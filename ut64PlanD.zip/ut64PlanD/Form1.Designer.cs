﻿namespace ut64configurator
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label185 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.label183 = new System.Windows.Forms.Label();
            this.Delete_fre_button = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.G1_dataLineEnable_button = new System.Windows.Forms.Button();
            this.plt22 = new ScottPlot.FormsPlot();
            this.plt21 = new ScottPlot.FormsPlot();
            this.label179 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.SB_IQ_AcheckBox = new System.Windows.Forms.CheckBox();
            this.SA_IQ_AcheckBox = new System.Windows.Forms.CheckBox();
            this.SB_IQ_QcheckBox = new System.Windows.Forms.CheckBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.SA_IQ_QcheckBox = new System.Windows.Forms.CheckBox();
            this.SB_IQ_IcheckBox = new System.Windows.Forms.CheckBox();
            this.SA_IQ_IcheckBox = new System.Windows.Forms.CheckBox();
            this.label124 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.plt1 = new ScottPlot.FormsPlot();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.plt2 = new ScottPlot.FormsPlot();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.plt8 = new ScottPlot.FormsPlot();
            this.plt7 = new ScottPlot.FormsPlot();
            this.plt6 = new ScottPlot.FormsPlot();
            this.plt5 = new ScottPlot.FormsPlot();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.checkBox33 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.plt10 = new ScottPlot.FormsPlot();
            this.storage_button = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.button_switch = new System.Windows.Forms.Button();
            this.port_list = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.HV4_textBox = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.HV2_textBox = new System.Windows.Forms.TextBox();
            this.HV1_textBox = new System.Windows.Forms.TextBox();
            this.HV3_textBox = new System.Windows.Forms.TextBox();
            this.HV_SB_textBox = new System.Windows.Forms.TextBox();
            this.HV_CB_textBox = new System.Windows.Forms.TextBox();
            this.HV_SA_textBox = new System.Windows.Forms.TextBox();
            this.HV_CA_textBox = new System.Windows.Forms.TextBox();
            this.G1_HV_button = new System.Windows.Forms.Button();
            this.G1_MISCbutton = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.G1_wait_textBox = new System.Windows.Forms.TextBox();
            this.G1_stepfre_textBox = new System.Windows.Forms.TextBox();
            this.G1_lfre_textBox = new System.Windows.Forms.TextBox();
            this.G1_hfre_textBox = new System.Windows.Forms.TextBox();
            this.G1_scanfre_button = new System.Windows.Forms.Button();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.G1_PLL_button = new System.Windows.Forms.Button();
            this.label176 = new System.Windows.Forms.Label();
            this.label175 = new System.Windows.Forms.Label();
            this.PLL_D_textBox = new System.Windows.Forms.TextBox();
            this.PLL_relativeerror_textBox = new System.Windows.Forms.TextBox();
            this.PLL_Nowphase_textBox = new System.Windows.Forms.TextBox();
            this.PLL_Nowfre_textBox = new System.Windows.Forms.TextBox();
            this.PLL_Lockpha_Limiteamp_textBox = new System.Windows.Forms.TextBox();
            this.PLL_I_textBox = new System.Windows.Forms.TextBox();
            this.PLL_P_textBox = new System.Windows.Forms.TextBox();
            this.PLL_middlefre_textBox = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.PLL_Lockphase_textBox = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label173 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.openLoopEnableG1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.G1_drivefre_textBox = new System.Windows.Forms.TextBox();
            this.G1_drivefre_button = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label91 = new System.Windows.Forms.Label();
            this.CMD_OPENLOOP_ACT_button = new System.Windows.Forms.Button();
            this.label189 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.pidAmpOutputG1_textBox = new System.Windows.Forms.TextBox();
            this.pidAmpErrorG1_textBox = new System.Windows.Forms.TextBox();
            this.pid4DG1 = new System.Windows.Forms.TextBox();
            this.pid4IG1 = new System.Windows.Forms.TextBox();
            this.pid4PG1 = new System.Windows.Forms.TextBox();
            this.pid4LimitAmpG1 = new System.Windows.Forms.TextBox();
            this.pid4MiddleAmpG1 = new System.Windows.Forms.TextBox();
            this.pid4LockAmpG1 = new System.Windows.Forms.TextBox();
            this.pid3DG1 = new System.Windows.Forms.TextBox();
            this.pid3IG1 = new System.Windows.Forms.TextBox();
            this.pid3PG1 = new System.Windows.Forms.TextBox();
            this.pid3LimitAmpG1 = new System.Windows.Forms.TextBox();
            this.pid3MiddleAmpG1 = new System.Windows.Forms.TextBox();
            this.pid3LockAmpG1 = new System.Windows.Forms.TextBox();
            this.pid2DG1 = new System.Windows.Forms.TextBox();
            this.pid2IG1 = new System.Windows.Forms.TextBox();
            this.pid2PG1 = new System.Windows.Forms.TextBox();
            this.pid2LimitAmpG1 = new System.Windows.Forms.TextBox();
            this.pid2MiddleAmpG1 = new System.Windows.Forms.TextBox();
            this.pid2LockAmpG1 = new System.Windows.Forms.TextBox();
            this.pid1DG1 = new System.Windows.Forms.TextBox();
            this.pid1IG1 = new System.Windows.Forms.TextBox();
            this.pid1PG1 = new System.Windows.Forms.TextBox();
            this.pid1LimitAmpG1 = new System.Windows.Forms.TextBox();
            this.pid1MiddleAmpG1 = new System.Windows.Forms.TextBox();
            this.pid1LockAmpG1 = new System.Windows.Forms.TextBox();
            this.Openloop_BC_textBox = new System.Windows.Forms.TextBox();
            this.Openloop_BS_textBox = new System.Windows.Forms.TextBox();
            this.Openloop_AC_textBox = new System.Windows.Forms.TextBox();
            this.Openloop_AS_textBox = new System.Windows.Forms.TextBox();
            this.label191 = new System.Windows.Forms.Label();
            this.label192 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.G1_pid4_button = new System.Windows.Forms.Button();
            this.pid4EnableG1 = new System.Windows.Forms.Button();
            this.G1_pid3_button = new System.Windows.Forms.Button();
            this.pid3EnableG1 = new System.Windows.Forms.Button();
            this.G1_pid2_button = new System.Windows.Forms.Button();
            this.pid2EnableG1 = new System.Windows.Forms.Button();
            this.G1_pid1_button = new System.Windows.Forms.Button();
            this.pid1EnableG1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 35;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label185
            // 
            this.label185.AutoSize = true;
            this.label185.Location = new System.Drawing.Point(168, 312);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(29, 12);
            this.label185.TabIndex = 17;
            this.label185.Text = "0.00";
            // 
            // label184
            // 
            this.label184.AutoSize = true;
            this.label184.Location = new System.Drawing.Point(233, 312);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(29, 12);
            this.label184.TabIndex = 17;
            this.label184.Text = "0.00";
            // 
            // label183
            // 
            this.label183.AutoSize = true;
            this.label183.Location = new System.Drawing.Point(233, 10);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(29, 12);
            this.label183.TabIndex = 16;
            this.label183.Text = "0.00";
            // 
            // Delete_fre_button
            // 
            this.Delete_fre_button.Location = new System.Drawing.Point(77, 5);
            this.Delete_fre_button.Name = "Delete_fre_button";
            this.Delete_fre_button.Size = new System.Drawing.Size(75, 23);
            this.Delete_fre_button.TabIndex = 14;
            this.Delete_fre_button.Text = "清除曲线";
            this.Delete_fre_button.UseVisualStyleBackColor = true;
            this.Delete_fre_button.Click += new System.EventHandler(this.Delete_fre_button_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.G1_dataLineEnable_button);
            this.tabPage6.Controls.Add(this.plt22);
            this.tabPage6.Controls.Add(this.plt21);
            this.tabPage6.Controls.Add(this.label185);
            this.tabPage6.Controls.Add(this.label184);
            this.tabPage6.Controls.Add(this.label183);
            this.tabPage6.Controls.Add(this.label179);
            this.tabPage6.Controls.Add(this.Delete_fre_button);
            this.tabPage6.Controls.Add(this.label126);
            this.tabPage6.Controls.Add(this.label125);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(701, 625);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "扫频曲线";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // G1_dataLineEnable_button
            // 
            this.G1_dataLineEnable_button.Location = new System.Drawing.Point(643, 10);
            this.G1_dataLineEnable_button.Name = "G1_dataLineEnable_button";
            this.G1_dataLineEnable_button.Size = new System.Drawing.Size(43, 23);
            this.G1_dataLineEnable_button.TabIndex = 20;
            this.G1_dataLineEnable_button.Text = "开";
            this.G1_dataLineEnable_button.UseVisualStyleBackColor = true;
            this.G1_dataLineEnable_button.Click += new System.EventHandler(this.G1_dataLineEnable_button_Click);
            // 
            // plt22
            // 
            this.plt22.Location = new System.Drawing.Point(70, 339);
            this.plt22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt22.Name = "plt22";
            this.plt22.Size = new System.Drawing.Size(631, 277);
            this.plt22.TabIndex = 19;
            // 
            // plt21
            // 
            this.plt21.Location = new System.Drawing.Point(70, 33);
            this.plt21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt21.Name = "plt21";
            this.plt21.Size = new System.Drawing.Size(631, 277);
            this.plt21.TabIndex = 18;
            // 
            // label179
            // 
            this.label179.AutoSize = true;
            this.label179.Location = new System.Drawing.Point(168, 10);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(29, 12);
            this.label179.TabIndex = 15;
            this.label179.Text = "0.00";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(8, 314);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(53, 12);
            this.label126.TabIndex = 1;
            this.label126.Text = "相频曲线";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(7, 10);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(53, 12);
            this.label125.TabIndex = 1;
            this.label125.Text = "幅频曲线";
            // 
            // SB_IQ_AcheckBox
            // 
            this.SB_IQ_AcheckBox.AutoSize = true;
            this.SB_IQ_AcheckBox.Checked = true;
            this.SB_IQ_AcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SB_IQ_AcheckBox.Location = new System.Drawing.Point(460, 314);
            this.SB_IQ_AcheckBox.Name = "SB_IQ_AcheckBox";
            this.SB_IQ_AcheckBox.Size = new System.Drawing.Size(102, 16);
            this.SB_IQ_AcheckBox.TabIndex = 2;
            this.SB_IQ_AcheckBox.Text = "B通道解调幅值";
            this.SB_IQ_AcheckBox.UseVisualStyleBackColor = true;
            // 
            // SA_IQ_AcheckBox
            // 
            this.SA_IQ_AcheckBox.AutoSize = true;
            this.SA_IQ_AcheckBox.Checked = true;
            this.SA_IQ_AcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SA_IQ_AcheckBox.Location = new System.Drawing.Point(460, 6);
            this.SA_IQ_AcheckBox.Name = "SA_IQ_AcheckBox";
            this.SA_IQ_AcheckBox.Size = new System.Drawing.Size(102, 16);
            this.SA_IQ_AcheckBox.TabIndex = 2;
            this.SA_IQ_AcheckBox.Text = "A通道解调幅值";
            this.SA_IQ_AcheckBox.UseVisualStyleBackColor = true;
            // 
            // SB_IQ_QcheckBox
            // 
            this.SB_IQ_QcheckBox.AutoSize = true;
            this.SB_IQ_QcheckBox.Checked = true;
            this.SB_IQ_QcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SB_IQ_QcheckBox.Location = new System.Drawing.Point(290, 314);
            this.SB_IQ_QcheckBox.Name = "SB_IQ_QcheckBox";
            this.SB_IQ_QcheckBox.Size = new System.Drawing.Size(84, 16);
            this.SB_IQ_QcheckBox.TabIndex = 2;
            this.SB_IQ_QcheckBox.Text = "B通道解调Q";
            this.SB_IQ_QcheckBox.UseVisualStyleBackColor = true;
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "自动",
            "手动",
            "X轴",
            "Y轴"});
            this.comboBox9.Location = new System.Drawing.Point(607, 6);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(74, 20);
            this.comboBox9.TabIndex = 4;
            this.comboBox9.Text = "自动";
            // 
            // SA_IQ_QcheckBox
            // 
            this.SA_IQ_QcheckBox.AutoSize = true;
            this.SA_IQ_QcheckBox.Checked = true;
            this.SA_IQ_QcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SA_IQ_QcheckBox.Location = new System.Drawing.Point(290, 6);
            this.SA_IQ_QcheckBox.Name = "SA_IQ_QcheckBox";
            this.SA_IQ_QcheckBox.Size = new System.Drawing.Size(84, 16);
            this.SA_IQ_QcheckBox.TabIndex = 2;
            this.SA_IQ_QcheckBox.Text = "A通道解调Q";
            this.SA_IQ_QcheckBox.UseVisualStyleBackColor = true;
            // 
            // SB_IQ_IcheckBox
            // 
            this.SB_IQ_IcheckBox.AutoSize = true;
            this.SB_IQ_IcheckBox.Checked = true;
            this.SB_IQ_IcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SB_IQ_IcheckBox.Location = new System.Drawing.Point(120, 314);
            this.SB_IQ_IcheckBox.Name = "SB_IQ_IcheckBox";
            this.SB_IQ_IcheckBox.Size = new System.Drawing.Size(84, 16);
            this.SB_IQ_IcheckBox.TabIndex = 2;
            this.SB_IQ_IcheckBox.Text = "B通道解调I";
            this.SB_IQ_IcheckBox.UseVisualStyleBackColor = true;
            // 
            // SA_IQ_IcheckBox
            // 
            this.SA_IQ_IcheckBox.AutoSize = true;
            this.SA_IQ_IcheckBox.Checked = true;
            this.SA_IQ_IcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SA_IQ_IcheckBox.Location = new System.Drawing.Point(120, 6);
            this.SA_IQ_IcheckBox.Name = "SA_IQ_IcheckBox";
            this.SA_IQ_IcheckBox.Size = new System.Drawing.Size(84, 16);
            this.SA_IQ_IcheckBox.TabIndex = 2;
            this.SA_IQ_IcheckBox.Text = "A通道解调I";
            this.SA_IQ_IcheckBox.UseVisualStyleBackColor = true;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(11, 314);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(41, 12);
            this.label124.TabIndex = 1;
            this.label124.Text = "模态SB";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(11, 7);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(41, 12);
            this.label123.TabIndex = 1;
            this.label123.Text = "模态SA";
            // 
            // plt1
            // 
            this.plt1.Location = new System.Drawing.Point(70, 25);
            this.plt1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt1.Name = "plt1";
            this.plt1.Size = new System.Drawing.Size(631, 277);
            this.plt1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.SB_IQ_AcheckBox);
            this.tabPage5.Controls.Add(this.SA_IQ_AcheckBox);
            this.tabPage5.Controls.Add(this.SB_IQ_QcheckBox);
            this.tabPage5.Controls.Add(this.comboBox9);
            this.tabPage5.Controls.Add(this.SA_IQ_QcheckBox);
            this.tabPage5.Controls.Add(this.SB_IQ_IcheckBox);
            this.tabPage5.Controls.Add(this.SA_IQ_IcheckBox);
            this.tabPage5.Controls.Add(this.label124);
            this.tabPage5.Controls.Add(this.label123);
            this.tabPage5.Controls.Add(this.plt2);
            this.tabPage5.Controls.Add(this.plt1);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(701, 625);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "IQ曲线";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // plt2
            // 
            this.plt2.Location = new System.Drawing.Point(70, 322);
            this.plt2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt2.Name = "plt2";
            this.plt2.Size = new System.Drawing.Size(631, 277);
            this.plt2.TabIndex = 0;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage5);
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Location = new System.Drawing.Point(456, 98);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(709, 651);
            this.tabControl3.TabIndex = 15;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.checkBox2);
            this.tabPage7.Controls.Add(this.checkBox9);
            this.tabPage7.Controls.Add(this.checkBox8);
            this.tabPage7.Controls.Add(this.checkBox5);
            this.tabPage7.Controls.Add(this.checkBox7);
            this.tabPage7.Controls.Add(this.checkBox4);
            this.tabPage7.Controls.Add(this.checkBox6);
            this.tabPage7.Controls.Add(this.checkBox3);
            this.tabPage7.Controls.Add(this.checkBox1);
            this.tabPage7.Controls.Add(this.plt8);
            this.tabPage7.Controls.Add(this.plt7);
            this.tabPage7.Controls.Add(this.plt6);
            this.tabPage7.Controls.Add(this.plt5);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(701, 625);
            this.tabPage7.TabIndex = 2;
            this.tabPage7.Text = "锁相环";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(368, 3);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(72, 16);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "当前频率";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(368, 424);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(72, 16);
            this.checkBox9.TabIndex = 1;
            this.checkBox9.Text = "当前相位";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(368, 275);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(102, 16);
            this.checkBox8.TabIndex = 1;
            this.checkBox8.Text = "B通道解调幅值";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(368, 137);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(102, 16);
            this.checkBox5.TabIndex = 1;
            this.checkBox5.Text = "A通道解调幅值";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(284, 275);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(84, 16);
            this.checkBox7.TabIndex = 1;
            this.checkBox7.Text = "B通道解调Q";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(284, 137);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(84, 16);
            this.checkBox4.TabIndex = 1;
            this.checkBox4.Text = "A通道解调Q";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(189, 275);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(84, 16);
            this.checkBox6.TabIndex = 1;
            this.checkBox6.Text = "B通道解调I";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(189, 137);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(84, 16);
            this.checkBox3.TabIndex = 1;
            this.checkBox3.Text = "A通道解调I";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(284, 3);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(72, 16);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "相位误差";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // plt8
            // 
            this.plt8.Location = new System.Drawing.Point(20, 434);
            this.plt8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt8.Name = "plt8";
            this.plt8.Size = new System.Drawing.Size(678, 131);
            this.plt8.TabIndex = 0;
            // 
            // plt7
            // 
            this.plt7.Location = new System.Drawing.Point(23, 296);
            this.plt7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt7.Name = "plt7";
            this.plt7.Size = new System.Drawing.Size(678, 131);
            this.plt7.TabIndex = 0;
            // 
            // plt6
            // 
            this.plt6.Location = new System.Drawing.Point(20, 149);
            this.plt6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt6.Name = "plt6";
            this.plt6.Size = new System.Drawing.Size(678, 131);
            this.plt6.TabIndex = 0;
            // 
            // plt5
            // 
            this.plt5.Location = new System.Drawing.Point(20, 14);
            this.plt5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt5.Name = "plt5";
            this.plt5.Size = new System.Drawing.Size(678, 131);
            this.plt5.TabIndex = 0;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.checkBox33);
            this.tabPage9.Controls.Add(this.checkBox11);
            this.tabPage9.Controls.Add(this.plt10);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(701, 625);
            this.tabPage9.TabIndex = 4;
            this.tabPage9.Text = "PID";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // checkBox33
            // 
            this.checkBox33.AutoSize = true;
            this.checkBox33.Location = new System.Drawing.Point(385, 14);
            this.checkBox33.Name = "checkBox33";
            this.checkBox33.Size = new System.Drawing.Size(72, 16);
            this.checkBox33.TabIndex = 2;
            this.checkBox33.Text = "输出误差";
            this.checkBox33.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(275, 14);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(72, 16);
            this.checkBox11.TabIndex = 1;
            this.checkBox11.Text = "输出幅值";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // plt10
            // 
            this.plt10.Location = new System.Drawing.Point(13, 53);
            this.plt10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt10.Name = "plt10";
            this.plt10.Size = new System.Drawing.Size(674, 277);
            this.plt10.TabIndex = 0;
            // 
            // storage_button
            // 
            this.storage_button.Location = new System.Drawing.Point(1086, 43);
            this.storage_button.Name = "storage_button";
            this.storage_button.Size = new System.Drawing.Size(75, 23);
            this.storage_button.TabIndex = 24;
            this.storage_button.Text = "开始保存";
            this.storage_button.UseVisualStyleBackColor = true;
            this.storage_button.Click += new System.EventHandler(this.storage_button_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(1003, 14);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 23;
            this.button9.Text = "清空";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(220, 4);
            this.textBox89.MaxLength = 3276700;
            this.textBox89.Multiline = true;
            this.textBox89.Name = "textBox89";
            this.textBox89.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox89.Size = new System.Drawing.Size(779, 33);
            this.textBox89.TabIndex = 22;
            // 
            // button_switch
            // 
            this.button_switch.BackColor = System.Drawing.SystemColors.Window;
            this.button_switch.Location = new System.Drawing.Point(136, 5);
            this.button_switch.Name = "button_switch";
            this.button_switch.Size = new System.Drawing.Size(75, 23);
            this.button_switch.TabIndex = 21;
            this.button_switch.Text = "START";
            this.button_switch.UseVisualStyleBackColor = false;
            this.button_switch.TextChanged += new System.EventHandler(this.button_switch_TextChanged);
            this.button_switch.Click += new System.EventHandler(this.button_switch_Click);
            // 
            // port_list
            // 
            this.port_list.FormattingEnabled = true;
            this.port_list.Location = new System.Drawing.Point(27, 7);
            this.port_list.Name = "port_list";
            this.port_list.Size = new System.Drawing.Size(92, 20);
            this.port_list.TabIndex = 20;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(7, 127);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(31, 16);
            this.label32.TabIndex = 3;
            this.label32.Text = "HV4";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.Location = new System.Drawing.Point(219, 116);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(17, 24);
            this.label28.TabIndex = 3;
            this.label28.Text = "DB\r\nφ";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(219, 86);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(17, 24);
            this.label27.TabIndex = 3;
            this.label27.Text = "DA\r\nφ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(220, 53);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(17, 24);
            this.label26.TabIndex = 3;
            this.label26.Text = "SB\r\nφ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(220, 20);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(17, 24);
            this.label25.TabIndex = 3;
            this.label25.Text = "SA\r\nφ";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(7, 97);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(31, 16);
            this.label31.TabIndex = 3;
            this.label31.Text = "HV3";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.Location = new System.Drawing.Point(8, 64);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(31, 16);
            this.label30.TabIndex = 3;
            this.label30.Text = "HV2";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.Location = new System.Drawing.Point(8, 31);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(31, 16);
            this.label29.TabIndex = 3;
            this.label29.Text = "HV1";
            // 
            // HV4_textBox
            // 
            this.HV4_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV4_textBox.Location = new System.Drawing.Point(39, 119);
            this.HV4_textBox.Name = "HV4_textBox";
            this.HV4_textBox.Size = new System.Drawing.Size(65, 26);
            this.HV4_textBox.TabIndex = 1;
            this.HV4_textBox.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.Location = new System.Drawing.Point(105, 127);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(15, 16);
            this.label36.TabIndex = 3;
            this.label36.Text = "V";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.Location = new System.Drawing.Point(105, 97);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(15, 16);
            this.label35.TabIndex = 3;
            this.label35.Text = "V";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.Location = new System.Drawing.Point(105, 64);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(15, 16);
            this.label34.TabIndex = 3;
            this.label34.Text = "V";
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.HV2_textBox);
            this.tabPage13.Controls.Add(this.HV1_textBox);
            this.tabPage13.Controls.Add(this.HV4_textBox);
            this.tabPage13.Controls.Add(this.HV3_textBox);
            this.tabPage13.Controls.Add(this.HV_SB_textBox);
            this.tabPage13.Controls.Add(this.HV_CB_textBox);
            this.tabPage13.Controls.Add(this.HV_SA_textBox);
            this.tabPage13.Controls.Add(this.HV_CA_textBox);
            this.tabPage13.Controls.Add(this.G1_HV_button);
            this.tabPage13.Controls.Add(this.label32);
            this.tabPage13.Controls.Add(this.label28);
            this.tabPage13.Controls.Add(this.label27);
            this.tabPage13.Controls.Add(this.label26);
            this.tabPage13.Controls.Add(this.label25);
            this.tabPage13.Controls.Add(this.label31);
            this.tabPage13.Controls.Add(this.label30);
            this.tabPage13.Controls.Add(this.label29);
            this.tabPage13.Controls.Add(this.G1_MISCbutton);
            this.tabPage13.Controls.Add(this.label36);
            this.tabPage13.Controls.Add(this.label35);
            this.tabPage13.Controls.Add(this.label34);
            this.tabPage13.Controls.Add(this.label33);
            this.tabPage13.Controls.Add(this.label24);
            this.tabPage13.Controls.Add(this.label23);
            this.tabPage13.Controls.Add(this.label22);
            this.tabPage13.Controls.Add(this.label21);
            this.tabPage13.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(415, 169);
            this.tabPage13.TabIndex = 0;
            this.tabPage13.Text = "辅助参数";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // HV2_textBox
            // 
            this.HV2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV2_textBox.Location = new System.Drawing.Point(39, 53);
            this.HV2_textBox.Name = "HV2_textBox";
            this.HV2_textBox.Size = new System.Drawing.Size(65, 26);
            this.HV2_textBox.TabIndex = 1;
            this.HV2_textBox.Text = "0";
            // 
            // HV1_textBox
            // 
            this.HV1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV1_textBox.Location = new System.Drawing.Point(39, 20);
            this.HV1_textBox.Name = "HV1_textBox";
            this.HV1_textBox.Size = new System.Drawing.Size(65, 26);
            this.HV1_textBox.TabIndex = 1;
            this.HV1_textBox.Text = "0";
            // 
            // HV3_textBox
            // 
            this.HV3_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV3_textBox.Location = new System.Drawing.Point(39, 86);
            this.HV3_textBox.Name = "HV3_textBox";
            this.HV3_textBox.Size = new System.Drawing.Size(65, 26);
            this.HV3_textBox.TabIndex = 1;
            this.HV3_textBox.Text = "0";
            // 
            // HV_SB_textBox
            // 
            this.HV_SB_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV_SB_textBox.Location = new System.Drawing.Point(236, 50);
            this.HV_SB_textBox.Name = "HV_SB_textBox";
            this.HV_SB_textBox.Size = new System.Drawing.Size(59, 26);
            this.HV_SB_textBox.TabIndex = 1;
            this.HV_SB_textBox.Text = "0";
            // 
            // HV_CB_textBox
            // 
            this.HV_CB_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV_CB_textBox.Location = new System.Drawing.Point(236, 116);
            this.HV_CB_textBox.Name = "HV_CB_textBox";
            this.HV_CB_textBox.Size = new System.Drawing.Size(59, 26);
            this.HV_CB_textBox.TabIndex = 1;
            this.HV_CB_textBox.Text = "0";
            // 
            // HV_SA_textBox
            // 
            this.HV_SA_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV_SA_textBox.Location = new System.Drawing.Point(237, 17);
            this.HV_SA_textBox.Name = "HV_SA_textBox";
            this.HV_SA_textBox.Size = new System.Drawing.Size(58, 26);
            this.HV_SA_textBox.TabIndex = 1;
            this.HV_SA_textBox.Text = "0";
            // 
            // HV_CA_textBox
            // 
            this.HV_CA_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV_CA_textBox.Location = new System.Drawing.Point(236, 83);
            this.HV_CA_textBox.Name = "HV_CA_textBox";
            this.HV_CA_textBox.Size = new System.Drawing.Size(59, 26);
            this.HV_CA_textBox.TabIndex = 1;
            this.HV_CA_textBox.Text = "0";
            // 
            // G1_HV_button
            // 
            this.G1_HV_button.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_HV_button.Location = new System.Drawing.Point(121, 78);
            this.G1_HV_button.Name = "G1_HV_button";
            this.G1_HV_button.Size = new System.Drawing.Size(75, 23);
            this.G1_HV_button.TabIndex = 4;
            this.G1_HV_button.Text = "G1发送";
            this.G1_HV_button.UseVisualStyleBackColor = true;
            this.G1_HV_button.Click += new System.EventHandler(this.G1_HV_button_Click);
            // 
            // G1_MISCbutton
            // 
            this.G1_MISCbutton.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_MISCbutton.Location = new System.Drawing.Point(340, 78);
            this.G1_MISCbutton.Name = "G1_MISCbutton";
            this.G1_MISCbutton.Size = new System.Drawing.Size(75, 23);
            this.G1_MISCbutton.TabIndex = 0;
            this.G1_MISCbutton.Text = "G1发送";
            this.G1_MISCbutton.UseVisualStyleBackColor = true;
            this.G1_MISCbutton.Click += new System.EventHandler(this.G1_MISCbutton_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(105, 31);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(15, 16);
            this.label33.TabIndex = 3;
            this.label33.Text = "V";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(300, 127);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(31, 16);
            this.label24.TabIndex = 3;
            this.label24.Text = "deg";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(300, 94);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(31, 16);
            this.label23.TabIndex = 3;
            this.label23.Text = "deg";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(300, 61);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(31, 16);
            this.label22.TabIndex = 3;
            this.label22.Text = "deg";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(301, 28);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(31, 16);
            this.label21.TabIndex = 3;
            this.label21.Text = "deg";
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage13);
            this.tabControl4.Location = new System.Drawing.Point(27, 555);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(423, 195);
            this.tabControl4.TabIndex = 17;
            // 
            // G1_wait_textBox
            // 
            this.G1_wait_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_wait_textBox.Location = new System.Drawing.Point(88, 136);
            this.G1_wait_textBox.Name = "G1_wait_textBox";
            this.G1_wait_textBox.Size = new System.Drawing.Size(75, 26);
            this.G1_wait_textBox.TabIndex = 1;
            this.G1_wait_textBox.Text = "0";
            // 
            // G1_stepfre_textBox
            // 
            this.G1_stepfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_stepfre_textBox.Location = new System.Drawing.Point(88, 103);
            this.G1_stepfre_textBox.Name = "G1_stepfre_textBox";
            this.G1_stepfre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G1_stepfre_textBox.TabIndex = 1;
            this.G1_stepfre_textBox.Text = "0";
            // 
            // G1_lfre_textBox
            // 
            this.G1_lfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_lfre_textBox.Location = new System.Drawing.Point(88, 70);
            this.G1_lfre_textBox.Name = "G1_lfre_textBox";
            this.G1_lfre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G1_lfre_textBox.TabIndex = 1;
            this.G1_lfre_textBox.Text = "0";
            // 
            // G1_hfre_textBox
            // 
            this.G1_hfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_hfre_textBox.Location = new System.Drawing.Point(88, 37);
            this.G1_hfre_textBox.Name = "G1_hfre_textBox";
            this.G1_hfre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G1_hfre_textBox.TabIndex = 1;
            this.G1_hfre_textBox.Text = "0";
            // 
            // G1_scanfre_button
            // 
            this.G1_scanfre_button.Location = new System.Drawing.Point(329, 100);
            this.G1_scanfre_button.Name = "G1_scanfre_button";
            this.G1_scanfre_button.Size = new System.Drawing.Size(75, 23);
            this.G1_scanfre_button.TabIndex = 0;
            this.G1_scanfre_button.Text = "G1发送";
            this.G1_scanfre_button.UseVisualStyleBackColor = true;
            this.G1_scanfre_button.Click += new System.EventHandler(this.G1_scanfre_button_Click);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(19, 151);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(65, 12);
            this.label56.TabIndex = 2;
            this.label56.Text = "G1等待时间";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(41, 118);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(41, 12);
            this.label55.TabIndex = 2;
            this.label55.Text = "G1步长";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(29, 85);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(53, 12);
            this.label54.TabIndex = 2;
            this.label54.Text = "下限频率";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(31, 52);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(53, 12);
            this.label53.TabIndex = 2;
            this.label53.Text = "上限频率";
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.G1_PLL_button);
            this.tabPage10.Controls.Add(this.label176);
            this.tabPage10.Controls.Add(this.label175);
            this.tabPage10.Controls.Add(this.PLL_D_textBox);
            this.tabPage10.Controls.Add(this.PLL_relativeerror_textBox);
            this.tabPage10.Controls.Add(this.PLL_Nowphase_textBox);
            this.tabPage10.Controls.Add(this.PLL_Nowfre_textBox);
            this.tabPage10.Controls.Add(this.PLL_Lockpha_Limiteamp_textBox);
            this.tabPage10.Controls.Add(this.PLL_I_textBox);
            this.tabPage10.Controls.Add(this.PLL_P_textBox);
            this.tabPage10.Controls.Add(this.PLL_middlefre_textBox);
            this.tabPage10.Controls.Add(this.label71);
            this.tabPage10.Controls.Add(this.PLL_Lockphase_textBox);
            this.tabPage10.Controls.Add(this.label70);
            this.tabPage10.Controls.Add(this.label118);
            this.tabPage10.Controls.Add(this.label119);
            this.tabPage10.Controls.Add(this.label117);
            this.tabPage10.Controls.Add(this.label74);
            this.tabPage10.Controls.Add(this.label69);
            this.tabPage10.Controls.Add(this.label75);
            this.tabPage10.Controls.Add(this.label76);
            this.tabPage10.Controls.Add(this.comboBox1);
            this.tabPage10.Controls.Add(this.label173);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(415, 193);
            this.tabPage10.TabIndex = 2;
            this.tabPage10.Text = "PLL";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // G1_PLL_button
            // 
            this.G1_PLL_button.Location = new System.Drawing.Point(316, 149);
            this.G1_PLL_button.Name = "G1_PLL_button";
            this.G1_PLL_button.Size = new System.Drawing.Size(75, 23);
            this.G1_PLL_button.TabIndex = 14;
            this.G1_PLL_button.Text = "PLL发送";
            this.G1_PLL_button.UseVisualStyleBackColor = true;
            this.G1_PLL_button.Click += new System.EventHandler(this.G1_PLL_button_Click);
            // 
            // label176
            // 
            this.label176.AutoSize = true;
            this.label176.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label176.Location = new System.Drawing.Point(210, 128);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(23, 16);
            this.label176.TabIndex = 13;
            this.label176.Text = "Hz";
            // 
            // label175
            // 
            this.label175.AutoSize = true;
            this.label175.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label175.Location = new System.Drawing.Point(209, 95);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(23, 16);
            this.label175.TabIndex = 13;
            this.label175.Text = "Hz";
            // 
            // PLL_D_textBox
            // 
            this.PLL_D_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_D_textBox.Location = new System.Drawing.Point(250, 117);
            this.PLL_D_textBox.Name = "PLL_D_textBox";
            this.PLL_D_textBox.Size = new System.Drawing.Size(57, 26);
            this.PLL_D_textBox.TabIndex = 6;
            this.PLL_D_textBox.Text = "0";
            // 
            // PLL_relativeerror_textBox
            // 
            this.PLL_relativeerror_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_relativeerror_textBox.Location = new System.Drawing.Point(58, 13);
            this.PLL_relativeerror_textBox.Multiline = true;
            this.PLL_relativeerror_textBox.Name = "PLL_relativeerror_textBox";
            this.PLL_relativeerror_textBox.ReadOnly = true;
            this.PLL_relativeerror_textBox.Size = new System.Drawing.Size(80, 27);
            this.PLL_relativeerror_textBox.TabIndex = 6;
            // 
            // PLL_Nowphase_textBox
            // 
            this.PLL_Nowphase_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_Nowphase_textBox.Location = new System.Drawing.Point(189, 12);
            this.PLL_Nowphase_textBox.Multiline = true;
            this.PLL_Nowphase_textBox.Name = "PLL_Nowphase_textBox";
            this.PLL_Nowphase_textBox.ReadOnly = true;
            this.PLL_Nowphase_textBox.Size = new System.Drawing.Size(75, 27);
            this.PLL_Nowphase_textBox.TabIndex = 6;
            // 
            // PLL_Nowfre_textBox
            // 
            this.PLL_Nowfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_Nowfre_textBox.Location = new System.Drawing.Point(334, 12);
            this.PLL_Nowfre_textBox.Multiline = true;
            this.PLL_Nowfre_textBox.Name = "PLL_Nowfre_textBox";
            this.PLL_Nowfre_textBox.ReadOnly = true;
            this.PLL_Nowfre_textBox.Size = new System.Drawing.Size(75, 27);
            this.PLL_Nowfre_textBox.TabIndex = 6;
            // 
            // PLL_Lockpha_Limiteamp_textBox
            // 
            this.PLL_Lockpha_Limiteamp_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_Lockpha_Limiteamp_textBox.Location = new System.Drawing.Point(137, 117);
            this.PLL_Lockpha_Limiteamp_textBox.Name = "PLL_Lockpha_Limiteamp_textBox";
            this.PLL_Lockpha_Limiteamp_textBox.Size = new System.Drawing.Size(70, 26);
            this.PLL_Lockpha_Limiteamp_textBox.TabIndex = 6;
            this.PLL_Lockpha_Limiteamp_textBox.Text = "0";
            // 
            // PLL_I_textBox
            // 
            this.PLL_I_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_I_textBox.Location = new System.Drawing.Point(250, 84);
            this.PLL_I_textBox.Name = "PLL_I_textBox";
            this.PLL_I_textBox.Size = new System.Drawing.Size(57, 26);
            this.PLL_I_textBox.TabIndex = 7;
            this.PLL_I_textBox.Text = "0";
            // 
            // PLL_P_textBox
            // 
            this.PLL_P_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_P_textBox.Location = new System.Drawing.Point(250, 51);
            this.PLL_P_textBox.Name = "PLL_P_textBox";
            this.PLL_P_textBox.Size = new System.Drawing.Size(57, 26);
            this.PLL_P_textBox.TabIndex = 8;
            this.PLL_P_textBox.Text = "0";
            // 
            // PLL_middlefre_textBox
            // 
            this.PLL_middlefre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_middlefre_textBox.Location = new System.Drawing.Point(137, 84);
            this.PLL_middlefre_textBox.Name = "PLL_middlefre_textBox";
            this.PLL_middlefre_textBox.Size = new System.Drawing.Size(70, 26);
            this.PLL_middlefre_textBox.TabIndex = 7;
            this.PLL_middlefre_textBox.Text = "0";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label71.Location = new System.Drawing.Point(233, 128);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(15, 16);
            this.label71.TabIndex = 10;
            this.label71.Text = "D";
            // 
            // PLL_Lockphase_textBox
            // 
            this.PLL_Lockphase_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_Lockphase_textBox.Location = new System.Drawing.Point(137, 51);
            this.PLL_Lockphase_textBox.Name = "PLL_Lockphase_textBox";
            this.PLL_Lockphase_textBox.Size = new System.Drawing.Size(70, 26);
            this.PLL_Lockphase_textBox.TabIndex = 8;
            this.PLL_Lockphase_textBox.Text = "0";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label70.Location = new System.Drawing.Point(233, 95);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(15, 16);
            this.label70.TabIndex = 11;
            this.label70.Text = "I";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(157, 15);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(29, 24);
            this.label118.TabIndex = 10;
            this.label118.Text = "当前\r\n相位";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(26, 15);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(29, 24);
            this.label119.TabIndex = 10;
            this.label119.Text = "相对\r\n误差";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(302, 15);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(29, 24);
            this.label117.TabIndex = 10;
            this.label117.Text = "当前\r\n频率";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(81, 132);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(53, 12);
            this.label74.TabIndex = 10;
            this.label74.Text = "锁相限幅";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label69.Location = new System.Drawing.Point(233, 62);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(15, 16);
            this.label69.TabIndex = 12;
            this.label69.Text = "P";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(83, 99);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(53, 12);
            this.label75.TabIndex = 11;
            this.label75.Text = "中心频率";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(83, 66);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(53, 12);
            this.label76.TabIndex = 12;
            this.label76.Text = "锁定相位";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "关",
            "SA",
            "SB"});
            this.comboBox1.Location = new System.Drawing.Point(316, 84);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(69, 20);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.Text = "关";
            // 
            // label173
            // 
            this.label173.AutoSize = true;
            this.label173.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label173.Location = new System.Drawing.Point(205, 61);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(31, 16);
            this.label173.TabIndex = 3;
            this.label173.Text = "deg";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label57.Location = new System.Drawing.Point(169, 48);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(23, 16);
            this.label57.TabIndex = 4;
            this.label57.Text = "Hz";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.openLoopEnableG1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.G1_drivefre_textBox);
            this.tabPage1.Controls.Add(this.G1_drivefre_button);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(415, 193);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "开环频率";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // openLoopEnableG1
            // 
            this.openLoopEnableG1.BackColor = System.Drawing.Color.Red;
            this.openLoopEnableG1.Location = new System.Drawing.Point(195, 33);
            this.openLoopEnableG1.Name = "openLoopEnableG1";
            this.openLoopEnableG1.Size = new System.Drawing.Size(22, 17);
            this.openLoopEnableG1.TabIndex = 41;
            this.openLoopEnableG1.UseVisualStyleBackColor = false;
            this.openLoopEnableG1.Click += new System.EventHandler(this.openLoopEnableG1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(256, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Hz";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(130, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "G1驱动\r\n频率";
            // 
            // G1_drivefre_textBox
            // 
            this.G1_drivefre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_drivefre_textBox.Location = new System.Drawing.Point(175, 75);
            this.G1_drivefre_textBox.Name = "G1_drivefre_textBox";
            this.G1_drivefre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G1_drivefre_textBox.TabIndex = 1;
            this.G1_drivefre_textBox.Text = "0";
            // 
            // G1_drivefre_button
            // 
            this.G1_drivefre_button.Location = new System.Drawing.Point(175, 127);
            this.G1_drivefre_button.Name = "G1_drivefre_button";
            this.G1_drivefre_button.Size = new System.Drawing.Size(75, 23);
            this.G1_drivefre_button.TabIndex = 0;
            this.G1_drivefre_button.Text = "调频";
            this.G1_drivefre_button.UseVisualStyleBackColor = true;
            this.G1_drivefre_button.Click += new System.EventHandler(this.G1_drivefre_button_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Location = new System.Drawing.Point(27, 98);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(423, 219);
            this.tabControl1.TabIndex = 13;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.radioButton2);
            this.tabPage2.Controls.Add(this.radioButton3);
            this.tabPage2.Controls.Add(this.radioButton1);
            this.tabPage2.Controls.Add(this.label60);
            this.tabPage2.Controls.Add(this.label59);
            this.tabPage2.Controls.Add(this.label58);
            this.tabPage2.Controls.Add(this.label57);
            this.tabPage2.Controls.Add(this.G1_wait_textBox);
            this.tabPage2.Controls.Add(this.G1_stepfre_textBox);
            this.tabPage2.Controls.Add(this.G1_lfre_textBox);
            this.tabPage2.Controls.Add(this.G1_hfre_textBox);
            this.tabPage2.Controls.Add(this.G1_scanfre_button);
            this.tabPage2.Controls.Add(this.label56);
            this.tabPage2.Controls.Add(this.label55);
            this.tabPage2.Controls.Add(this.label54);
            this.tabPage2.Controls.Add(this.label53);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(415, 193);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "扫频";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoCheck = false;
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(218, 103);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(77, 16);
            this.radioButton2.TabIndex = 5;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "单扫/连扫";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.Click += new System.EventHandler(this.radioButton2_Click);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoCheck = false;
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(218, 136);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(71, 16);
            this.radioButton3.TabIndex = 5;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "扫频启停";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.Click += new System.EventHandler(this.radioButton3_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoCheck = false;
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(218, 69);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(77, 16);
            this.radioButton1.TabIndex = 5;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "正扫/反扫";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            this.radioButton1.Click += new System.EventHandler(this.radioButton1_Click);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label60.Location = new System.Drawing.Point(169, 147);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(23, 16);
            this.label60.TabIndex = 4;
            this.label60.Text = "ms";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label59.Location = new System.Drawing.Point(169, 114);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(23, 16);
            this.label59.TabIndex = 4;
            this.label59.Text = "Hz";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label58.Location = new System.Drawing.Point(169, 81);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(23, 16);
            this.label58.TabIndex = 4;
            this.label58.Text = "Hz";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(1107, 17);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(53, 12);
            this.label141.TabIndex = 30;
            this.label141.Text = "手动保存";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(279, 48);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 31;
            this.button1.Text = "G1PLL";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(198, 49);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 32;
            this.button2.Text = "G1扫频";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Red;
            this.button5.Location = new System.Drawing.Point(3, 379);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(22, 17);
            this.button5.TabIndex = 44;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Green;
            this.button6.Location = new System.Drawing.Point(3, 418);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(22, 17);
            this.button6.TabIndex = 45;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button7.Location = new System.Drawing.Point(3, 460);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(22, 17);
            this.button7.TabIndex = 46;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label93.Location = new System.Drawing.Point(1, 350);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(29, 12);
            this.label93.TabIndex = 84;
            this.label93.Text = "图例";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label94.Location = new System.Drawing.Point(6, 397);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(17, 12);
            this.label94.TabIndex = 85;
            this.label94.Text = "关";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label95.Location = new System.Drawing.Point(1, 438);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(29, 12);
            this.label95.TabIndex = 86;
            this.label95.Text = "幅值";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label97.Location = new System.Drawing.Point(1, 481);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(29, 12);
            this.label97.TabIndex = 87;
            this.label97.Text = "分量";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(360, 48);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 88;
            this.button8.Text = "G1AI";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(441, 48);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 89;
            this.button10.Text = "G1AQ";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(522, 48);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 90;
            this.button11.Text = "G1BI";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(603, 48);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 91;
            this.button12.Text = "G1BQ";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 1000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label91);
            this.tabPage3.Controls.Add(this.CMD_OPENLOOP_ACT_button);
            this.tabPage3.Controls.Add(this.label189);
            this.tabPage3.Controls.Add(this.label190);
            this.tabPage3.Controls.Add(this.pidAmpOutputG1_textBox);
            this.tabPage3.Controls.Add(this.pidAmpErrorG1_textBox);
            this.tabPage3.Controls.Add(this.pid4DG1);
            this.tabPage3.Controls.Add(this.pid4IG1);
            this.tabPage3.Controls.Add(this.pid4PG1);
            this.tabPage3.Controls.Add(this.pid4LimitAmpG1);
            this.tabPage3.Controls.Add(this.pid4MiddleAmpG1);
            this.tabPage3.Controls.Add(this.pid4LockAmpG1);
            this.tabPage3.Controls.Add(this.pid3DG1);
            this.tabPage3.Controls.Add(this.pid3IG1);
            this.tabPage3.Controls.Add(this.pid3PG1);
            this.tabPage3.Controls.Add(this.pid3LimitAmpG1);
            this.tabPage3.Controls.Add(this.pid3MiddleAmpG1);
            this.tabPage3.Controls.Add(this.pid3LockAmpG1);
            this.tabPage3.Controls.Add(this.pid2DG1);
            this.tabPage3.Controls.Add(this.pid2IG1);
            this.tabPage3.Controls.Add(this.pid2PG1);
            this.tabPage3.Controls.Add(this.pid2LimitAmpG1);
            this.tabPage3.Controls.Add(this.pid2MiddleAmpG1);
            this.tabPage3.Controls.Add(this.pid2LockAmpG1);
            this.tabPage3.Controls.Add(this.pid1DG1);
            this.tabPage3.Controls.Add(this.pid1IG1);
            this.tabPage3.Controls.Add(this.pid1PG1);
            this.tabPage3.Controls.Add(this.pid1LimitAmpG1);
            this.tabPage3.Controls.Add(this.pid1MiddleAmpG1);
            this.tabPage3.Controls.Add(this.pid1LockAmpG1);
            this.tabPage3.Controls.Add(this.Openloop_BC_textBox);
            this.tabPage3.Controls.Add(this.Openloop_BS_textBox);
            this.tabPage3.Controls.Add(this.Openloop_AC_textBox);
            this.tabPage3.Controls.Add(this.Openloop_AS_textBox);
            this.tabPage3.Controls.Add(this.label191);
            this.tabPage3.Controls.Add(this.label192);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.G1_pid4_button);
            this.tabPage3.Controls.Add(this.pid4EnableG1);
            this.tabPage3.Controls.Add(this.G1_pid3_button);
            this.tabPage3.Controls.Add(this.pid3EnableG1);
            this.tabPage3.Controls.Add(this.G1_pid2_button);
            this.tabPage3.Controls.Add(this.pid2EnableG1);
            this.tabPage3.Controls.Add(this.G1_pid1_button);
            this.tabPage3.Controls.Add(this.pid1EnableG1);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(415, 207);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "开环/PID";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label91.Location = new System.Drawing.Point(78, 10);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(29, 12);
            this.label91.TabIndex = 83;
            this.label91.Text = "状态";
            // 
            // CMD_OPENLOOP_ACT_button
            // 
            this.CMD_OPENLOOP_ACT_button.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CMD_OPENLOOP_ACT_button.Location = new System.Drawing.Point(8, 175);
            this.CMD_OPENLOOP_ACT_button.Name = "CMD_OPENLOOP_ACT_button";
            this.CMD_OPENLOOP_ACT_button.Size = new System.Drawing.Size(75, 23);
            this.CMD_OPENLOOP_ACT_button.TabIndex = 82;
            this.CMD_OPENLOOP_ACT_button.Text = "G1发送";
            this.CMD_OPENLOOP_ACT_button.UseVisualStyleBackColor = true;
            this.CMD_OPENLOOP_ACT_button.Click += new System.EventHandler(this.CMD_OPENLOOP_ACT_button_Click_1);
            // 
            // label189
            // 
            this.label189.AutoSize = true;
            this.label189.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label189.Location = new System.Drawing.Point(388, 182);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(23, 16);
            this.label189.TabIndex = 80;
            this.label189.Text = "mV";
            // 
            // label190
            // 
            this.label190.AutoSize = true;
            this.label190.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label190.Location = new System.Drawing.Point(229, 184);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(23, 16);
            this.label190.TabIndex = 81;
            this.label190.Text = "mV";
            // 
            // pidAmpOutputG1_textBox
            // 
            this.pidAmpOutputG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pidAmpOutputG1_textBox.Location = new System.Drawing.Point(304, 172);
            this.pidAmpOutputG1_textBox.Multiline = true;
            this.pidAmpOutputG1_textBox.Name = "pidAmpOutputG1_textBox";
            this.pidAmpOutputG1_textBox.ReadOnly = true;
            this.pidAmpOutputG1_textBox.Size = new System.Drawing.Size(78, 27);
            this.pidAmpOutputG1_textBox.TabIndex = 76;
            // 
            // pidAmpErrorG1_textBox
            // 
            this.pidAmpErrorG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pidAmpErrorG1_textBox.Location = new System.Drawing.Point(153, 173);
            this.pidAmpErrorG1_textBox.Multiline = true;
            this.pidAmpErrorG1_textBox.Name = "pidAmpErrorG1_textBox";
            this.pidAmpErrorG1_textBox.ReadOnly = true;
            this.pidAmpErrorG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.pidAmpErrorG1_textBox.TabIndex = 77;
            // 
            // pid4DG1
            // 
            this.pid4DG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4DG1.Location = new System.Drawing.Point(329, 130);
            this.pid4DG1.Name = "pid4DG1";
            this.pid4DG1.Size = new System.Drawing.Size(39, 23);
            this.pid4DG1.TabIndex = 67;
            this.pid4DG1.Text = "0";
            // 
            // pid4IG1
            // 
            this.pid4IG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4IG1.Location = new System.Drawing.Point(284, 130);
            this.pid4IG1.Name = "pid4IG1";
            this.pid4IG1.Size = new System.Drawing.Size(39, 23);
            this.pid4IG1.TabIndex = 66;
            this.pid4IG1.Text = "0";
            // 
            // pid4PG1
            // 
            this.pid4PG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4PG1.Location = new System.Drawing.Point(239, 130);
            this.pid4PG1.Name = "pid4PG1";
            this.pid4PG1.Size = new System.Drawing.Size(39, 23);
            this.pid4PG1.TabIndex = 65;
            this.pid4PG1.Text = "0";
            // 
            // pid4LimitAmpG1
            // 
            this.pid4LimitAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4LimitAmpG1.Location = new System.Drawing.Point(194, 130);
            this.pid4LimitAmpG1.Name = "pid4LimitAmpG1";
            this.pid4LimitAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid4LimitAmpG1.TabIndex = 64;
            this.pid4LimitAmpG1.Text = "0";
            // 
            // pid4MiddleAmpG1
            // 
            this.pid4MiddleAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4MiddleAmpG1.Location = new System.Drawing.Point(149, 130);
            this.pid4MiddleAmpG1.Name = "pid4MiddleAmpG1";
            this.pid4MiddleAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid4MiddleAmpG1.TabIndex = 63;
            this.pid4MiddleAmpG1.Text = "0";
            // 
            // pid4LockAmpG1
            // 
            this.pid4LockAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4LockAmpG1.Location = new System.Drawing.Point(105, 130);
            this.pid4LockAmpG1.Name = "pid4LockAmpG1";
            this.pid4LockAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid4LockAmpG1.TabIndex = 62;
            this.pid4LockAmpG1.Text = "0";
            // 
            // pid3DG1
            // 
            this.pid3DG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3DG1.Location = new System.Drawing.Point(329, 97);
            this.pid3DG1.Name = "pid3DG1";
            this.pid3DG1.Size = new System.Drawing.Size(39, 23);
            this.pid3DG1.TabIndex = 59;
            this.pid3DG1.Text = "0";
            // 
            // pid3IG1
            // 
            this.pid3IG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3IG1.Location = new System.Drawing.Point(284, 97);
            this.pid3IG1.Name = "pid3IG1";
            this.pid3IG1.Size = new System.Drawing.Size(39, 23);
            this.pid3IG1.TabIndex = 58;
            this.pid3IG1.Text = "0";
            // 
            // pid3PG1
            // 
            this.pid3PG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3PG1.Location = new System.Drawing.Point(239, 97);
            this.pid3PG1.Name = "pid3PG1";
            this.pid3PG1.Size = new System.Drawing.Size(39, 23);
            this.pid3PG1.TabIndex = 57;
            this.pid3PG1.Text = "0";
            // 
            // pid3LimitAmpG1
            // 
            this.pid3LimitAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3LimitAmpG1.Location = new System.Drawing.Point(194, 97);
            this.pid3LimitAmpG1.Name = "pid3LimitAmpG1";
            this.pid3LimitAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid3LimitAmpG1.TabIndex = 56;
            this.pid3LimitAmpG1.Text = "0";
            // 
            // pid3MiddleAmpG1
            // 
            this.pid3MiddleAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3MiddleAmpG1.Location = new System.Drawing.Point(149, 97);
            this.pid3MiddleAmpG1.Name = "pid3MiddleAmpG1";
            this.pid3MiddleAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid3MiddleAmpG1.TabIndex = 55;
            this.pid3MiddleAmpG1.Text = "0";
            // 
            // pid3LockAmpG1
            // 
            this.pid3LockAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3LockAmpG1.Location = new System.Drawing.Point(105, 97);
            this.pid3LockAmpG1.Name = "pid3LockAmpG1";
            this.pid3LockAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid3LockAmpG1.TabIndex = 54;
            this.pid3LockAmpG1.Text = "0";
            // 
            // pid2DG1
            // 
            this.pid2DG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2DG1.Location = new System.Drawing.Point(329, 64);
            this.pid2DG1.Name = "pid2DG1";
            this.pid2DG1.Size = new System.Drawing.Size(39, 23);
            this.pid2DG1.TabIndex = 51;
            this.pid2DG1.Text = "0";
            // 
            // pid2IG1
            // 
            this.pid2IG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2IG1.Location = new System.Drawing.Point(284, 64);
            this.pid2IG1.Name = "pid2IG1";
            this.pid2IG1.Size = new System.Drawing.Size(39, 23);
            this.pid2IG1.TabIndex = 50;
            this.pid2IG1.Text = "0";
            // 
            // pid2PG1
            // 
            this.pid2PG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2PG1.Location = new System.Drawing.Point(239, 64);
            this.pid2PG1.Name = "pid2PG1";
            this.pid2PG1.Size = new System.Drawing.Size(39, 23);
            this.pid2PG1.TabIndex = 49;
            this.pid2PG1.Text = "0";
            // 
            // pid2LimitAmpG1
            // 
            this.pid2LimitAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2LimitAmpG1.Location = new System.Drawing.Point(194, 64);
            this.pid2LimitAmpG1.Name = "pid2LimitAmpG1";
            this.pid2LimitAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid2LimitAmpG1.TabIndex = 48;
            this.pid2LimitAmpG1.Text = "0";
            // 
            // pid2MiddleAmpG1
            // 
            this.pid2MiddleAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2MiddleAmpG1.Location = new System.Drawing.Point(149, 64);
            this.pid2MiddleAmpG1.Name = "pid2MiddleAmpG1";
            this.pid2MiddleAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid2MiddleAmpG1.TabIndex = 47;
            this.pid2MiddleAmpG1.Text = "0";
            // 
            // pid2LockAmpG1
            // 
            this.pid2LockAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2LockAmpG1.Location = new System.Drawing.Point(105, 64);
            this.pid2LockAmpG1.Name = "pid2LockAmpG1";
            this.pid2LockAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid2LockAmpG1.TabIndex = 46;
            this.pid2LockAmpG1.Text = "0";
            // 
            // pid1DG1
            // 
            this.pid1DG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1DG1.Location = new System.Drawing.Point(329, 31);
            this.pid1DG1.Name = "pid1DG1";
            this.pid1DG1.Size = new System.Drawing.Size(39, 23);
            this.pid1DG1.TabIndex = 9;
            this.pid1DG1.Text = "0";
            // 
            // pid1IG1
            // 
            this.pid1IG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1IG1.Location = new System.Drawing.Point(284, 31);
            this.pid1IG1.Name = "pid1IG1";
            this.pid1IG1.Size = new System.Drawing.Size(39, 23);
            this.pid1IG1.TabIndex = 8;
            this.pid1IG1.Text = "0";
            // 
            // pid1PG1
            // 
            this.pid1PG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1PG1.Location = new System.Drawing.Point(239, 31);
            this.pid1PG1.Name = "pid1PG1";
            this.pid1PG1.Size = new System.Drawing.Size(39, 23);
            this.pid1PG1.TabIndex = 7;
            this.pid1PG1.Text = "0";
            // 
            // pid1LimitAmpG1
            // 
            this.pid1LimitAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1LimitAmpG1.Location = new System.Drawing.Point(194, 31);
            this.pid1LimitAmpG1.Name = "pid1LimitAmpG1";
            this.pid1LimitAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid1LimitAmpG1.TabIndex = 6;
            this.pid1LimitAmpG1.Text = "0";
            // 
            // pid1MiddleAmpG1
            // 
            this.pid1MiddleAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1MiddleAmpG1.Location = new System.Drawing.Point(149, 31);
            this.pid1MiddleAmpG1.Name = "pid1MiddleAmpG1";
            this.pid1MiddleAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid1MiddleAmpG1.TabIndex = 5;
            this.pid1MiddleAmpG1.Text = "0";
            // 
            // pid1LockAmpG1
            // 
            this.pid1LockAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1LockAmpG1.Location = new System.Drawing.Point(105, 31);
            this.pid1LockAmpG1.Name = "pid1LockAmpG1";
            this.pid1LockAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid1LockAmpG1.TabIndex = 4;
            this.pid1LockAmpG1.Text = "0";
            // 
            // Openloop_BC_textBox
            // 
            this.Openloop_BC_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Openloop_BC_textBox.Location = new System.Drawing.Point(39, 130);
            this.Openloop_BC_textBox.Name = "Openloop_BC_textBox";
            this.Openloop_BC_textBox.Size = new System.Drawing.Size(39, 26);
            this.Openloop_BC_textBox.TabIndex = 1;
            this.Openloop_BC_textBox.Text = "0";
            // 
            // Openloop_BS_textBox
            // 
            this.Openloop_BS_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Openloop_BS_textBox.Location = new System.Drawing.Point(39, 97);
            this.Openloop_BS_textBox.Name = "Openloop_BS_textBox";
            this.Openloop_BS_textBox.Size = new System.Drawing.Size(39, 26);
            this.Openloop_BS_textBox.TabIndex = 1;
            this.Openloop_BS_textBox.Text = "0";
            // 
            // Openloop_AC_textBox
            // 
            this.Openloop_AC_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Openloop_AC_textBox.Location = new System.Drawing.Point(39, 64);
            this.Openloop_AC_textBox.Name = "Openloop_AC_textBox";
            this.Openloop_AC_textBox.Size = new System.Drawing.Size(39, 26);
            this.Openloop_AC_textBox.TabIndex = 1;
            this.Openloop_AC_textBox.Text = "0";
            // 
            // Openloop_AS_textBox
            // 
            this.Openloop_AS_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Openloop_AS_textBox.Location = new System.Drawing.Point(39, 31);
            this.Openloop_AS_textBox.Name = "Openloop_AS_textBox";
            this.Openloop_AS_textBox.Size = new System.Drawing.Size(39, 26);
            this.Openloop_AS_textBox.TabIndex = 1;
            this.Openloop_AS_textBox.Text = "0";
            // 
            // label191
            // 
            this.label191.AutoSize = true;
            this.label191.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label191.Location = new System.Drawing.Point(253, 186);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(53, 12);
            this.label191.TabIndex = 78;
            this.label191.Text = "输出幅值";
            // 
            // label192
            // 
            this.label192.AutoSize = true;
            this.label192.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label192.Location = new System.Drawing.Point(95, 188);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(53, 12);
            this.label192.TabIndex = 79;
            this.label192.Text = "幅值误差";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(199, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 24);
            this.label16.TabIndex = 75;
            this.label16.Text = "稳幅\r\n限幅";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(151, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 24);
            this.label15.TabIndex = 74;
            this.label15.Text = "中心\r\n幅值";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(109, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 24);
            this.label14.TabIndex = 73;
            this.label14.Text = "锁定\r\n幅值";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(339, 12);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 16);
            this.label12.TabIndex = 72;
            this.label12.Text = "D";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(296, 12);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 16);
            this.label11.TabIndex = 71;
            this.label11.Text = "I";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(249, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 16);
            this.label10.TabIndex = 70;
            this.label10.Text = "P";
            // 
            // G1_pid4_button
            // 
            this.G1_pid4_button.BackColor = System.Drawing.SystemColors.Window;
            this.G1_pid4_button.Location = new System.Drawing.Point(377, 140);
            this.G1_pid4_button.Name = "G1_pid4_button";
            this.G1_pid4_button.Size = new System.Drawing.Size(22, 17);
            this.G1_pid4_button.TabIndex = 69;
            this.G1_pid4_button.UseVisualStyleBackColor = false;
            this.G1_pid4_button.Click += new System.EventHandler(this.G1_pid4_button_Click);
            // 
            // pid4EnableG1
            // 
            this.pid4EnableG1.BackColor = System.Drawing.Color.Red;
            this.pid4EnableG1.Location = new System.Drawing.Point(82, 140);
            this.pid4EnableG1.Name = "pid4EnableG1";
            this.pid4EnableG1.Size = new System.Drawing.Size(22, 17);
            this.pid4EnableG1.TabIndex = 68;
            this.pid4EnableG1.UseVisualStyleBackColor = false;
            this.pid4EnableG1.Click += new System.EventHandler(this.pid4EnableG1_Click);
            // 
            // G1_pid3_button
            // 
            this.G1_pid3_button.BackColor = System.Drawing.SystemColors.Window;
            this.G1_pid3_button.Location = new System.Drawing.Point(377, 107);
            this.G1_pid3_button.Name = "G1_pid3_button";
            this.G1_pid3_button.Size = new System.Drawing.Size(22, 17);
            this.G1_pid3_button.TabIndex = 61;
            this.G1_pid3_button.UseVisualStyleBackColor = false;
            this.G1_pid3_button.Click += new System.EventHandler(this.G1_pid3_button_Click);
            // 
            // pid3EnableG1
            // 
            this.pid3EnableG1.BackColor = System.Drawing.Color.Red;
            this.pid3EnableG1.Location = new System.Drawing.Point(82, 107);
            this.pid3EnableG1.Name = "pid3EnableG1";
            this.pid3EnableG1.Size = new System.Drawing.Size(22, 17);
            this.pid3EnableG1.TabIndex = 60;
            this.pid3EnableG1.UseVisualStyleBackColor = false;
            this.pid3EnableG1.Click += new System.EventHandler(this.pid3EnableG1_Click);
            // 
            // G1_pid2_button
            // 
            this.G1_pid2_button.BackColor = System.Drawing.SystemColors.Window;
            this.G1_pid2_button.Location = new System.Drawing.Point(377, 74);
            this.G1_pid2_button.Name = "G1_pid2_button";
            this.G1_pid2_button.Size = new System.Drawing.Size(22, 17);
            this.G1_pid2_button.TabIndex = 53;
            this.G1_pid2_button.UseVisualStyleBackColor = false;
            this.G1_pid2_button.Click += new System.EventHandler(this.G1_pid2_button_Click);
            // 
            // pid2EnableG1
            // 
            this.pid2EnableG1.BackColor = System.Drawing.Color.Red;
            this.pid2EnableG1.Location = new System.Drawing.Point(82, 74);
            this.pid2EnableG1.Name = "pid2EnableG1";
            this.pid2EnableG1.Size = new System.Drawing.Size(22, 17);
            this.pid2EnableG1.TabIndex = 52;
            this.pid2EnableG1.UseVisualStyleBackColor = false;
            this.pid2EnableG1.Click += new System.EventHandler(this.pid2EnableG1_Click);
            // 
            // G1_pid1_button
            // 
            this.G1_pid1_button.BackColor = System.Drawing.SystemColors.Window;
            this.G1_pid1_button.Location = new System.Drawing.Point(377, 41);
            this.G1_pid1_button.Name = "G1_pid1_button";
            this.G1_pid1_button.Size = new System.Drawing.Size(22, 17);
            this.G1_pid1_button.TabIndex = 45;
            this.G1_pid1_button.UseVisualStyleBackColor = false;
            this.G1_pid1_button.Click += new System.EventHandler(this.G1_pid1_button_Click);
            // 
            // pid1EnableG1
            // 
            this.pid1EnableG1.BackColor = System.Drawing.Color.Red;
            this.pid1EnableG1.Location = new System.Drawing.Point(82, 41);
            this.pid1EnableG1.Name = "pid1EnableG1";
            this.pid1EnableG1.Size = new System.Drawing.Size(22, 17);
            this.pid1EnableG1.TabIndex = 44;
            this.pid1EnableG1.UseVisualStyleBackColor = false;
            this.pid1EnableG1.Click += new System.EventHandler(this.pid1EnableG1_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(45, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 16);
            this.label9.TabIndex = 3;
            this.label9.Text = "mV";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(6, 133);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 24);
            this.label8.TabIndex = 2;
            this.label8.Text = "G1DB\r\ncos";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(6, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 24);
            this.label7.TabIndex = 2;
            this.label7.Text = "G1DB\r\nsin";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(4, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 24);
            this.label6.TabIndex = 2;
            this.label6.Text = "G1DA\r\ncos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(4, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 24);
            this.label5.TabIndex = 2;
            this.label5.Text = "G1DA\r\nsin";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Location = new System.Drawing.Point(27, 319);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(423, 233);
            this.tabControl2.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1177, 761);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.label97);
            this.Controls.Add(this.label95);
            this.Controls.Add(this.label94);
            this.Controls.Add(this.label93);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tabControl3);
            this.Controls.Add(this.storage_button);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.textBox89);
            this.Controls.Add(this.button_switch);
            this.Controls.Add(this.port_list);
            this.Controls.Add(this.tabControl4);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label141);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.Resize += new System.EventHandler(this.Form1_AutoSizeChanged);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabControl3.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.tabControl4.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Button Delete_fre_button;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.CheckBox SB_IQ_AcheckBox;
        private System.Windows.Forms.CheckBox SA_IQ_AcheckBox;
        private System.Windows.Forms.CheckBox SB_IQ_QcheckBox;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.CheckBox SA_IQ_QcheckBox;
        private System.Windows.Forms.CheckBox SB_IQ_IcheckBox;
        private System.Windows.Forms.CheckBox SA_IQ_IcheckBox;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label123;
        private ScottPlot.FormsPlot plt1;
        private System.Windows.Forms.TabPage tabPage5;
        private ScottPlot.FormsPlot plt2;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox1;
        private ScottPlot.FormsPlot plt8;
        private ScottPlot.FormsPlot plt7;
        private ScottPlot.FormsPlot plt6;
        private ScottPlot.FormsPlot plt5;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.CheckBox checkBox11;
        private ScottPlot.FormsPlot plt10;
        private System.Windows.Forms.Button storage_button;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.Button button_switch;
        private System.Windows.Forms.ComboBox port_list;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox HV4_textBox;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox HV3_textBox;
        private System.Windows.Forms.TextBox HV2_textBox;
        private System.Windows.Forms.TextBox HV1_textBox;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox HV_SB_textBox;
        private System.Windows.Forms.TextBox HV_CB_textBox;
        private System.Windows.Forms.TextBox HV_SA_textBox;
        private System.Windows.Forms.TextBox HV_CA_textBox;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TextBox G1_wait_textBox;
        private System.Windows.Forms.TextBox G1_stepfre_textBox;
        private System.Windows.Forms.TextBox G1_lfre_textBox;
        private System.Windows.Forms.TextBox G1_hfre_textBox;
        private System.Windows.Forms.Button G1_scanfre_button;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.TextBox PLL_D_textBox;
        private System.Windows.Forms.TextBox PLL_relativeerror_textBox;
        private System.Windows.Forms.TextBox PLL_Nowphase_textBox;
        private System.Windows.Forms.TextBox PLL_Nowfre_textBox;
        private System.Windows.Forms.TextBox PLL_Lockpha_Limiteamp_textBox;
        private System.Windows.Forms.TextBox PLL_I_textBox;
        private System.Windows.Forms.TextBox PLL_P_textBox;
        private System.Windows.Forms.TextBox PLL_middlefre_textBox;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox PLL_Lockphase_textBox;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.Button G1_MISCbutton;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox G1_drivefre_textBox;
        private System.Windows.Forms.Button G1_drivefre_button;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Button G1_PLL_button;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button G1_HV_button;
        private System.Windows.Forms.Button button2;
        private ScottPlot.FormsPlot plt22;
        private ScottPlot.FormsPlot plt21;
        private System.Windows.Forms.Button openLoopEnableG1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button G1_dataLineEnable_button;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Button CMD_OPENLOOP_ACT_button;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.TextBox pidAmpOutputG1_textBox;
        private System.Windows.Forms.TextBox pidAmpErrorG1_textBox;
        private System.Windows.Forms.TextBox pid4DG1;
        private System.Windows.Forms.TextBox pid4IG1;
        private System.Windows.Forms.TextBox pid4PG1;
        private System.Windows.Forms.TextBox pid4LimitAmpG1;
        private System.Windows.Forms.TextBox pid4MiddleAmpG1;
        private System.Windows.Forms.TextBox pid4LockAmpG1;
        private System.Windows.Forms.TextBox pid3DG1;
        private System.Windows.Forms.TextBox pid3IG1;
        private System.Windows.Forms.TextBox pid3PG1;
        private System.Windows.Forms.TextBox pid3LimitAmpG1;
        private System.Windows.Forms.TextBox pid3MiddleAmpG1;
        private System.Windows.Forms.TextBox pid3LockAmpG1;
        private System.Windows.Forms.TextBox pid2DG1;
        private System.Windows.Forms.TextBox pid2IG1;
        private System.Windows.Forms.TextBox pid2PG1;
        private System.Windows.Forms.TextBox pid2LimitAmpG1;
        private System.Windows.Forms.TextBox pid2MiddleAmpG1;
        private System.Windows.Forms.TextBox pid2LockAmpG1;
        private System.Windows.Forms.TextBox pid1DG1;
        private System.Windows.Forms.TextBox pid1IG1;
        private System.Windows.Forms.TextBox pid1PG1;
        private System.Windows.Forms.TextBox pid1LimitAmpG1;
        private System.Windows.Forms.TextBox pid1MiddleAmpG1;
        private System.Windows.Forms.TextBox pid1LockAmpG1;
        private System.Windows.Forms.TextBox Openloop_BC_textBox;
        private System.Windows.Forms.TextBox Openloop_BS_textBox;
        private System.Windows.Forms.TextBox Openloop_AC_textBox;
        private System.Windows.Forms.TextBox Openloop_AS_textBox;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button G1_pid4_button;
        private System.Windows.Forms.Button pid4EnableG1;
        private System.Windows.Forms.Button G1_pid3_button;
        private System.Windows.Forms.Button pid3EnableG1;
        private System.Windows.Forms.Button G1_pid2_button;
        private System.Windows.Forms.Button pid2EnableG1;
        private System.Windows.Forms.Button G1_pid1_button;
        private System.Windows.Forms.Button pid1EnableG1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabControl tabControl2;
    }
}

