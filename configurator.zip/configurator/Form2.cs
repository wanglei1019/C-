﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ut64configurator
{
    public partial class  Form2 : Form1
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button26_Click(object sender, EventArgs e)
        {
            textBox89.Text = gyro1.getValue(Macro.RUNTIME_FIELD_MODESWITCH_DIFFERENCE_FREQUENCY).ToString("0.000") ;
        }
    }
}
