﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;
using System.IO.Ports;
using System.Collections;
using System.Net;
using System.Security.Cryptography;
using System.IO;
using ScottPlot.Plottable;
using ScottPlot;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ScottPlot.Renderable;

namespace ut64configurator
{
    public partial class Form1 : Form
    {
        byte flag=0;
        Thread thread_circle;

        internal Gyro gyro1;
        internal Gyro gyro2;
        GyroBuffer gyroBuffer1;
        GyroBuffer gyroBuffer2;
        Communication communication;
        EventTest Event = new EventTest();
        Paint gyroPaint1;
        Paint gyroPaint2;
        AutoSizeForm asc = new AutoSizeForm();


        ScatterPlotList<double> scatterChat11;
        ScatterPlotList<double> scatterChat21;
        ScatterPlotList<double> scatterChat31;
        ScatterPlotList<double> scatterChat41;
        ScatterPlotList<double> scatterChat12;
        ScatterPlotList<double> scatterChat22;
        ScatterPlotList<double> scatterChat32;
        ScatterPlotList<double> scatterChat42;
        VLine vLine11 = new VLine();
        HLine hLine12 = new HLine();
        VLine vLine21 = new VLine();
        HLine hLine22 = new HLine();
        VLine vLine31 = new VLine();
        HLine hLine32 = new HLine();
        VLine vLine41 = new VLine();
        HLine hLine42 = new HLine();


        ScatterPlotList<double> scatterChatPhaseAgcavg;
        double phaseagcAvgCountgyro1 = 0;
        double phaseagcAvgCountgyro2 = 0;

        double[] chatXs = { };
        double[] chatYs = { };
        double scanCountgyro1 = 0;
        double scanCountgyro2 = 0;


        //扫频中6个radiobutton的控制符
        bool rb1 = true;
        bool rb2 = true;
        bool rb3 = true;
        bool rb4 = true;
        bool rb5 = true;
        bool rb6 = true;

        //LED
        System.Timers.Timer timerLed;

        // dataSave
        System.Timers.Timer timerDataSave;
        //sendbuffer
        private byte [] sendBuffers = { 0, 0, 0x24, 0x3E, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x24 };
        

        //
        public Form1()
        {
            InitializeComponent();
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;
            //Init gyro data
            gyro1 = new Gyro();
            gyro2 = new Gyro();
            //初始化缓存区
            gyroBuffer1 = new GyroBuffer();
            gyroBuffer2 = new GyroBuffer();
            //初始化串口接收
            communication = new Communication(gyro1,gyroBuffer1, gyro2, gyroBuffer2, sendBuffers);

            port_list.Items.AddRange(communication.getSerialPortID());

            communication.createSerialPort();

            //初始化串口发送事件 保存事件
            Event.ChangeNumSendCmd += new EventTest.NumManipulationHandler(communication.sendCommand);
            Event.ChangeNumDataSaveStart += new EventTest.NumManipulationHandler(communication.dataSaveStart);
            Event.ChangeNumDataSaveStop += new EventTest.NumManipulationHandler(communication.dataSaveStop);
            Event.ChangeNumDataSaveEmpty += new EventTest.NumManipulationHandler(communication.emptySaveStr);
            //初始化陀螺绘图曲线

            gyroPaint1 = new Paint();
            Init_scanfre_line1();
            Init_IQ_line(ref gyroPaint1);
            Init_PLL_line(ref gyroPaint1);
            Init_PID_line(ref gyroPaint1);
            Init_EST_RESONANT_line(ref gyroPaint1);
            Init_phasefinder_line1();


            gyroPaint2 = new Paint();
            Init_scanfre_line2();
            Init_IQ_line2(ref gyroPaint2);
            Init_PLL_line2(ref gyroPaint2);
            Init_PID_line2(ref gyroPaint2);
            Init_EST_RESONANT_line2(ref gyroPaint2);

            InitTimerLed();
            InitTimerDataSave();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //初始化窗口自适应
            asc.controllInitializeSize(this);

        }


        
        private void Form1_Shown(object sender, EventArgs e)
        {
            //Gyro gyro1 = new Gyro();
            //thread_circle = new Thread(new ThreadStart(Circle));
            //thread_circle.Start();

           
            //gyro1.setValue(Macro.RUNTIME_FIELD_AMP_CHA_I, 2);

            //Communication communication = new Communication();
            //communication.createSerialPort();
            //EventTest send = new EventTest(); 
            //send.ChangeNum += new EventTest.NumManipulationHandler(communication.sendCommand);
            //send.setValue(1);
            //textBox1.AppendText(communication.getRecStatus().ToString() + "  ");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //thread_circle.Abort();
        }

        

        private void timer1_Tick(object sender, EventArgs e)
        {
            //string str = String.Join(" ", communication.getRecData());
            //textBox89.AppendText(str + "\r\n");
            //更新数据
            upDataGyro1();
            upDataGyro2();

            
            


            //陀螺1绘图
            switch (tabControl3.SelectedIndex)
            {
                case 0:
                    Render.repaintIQ(ref plt1, ref gyroPaint1.SA_IQ_checkboxs, ref gyroPaint1.SA_IQ_lines, 1);
                    Render.repaintIQ(ref plt2, ref gyroPaint1.SB_IQ_checkboxs, ref gyroPaint1.SB_IQ_lines, 1);
                    break;
                case 1:
                    if(scanCountgyro1 != gyro1.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY))
                    {
                        
                        scatterChat11.Add(Convert.ToDouble(gyro1.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY).ToString("0.00")), gyro1.getValue(Macro.RUNTIME_FIELD_AMP_SCAN_CHA));
                        scatterChat12.Add(Convert.ToDouble(gyro1.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY).ToString("0.00")), gyro1.getValue(Macro.RUNTIME_FIELD_AMP_SCAN_CHB));

                        scatterChat21.Add(Convert.ToDouble(gyro1.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY).ToString("0.00")), gyro1.getValue(Macro.RUNTIME_FIELD_PHASE_A));
                        scatterChat22.Add(Convert.ToDouble(gyro1.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY).ToString("0.00")), gyro1.getValue(Macro.RUNTIME_FIELD_PHASE_B));
                        scanCountgyro1 = gyro1.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY);

                        plt21.Plot.AxisAuto();
                        plt22.Plot.AxisAuto();
                        plt21.Refresh();
                        plt22.Refresh();
                    }
                    break;
                case 2:
                    Render.repaintTwo(ref plt5, ref gyroPaint1.PLL_Amp_checkboxs, ref gyroPaint1.PLL_Amp_lines, 1);
                    Render.repaintOne(ref plt8, ref gyroPaint1.PLL_Phase_checkbox, ref gyroPaint1.PLL_Phase_lines, 1);
                    Render.repaintIQ(ref plt6, ref gyroPaint1.PLL_SA_IQ_checkboxs, ref gyroPaint1.PLL_SA_IQ_lines, 1);
                    Render.repaintIQ(ref plt7, ref gyroPaint1.PLL_SB_IQ_checkboxs, ref gyroPaint1.PLL_SB_IQ_lines, 1);
                    break;
                case 3:
                    Render.repaintTwo(ref plt10, ref gyroPaint1.PID_checkboxs, ref gyroPaint1.PID_lines, 1);
                    break;
                case 4:
                    Render.repaintOne(ref plt31, ref gyroPaint1.Fre_resonant_checkbox, ref gyroPaint1.Fre_resonant_line, 1);
                    Render.repaintOne(ref plt32, ref gyroPaint1.AGC_min_output_checkbox, ref gyroPaint1.AGC_min_output_line, 1);
                    break;
                case 5:
                    if (phaseagcAvgCountgyro1 != gyro1.getValue(Macro.RUNTIME_FIELD_PHASE_FINDER_SET_PHASE))
                    {

                        scatterChatPhaseAgcavg.Add(Convert.ToDouble(gyro1.getValue(Macro.RUNTIME_FIELD_PHASE_FINDER_SET_PHASE).ToString("0.00")), gyro1.getValue(Macro.RUNTIME_FIELD_PHASE_FINDER_AGCAVG));
                        
                      
                        scanCountgyro1 = gyro1.getValue(Macro.RUNTIME_FIELD_PHASE_FINDER_SET_PHASE);

                        pltphasefinder1.Plot.AxisAuto();

                        pltphasefinder1.Refresh();
                 
                    }
                    break;
                default:
                    break;
            }

            //陀螺2绘图
            switch (tabControl5.SelectedIndex)
            {
                case 0:
                    Render.repaintIQ(ref plt11, ref gyroPaint2.SA_IQ_checkboxs, ref gyroPaint2.SA_IQ_lines, 1);
                    Render.repaintIQ(ref plt12, ref gyroPaint2.SB_IQ_checkboxs, ref gyroPaint2.SB_IQ_lines, 1);
                    break;
                case 1:
                    if (scanCountgyro2 != gyro2.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY))
                    {
                       
                        scatterChat31.Add(Convert.ToDouble(gyro2.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY).ToString("0.00")), gyro2.getValue(Macro.RUNTIME_FIELD_AMP_SCAN_CHA));
                        scatterChat32.Add(Convert.ToDouble(gyro2.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY).ToString("0.00")), gyro2.getValue(Macro.RUNTIME_FIELD_AMP_SCAN_CHB));

                        scatterChat41.Add(Convert.ToDouble(gyro2.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY).ToString("0.00")), gyro2.getValue(Macro.RUNTIME_FIELD_PHASE_A));
                        scatterChat42.Add(Convert.ToDouble(gyro2.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY).ToString("0.00")), gyro2.getValue(Macro.RUNTIME_FIELD_PHASE_B));

                        plt23.Plot.AxisAuto();
                        plt24.Plot.AxisAuto();
                        plt23.Refresh();
                        plt24.Refresh();
                        scanCountgyro2 = gyro2.getValue(Macro.RUNTIME_FIELD_CURRENT_FREQUENCY);
                    }
                    
                    break;
                case 2:
                    Render.repaintTwo(ref plt15, ref gyroPaint2.PLL_Amp_checkboxs, ref gyroPaint2.PLL_Amp_lines, 1);
                    Render.repaintOne(ref plt18, ref gyroPaint2.PLL_Phase_checkbox, ref gyroPaint2.PLL_Phase_lines, 1);
                    Render.repaintIQ(ref plt16, ref gyroPaint2.PLL_SA_IQ_checkboxs, ref gyroPaint2.PLL_SA_IQ_lines, 1);
                    Render.repaintIQ(ref plt17, ref gyroPaint2.PLL_SB_IQ_checkboxs, ref gyroPaint2.PLL_SB_IQ_lines, 1);
                    break;
                case 3:
                    Render.repaintTwo(ref plt20, ref gyroPaint2.PID_checkboxs, ref gyroPaint2.PID_lines, 1);
                    break;
                case 4:
                    Render.repaintOne(ref plt33, ref gyroPaint2.Fre_resonant_checkbox, ref gyroPaint2.Fre_resonant_line, 1);
                    Render.repaintOne(ref plt34, ref gyroPaint2.AGC_min_output_checkbox, ref gyroPaint2.AGC_min_output_line, 1);
                    break;
                default:
                    break;
            }
        }

        private void Circle()
        {
            //Gyro gyro = new Gyro();
            //Communication communication = new Communication();
            //communication.createSerialPort();
            //while (true)
            //{
            //    if (flag == 1)
            //    {
            //        flag = 0;
            //        gyro.setValue(Macro.RUNTIME_FIELD_AMP_CHA_I, 2);
            //        textBox1.AppendText(gyro.getValue(Macro.RUNTIME_FIELD_AMP_CHA_I).ToString() + "  ");
            //    }

            //}
        }

        private void button_switch_Click(object sender, EventArgs e)
        {
            try
            {
                if (button_switch.Text == "START")
                {
                    //button_switch.BackColor = Color.Red;
                    communication.clearSerialRevList();
                    button_switch.Text = "STOP";
                    communication.setSerialPortName(port_list.Text);
                    communication .openSerialPort();
          
                    timer1.Start();
                }
                else
                {
                    //button_switch.BackColor = Color.Green; 
                    communication.clearSerialRevList();
                    button_switch.Text = "START";
                    communication .closeSerialPort();
                    timer1.Stop();
                }
            }
            catch
            {
                MessageBox.Show("端口错误,请检查串口", "错误");
                //button_switch.BackColor = Color.Green;
                if (button_switch.Text == "START")
                    button_switch.Text = "STOP";
                else
                    button_switch.Text = "START";
            }
        }

        private void Form1_AutoSizeChanged(object sender, EventArgs e)
        {
            asc.controlAutoSize(this);
        }

        private void InitTimerLed()
        {
            int interval = 500;
            timerLed = new System.Timers.Timer(interval);
            timerLed.Interval = interval;
            timerLed.AutoReset = true;
            timerLed.Enabled = true;
            timerLed.Elapsed += new System.Timers.ElapsedEventHandler(TimesUp);
        }
        private void TimesUp(object sender, System.Timers.ElapsedEventArgs e)
        {
            switch (communication.getDatatypeG1())
            {
                case 0:
                    openLoopLedG1.BackColor = Color.Green;
                    sweepLedG1.BackColor = Color.Red;
                    pllLedG1.BackColor = Color.Red;
                    break;
                case 1:
                    openLoopLedG1.BackColor = Color.Red;
                    sweepLedG1.BackColor = Color.Green;
                    pllLedG1.BackColor = Color.Red;
                    break;
                case 2:
                    openLoopLedG1.BackColor = Color.Red;
                    sweepLedG1.BackColor = Color.Red;
                    pllLedG1.BackColor = Color.Green;
                    break;
                case 3:
                    break;
                default:
                    break;
            }

            switch (communication.getDatatypeG2())
            {
                case 0:
                    openLoopLedG2.BackColor = Color.Green;
                    sweepLedG2.BackColor = Color.Red;
                    pllLedG2.BackColor = Color.Red;
                    break;
                case 1:
                    openLoopLedG2.BackColor = Color.Red;
                    sweepLedG2.BackColor = Color.Green;
                    pllLedG2.BackColor = Color.Red;
                    break;
                case 2:
                    openLoopLedG2.BackColor = Color.Red;
                    sweepLedG2.BackColor = Color.Red;
                    pllLedG2.BackColor = Color.Green;
                    break;
                case 3:
                    break;
                default:
                    break;
            }

        }

        private void InitTimerDataSave()
        {
            int interval = 1500;
            timerDataSave = new System.Timers.Timer(interval);
            timerDataSave.Interval = interval;
            timerDataSave.AutoReset = true;
            timerDataSave.Enabled = false;
            timerDataSave.Elapsed += new System.Timers.ElapsedEventHandler(TimesDataSaveUp);
        }
        private void TimesDataSaveUp(object sender, System.Timers.ElapsedEventArgs e)
        {
            storage_str = communication.getDataSaveStr();
            StreamWriter streamWriter = new StreamWriter(saveFileDialog.FileName, append: true);
            streamWriter.Write(storage_str);
            streamWriter.Close();
            storage_str = String.Empty;
            Event.setValue(4);
        }



        //曲线初始化函数1
        private void Init_IQ_line(ref Paint gyroPaint)
        {
            //按钮选择数组
            gyroPaint.SA_IQ_checkboxs[0] = SA_IQ_IcheckBox;
            gyroPaint.SA_IQ_checkboxs[1] = SA_IQ_QcheckBox;
            gyroPaint.SA_IQ_checkboxs[2] = SA_IQ_AcheckBox;

            gyroPaint.SB_IQ_checkboxs[0] = SB_IQ_IcheckBox;
            gyroPaint.SB_IQ_checkboxs[1] = SB_IQ_QcheckBox;
            gyroPaint.SB_IQ_checkboxs[2] = SB_IQ_AcheckBox;

            gyroPaint.SA_IQ_lines[0] = plt1.Plot.AddSignal(gyroPaint.IA_array);
            gyroPaint.SA_IQ_lines[1] = plt1.Plot.AddSignal(gyroPaint.QA_array);
            gyroPaint.SA_IQ_lines[2] = plt1.Plot.AddSignal(gyroPaint.AMPA_array);
            plt1.Render();
            gyroPaint.SB_IQ_lines[0] = plt2.Plot.AddSignal(gyroPaint.IB_array);
            gyroPaint.SB_IQ_lines[1] = plt2.Plot.AddSignal(gyroPaint.QB_array);
            gyroPaint.SB_IQ_lines[2] = plt2.Plot.AddSignal(gyroPaint.AMPB_array);
            plt2.Render();
            plt1.Plot.XLabel("时间");
            plt1.Plot.YLabel("幅值mV");
            plt2.Plot.XLabel("时间");
            plt2.Plot.YLabel("幅值mV");
            plt1.Plot.AxisAuto();
            plt2.Plot.AxisAuto();
        }
        private void Init_scanfre_line1()
        {
            scatterChat11 = plt21.Plot.AddScatterList(markerSize: 1);
            //scatterChat11.AddRange(chatXs,chatYs);
            scatterChat21 = plt22.Plot.AddScatterList(markerSize:1);
            //scatterChat21.AddRange(chatXs, chatYs);
            scatterChat12 = plt21.Plot.AddScatterList(markerSize: 1);
            //scatterChat12.AddRange(chatXs, chatYs);
            scatterChat22 = plt22.Plot.AddScatterList(markerSize: 1);
            //scatterChat22.AddRange(chatXs, chatYs);
            
            plt21.Refresh();
            plt22.Refresh();

        }

        private void Init_phasefinder_line1()
        {
            scatterChatPhaseAgcavg = pltphasefinder1.Plot.AddScatterList(markerSize: 1);
            pltphasefinder1.Refresh();
           

        }

        private void Init_XY_lineEnable()
        {
            vLine11 = plt21.Plot.AddVerticalLine(((Convert.ToDouble(G1_hfre_textBox.Text))+ (Convert.ToDouble(G1_lfre_textBox.Text)))/2.0);
            vLine21 = plt22.Plot.AddVerticalLine(((Convert.ToDouble(G1_hfre_textBox.Text)) + (Convert.ToDouble(G1_lfre_textBox.Text))) / 2.0);
            hLine12 = plt21.Plot.AddHorizontalLine(0);
            hLine22 = plt22.Plot.AddHorizontalLine(0);
            vLine11.DragEnabled = true;
            vLine21.DragEnabled = true;
            hLine12.DragEnabled = true;
            hLine22.DragEnabled = true;
            plt21.Plot.AxisAuto();
            plt22.Plot.AxisAuto();
            plt21.Refresh();
            plt22.Refresh();
        }

        private void Init_XY_linesEnable2()
        {
            vLine31 = plt23.Plot.AddVerticalLine(((Convert.ToDouble(G2_hfre_textBox.Text)) + (Convert.ToDouble(G2_lfre_textBox.Text))) / 2.0);
            vLine41 = plt24.Plot.AddVerticalLine(((Convert.ToDouble(G2_hfre_textBox.Text)) + (Convert.ToDouble(G2_lfre_textBox.Text))) / 2.0);
            hLine32 = plt23.Plot.AddHorizontalLine(0);
            hLine42 = plt24.Plot.AddHorizontalLine(0);
            vLine31.DragEnabled = true;
            vLine41.DragEnabled = true;
            hLine32.DragEnabled = true;
            hLine42.DragEnabled = true;
            plt23.Plot.AxisAuto();
            plt24.Plot.AxisAuto();
            plt23.Refresh();
            plt24.Refresh();
        }

        private void Init_XY_lineDisable()
        {

            plt21.Plot.Remove(vLine11);
            plt22.Plot.Remove(vLine21);
            plt21.Plot.Remove(hLine12);
            plt22.Plot.Remove(hLine22);
            plt21.Refresh();
            plt22.Refresh();


        }

        private void Init_XY_linesDisable2()
        {
            plt23.Plot.Remove(vLine31);
            plt24.Plot.Remove(vLine41);
            plt23.Plot.Remove(hLine32);
            plt24.Plot.Remove(hLine42);
            plt23.Refresh();
            plt24.Refresh();
        
        }


        private void Init_scanfre_line2()
        {
            scatterChat31 = plt23.Plot.AddScatterList(markerSize: 1);
            //scatterChat31.AddRange(chatXs, chatYs);
            scatterChat41 = plt24.Plot.AddScatterList(markerSize: 1);
            //scatterChat41.AddRange(chatXs, chatYs);

            scatterChat32 = plt23.Plot.AddScatterList(markerSize: 1);
            //scatterChat32.AddRange(chatXs, chatYs);
            scatterChat42 = plt24.Plot.AddScatterList(markerSize: 1);
            //scatterChat42.AddRange(chatXs, chatYs);
            
            plt23.Refresh();
            plt24.Refresh();

        }
        private void Init_PLL_line(ref Paint gyroPaint)
        {
            //按钮选择数组
            gyroPaint.PLL_Amp_checkboxs[0] = checkBox1;
            gyroPaint.PLL_Amp_checkboxs[1] = checkBox2;

            gyroPaint.PLL_Phase_checkbox = checkBox9;

            gyroPaint.PLL_SA_IQ_checkboxs[0] = checkBox3;
            gyroPaint.PLL_SA_IQ_checkboxs[1] = checkBox4;
            gyroPaint.PLL_SA_IQ_checkboxs[2] = checkBox5;

            gyroPaint.PLL_SB_IQ_checkboxs[0] = checkBox6;
            gyroPaint.PLL_SB_IQ_checkboxs[1] = checkBox7;
            gyroPaint.PLL_SB_IQ_checkboxs[2] = checkBox8;

            gyroPaint.PLL_SA_IQ_lines[0] = plt6.Plot.AddSignal(gyroPaint.IA_array);
            gyroPaint.PLL_SA_IQ_lines[1] = plt6.Plot.AddSignal(gyroPaint.QA_array);
            gyroPaint.PLL_SA_IQ_lines[2] = plt6.Plot.AddSignal(gyroPaint.AMPA_array);
            plt6.Render();
            gyroPaint.PLL_SB_IQ_lines[0] = plt7.Plot.AddSignal(gyroPaint.IB_array);
            gyroPaint.PLL_SB_IQ_lines[1] = plt7.Plot.AddSignal(gyroPaint.QB_array);
            gyroPaint.PLL_SB_IQ_lines[2] = plt7.Plot.AddSignal(gyroPaint.AMPB_array);
            plt7.Render();
            plt6.Plot.XLabel("时间");
            plt6.Plot.YLabel("幅值mV");
            plt7.Plot.XLabel("时间");
            plt7.Plot.YLabel("幅值mV");
            plt6.Plot.AxisAuto();
            plt7.Plot.AxisAuto();

            gyroPaint.PLL_Amp_lines[0] = plt5.Plot.AddSignal(gyroPaint.PLL_current_error_array);
            gyroPaint.PLL_Amp_lines[1] = plt5.Plot.AddSignal(gyroPaint.PLL_current_fre_array);
            plt5.Render();

            gyroPaint.PLL_Phase_lines = plt8.Plot.AddSignal(gyroPaint.PLL_current_phase_array);
            plt8.Render();

            plt5.Plot.XLabel("时间");
            // plt5.Plot.YLabel("幅值mV");
            plt8.Plot.XLabel("时间");
            //plt8.Plot.YLabel("幅值mV");
            plt8.Plot.AxisAuto();
            plt8.Plot.AxisAuto();
        }

        
        private void Init_PID_line(ref Paint gyroPaint)
        {
            //按钮选择数组
            //gyroPaint.AGC_Amp_checkbox = checkBox10;

            //gyroPaint.AGC_error_Amp_line = plt10.Plot.AddSignal(gyroPaint.AGC_error_Amp_array);
            gyroPaint.PID_checkboxs[0] = checkBox11;
            gyroPaint.PID_checkboxs[1] = checkBox33;
            gyroPaint.PID_lines[0] = plt10.Plot.AddSignal(gyroPaint.PID_out_Amp_array);
            gyroPaint.PID_lines[1] = plt10.Plot.AddSignal(gyroPaint.PID_error_Amp_array);

            plt10.Render();

            plt10.Plot.XLabel("时间");
            plt10.Plot.YLabel("幅值mV");

            plt10.Plot.AxisAuto();
        }
        private void Init_PID_line2(ref Paint gyroPaint)
        {
            //按钮选择数组
            gyroPaint.PID_checkboxs[0] = checkBox32;
            gyroPaint.PID_checkboxs[1] = checkBox34;
            gyroPaint.PID_lines[0] = plt20.Plot.AddSignal(gyroPaint.PID_out_Amp_array);
            gyroPaint.PID_lines[1] = plt20.Plot.AddSignal(gyroPaint.PID_error_Amp_array);

            plt20.Render();

            plt20.Plot.XLabel("时间");
            plt20.Plot.YLabel("幅值mV");

            plt20.Plot.AxisAuto();
        }


        //曲线初始化函数通道2
        private void Init_IQ_line2(ref Paint gyroPaint)
        {
            //按钮选择数组
            gyroPaint.SA_IQ_checkboxs[0] = checkBox12;
            gyroPaint.SA_IQ_checkboxs[1] = checkBox13;
            gyroPaint.SA_IQ_checkboxs[2] = checkBox14;

            gyroPaint.SB_IQ_checkboxs[0] = checkBox15;
            gyroPaint.SB_IQ_checkboxs[1] = checkBox16;
            gyroPaint.SB_IQ_checkboxs[2] = checkBox17;

            gyroPaint.SA_IQ_lines[0] = plt11.Plot.AddSignal(gyroPaint.IA_array);
            gyroPaint.SA_IQ_lines[1] = plt11.Plot.AddSignal(gyroPaint.QA_array);
            gyroPaint.SA_IQ_lines[2] = plt11.Plot.AddSignal(gyroPaint.AMPA_array);
            plt11.Render();
            gyroPaint.SB_IQ_lines[0] = plt12.Plot.AddSignal(gyroPaint.IB_array);
            gyroPaint.SB_IQ_lines[1] = plt12.Plot.AddSignal(gyroPaint.QB_array);
            gyroPaint.SB_IQ_lines[2] = plt12.Plot.AddSignal(gyroPaint.AMPB_array);
            plt12.Render();
            plt11.Plot.XLabel("时间");
            plt11.Plot.YLabel("幅值mV");
            plt12.Plot.XLabel("时间");
            plt12.Plot.YLabel("幅值mV");
            plt11.Plot.AxisAuto();
            plt12.Plot.AxisAuto();
        }
    

        private void Init_PLL_line2(ref Paint gyroPaint)
        {
            //按钮选择数组
            gyroPaint.PLL_Amp_checkboxs[0] = checkBox22;
            gyroPaint.PLL_Amp_checkboxs[1] = checkBox23;

            gyroPaint.PLL_Phase_checkbox = checkBox30;

            gyroPaint.PLL_SA_IQ_checkboxs[0] = checkBox24;
            gyroPaint.PLL_SA_IQ_checkboxs[1] = checkBox25;
            gyroPaint.PLL_SA_IQ_checkboxs[2] = checkBox26;

            gyroPaint.PLL_SB_IQ_checkboxs[0] = checkBox27;
            gyroPaint.PLL_SB_IQ_checkboxs[1] = checkBox28;
            gyroPaint.PLL_SB_IQ_checkboxs[2] = checkBox29;

            gyroPaint.PLL_SA_IQ_lines[0] = plt16.Plot.AddSignal(gyroPaint.IA_array);
            gyroPaint.PLL_SA_IQ_lines[1] = plt16.Plot.AddSignal(gyroPaint.QA_array);
            gyroPaint.PLL_SA_IQ_lines[2] = plt16.Plot.AddSignal(gyroPaint.AMPA_array);
            plt16.Render();
            gyroPaint.PLL_SB_IQ_lines[0] = plt17.Plot.AddSignal(gyroPaint.IB_array);
            gyroPaint.PLL_SB_IQ_lines[1] = plt17.Plot.AddSignal(gyroPaint.QB_array);
            gyroPaint.PLL_SB_IQ_lines[2] = plt17.Plot.AddSignal(gyroPaint.AMPB_array);
            plt17.Render();
            plt16.Plot.XLabel("时间");
            plt16.Plot.YLabel("幅值mV");
            plt17.Plot.XLabel("时间");
            plt17.Plot.YLabel("幅值mV");
            plt16.Plot.AxisAuto();
            plt17.Plot.AxisAuto();

            gyroPaint.PLL_Amp_lines[0] = plt15.Plot.AddSignal(gyroPaint.PLL_current_error_array);
            gyroPaint.PLL_Amp_lines[1] = plt15.Plot.AddSignal(gyroPaint.PLL_current_fre_array);
            plt15.Render();

            gyroPaint.PLL_Phase_lines = plt18.Plot.AddSignal(gyroPaint.PLL_current_phase_array);
            plt18.Render();

            plt15.Plot.XLabel("时间");
            // plt5.Plot.YLabel("幅值mV");
            plt18.Plot.XLabel("时间");
            //plt8.Plot.YLabel("幅值mV");
            plt18.Plot.AxisAuto();
            plt18.Plot.AxisAuto();
        }

        private void Init_EST_RESONANT_line(ref Paint gyroPaint)
        {
            //按钮选择数组
            gyroPaint.Fre_resonant_checkbox = checkBox10;
            gyroPaint.AGC_min_output_checkbox = checkBox31;
            gyroPaint.Fre_resonant_line = plt31.Plot.AddSignal(gyroPaint.Fre_resonant_array);
            gyroPaint.AGC_min_output_line = plt32.Plot.AddSignal(gyroPaint.AGC_min_output_array);
            plt31.Render();
            plt32.Render();
            plt31.Plot.XLabel("时间");
            plt32.Plot.XLabel("时间");
            plt31.Plot.AxisAuto();
            plt32.Plot.AxisAuto();
        }

      

        private void Init_EST_RESONANT_line2(ref Paint gyroPaint)
        {
            //按钮选择数组

            gyroPaint.Fre_resonant_checkbox = checkBox35;
            gyroPaint.AGC_min_output_checkbox = checkBox36;
            gyroPaint.Fre_resonant_line = plt33.Plot.AddSignal(gyroPaint.Fre_resonant_array);
            gyroPaint.AGC_min_output_line = plt34.Plot.AddSignal(gyroPaint.AGC_min_output_array);
            plt33.Render();
            plt34.Render();
            plt33.Plot.XLabel("时间");
            plt34.Plot.XLabel("时间");
            plt33.Plot.AxisAuto();
            plt34.Plot.AxisAuto();
        }



        private void upDataGyro1()
        {
            gyroBuffer1.getValue(Macro.RUNTIME_FIELD_AMP_CHA_I).CopyTo(gyroPaint1.IA_array, 0);
            gyroBuffer1.getValue(Macro.RUNTIME_FIELD_AMP_CHA_Q).CopyTo(gyroPaint1.QA_array, 0);
            gyroBuffer1.getValue(Macro.RUNTIME_FIELD_AMP_CHA).CopyTo(gyroPaint1.AMPA_array, 0);
            gyroBuffer1.getValue(Macro.RUNTIME_FIELD_AMP_CHB_I).CopyTo(gyroPaint1.IB_array, 0);
            gyroBuffer1.getValue(Macro.RUNTIME_FIELD_AMP_CHB_Q).CopyTo(gyroPaint1.QB_array, 0);
            gyroBuffer1.getValue(Macro.RUNTIME_FIELD_AMP_CHB).CopyTo(gyroPaint1.AMPB_array, 0);
            switch(communication.getDatatypeG1())
            {
                case 1:
                    
                    break;
                case 2:
                    gyroBuffer1.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_FRE).CopyTo(gyroPaint1.PLL_current_fre_array, 0);
                    gyroBuffer1.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_PHASE).CopyTo(gyroPaint1.PLL_current_phase_array, 0);
                    gyroBuffer1.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_ERROR).CopyTo(gyroPaint1.PLL_current_error_array, 0);
                    PLL_Nowfre_textBox.Text = gyro1.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_FRE).ToString("0.000");
                    PLL_Nowphase_textBox.Text = gyro1.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_PHASE).ToString("0.000");
                    PLL_relativeerror_textBox.Text = gyro1.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_ERROR).ToString("0.000");
                    break;
                case 6:
                    gyroBuffer1.getValue(Macro.RUNTIME_PID_CURRENT_ERROR).CopyTo(gyroPaint1.PID_error_Amp_array, 0);
                    gyroBuffer1.getValue(Macro.RUNTIME_PID_CURRENT_OUTPUT).CopyTo(gyroPaint1.PID_out_Amp_array, 0);
                   
                    pidAmpErrorG1_textBox.Text = gyro1.getValue(Macro.RUNTIME_PID_CURRENT_ERROR).ToString("0.000");
                    pidAmpOutputG1_textBox.Text = gyro1.getValue(Macro.RUNTIME_PID_CURRENT_OUTPUT).ToString("0.000");
                    break;
                case 15:
                    qfactorStartFreG1_textBox.Text = gyro1.getValue(Macro.RUNTIME_FIELD_QFACTOR_START_FREQUENCY).ToString("0.000");
                    qfactorShortTauG1_textBox.Text = gyro1.getValue(Macro.RUNTIME_FIELD_QFACTOR_SHORT_TAU).ToString("0.000");
                    qfactorLongTauG1_textBox.Text = gyro1.getValue(Macro.RUNTIME_FIELD_QFACTOR_LONG_TAU).ToString("0.000");
                    qfactorMinG1_textBox.Text = gyro1.getValue(Macro.RUNTIME_FIELD_QFACTOR_MIN).ToString("0.000");
                    qfactorMaxG1_textBox.Text = gyro1.getValue(Macro.RUNTIME_FIELD_QFACTOR_MAX).ToString("0.000");
                    break;
                case 16:
                    gyroBuffer1.getValue(Macro.RUNTIME_FIELD_EST_RESONANT_FREQUENCY).CopyTo(gyroPaint1.Fre_resonant_array, 0);
                    gyroBuffer1.getValue(Macro.RUNTIME_FIELD_MIN_AGC_OUTPUT).CopyTo(gyroPaint1.AGC_min_output_array, 0);
                    freResonantG1_textBox.Text = gyro1.getValue(Macro.RUNTIME_FIELD_EST_RESONANT_FREQUENCY).ToString("0.000");
                    agcMinOutG1_textBox.Text = gyro1.getValue(Macro.RUNTIME_FIELD_MIN_AGC_OUTPUT).ToString("0.000");
                    break;
                case 18:
                    textBox89.Text = gyro1.getValue(Macro.RUNTIME_FIELD_MODESWITCH_DIFFERENCE_FREQUENCY).ToString("0.000");
                    break;
                default:
                    break;

            }
        }

        private void upDataGyro2()
        {
            gyroBuffer2.getValue(Macro.RUNTIME_FIELD_AMP_CHA_I).CopyTo(gyroPaint2.IA_array, 0);
            gyroBuffer2.getValue(Macro.RUNTIME_FIELD_AMP_CHA_Q).CopyTo(gyroPaint2.QA_array, 0);
            gyroBuffer2.getValue(Macro.RUNTIME_FIELD_AMP_CHA).CopyTo(gyroPaint2.AMPA_array, 0);
            gyroBuffer2.getValue(Macro.RUNTIME_FIELD_AMP_CHB_I).CopyTo(gyroPaint2.IB_array, 0);
            gyroBuffer2.getValue(Macro.RUNTIME_FIELD_AMP_CHB_Q).CopyTo(gyroPaint2.QB_array, 0);
            gyroBuffer2.getValue(Macro.RUNTIME_FIELD_AMP_CHB).CopyTo(gyroPaint2.AMPB_array, 0);
            switch (communication.getDatatypeG2())
            {
                case 1:
                    
                    break;
                case 2:
                    gyroBuffer2.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_FRE).CopyTo(gyroPaint2.PLL_current_fre_array, 0);
                    gyroBuffer2.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_PHASE).CopyTo(gyroPaint2.PLL_current_phase_array, 0);
                    gyroBuffer2.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_ERROR).CopyTo(gyroPaint2.PLL_current_error_array, 0);
                    G2_PLL_Nowfre_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_FRE).ToString("0.000");
                    G2_PLL_Nowphase_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_PHASE).ToString("0.000");
                    G2_PLL_relativeerror_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_PLL_CURRENT_ERROR).ToString("0.000");
                    break;
                
                case 6:
                    gyroBuffer2.getValue(Macro.RUNTIME_PID_CURRENT_ERROR).CopyTo(gyroPaint2.PID_error_Amp_array, 0);
                    gyroBuffer2.getValue(Macro.RUNTIME_PID_CURRENT_OUTPUT).CopyTo(gyroPaint2.PID_out_Amp_array, 0);
                 
                    pidAmpErrorG2_textBox.Text = gyro2.getValue(Macro.RUNTIME_PID_CURRENT_ERROR).ToString("0.000");
                    pidAmpOutputG2_textBox.Text = gyro2.getValue(Macro.RUNTIME_PID_CURRENT_OUTPUT).ToString("0.000");
                    break;
                case 15:
                    qfactorStartFreG2_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_QFACTOR_START_FREQUENCY).ToString("0.000");
                    qfactorShortTauG2_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_QFACTOR_SHORT_TAU).ToString("0.000");
                    qfactorLongTauG2_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_QFACTOR_LONG_TAU).ToString("0.000");
                    qfactorMinG2_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_QFACTOR_MIN).ToString("0.000");
                    qfactorMaxG2_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_QFACTOR_MAX).ToString("0.000");
                    break;
                case 16:
                    gyroBuffer2.getValue(Macro.RUNTIME_FIELD_EST_RESONANT_FREQUENCY).CopyTo(gyroPaint2.Fre_resonant_array, 0);
                    gyroBuffer2.getValue(Macro.RUNTIME_FIELD_MIN_AGC_OUTPUT).CopyTo(gyroPaint2.AGC_min_output_array, 0);
                    freResonantG2_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_EST_RESONANT_FREQUENCY).ToString("0.000");
                    agcMinOutG2_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_MIN_AGC_OUTPUT).ToString("0.000");
                    break;
                case 17:
                    G2_pilotFre_leftAmp_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_MODEMATCH_AMP_LEFT).ToString("0.000");
                    G2_pilotFre_rightAmp_textBox.Text = gyro2.getValue(Macro.RUNTIME_FIELD_MODEMATCH_AMP_RIGHT).ToString("0.000");
                    break;
                default:
                    break;
            }
        }

        private void G1_drivefre_button_Click(object sender, EventArgs e)
        {
            try
            {
                if (G1_drivefre_textBox.Text != string.Empty && Convert.ToDouble(G1_drivefre_textBox.Text) >= 0.01 && Convert.ToDouble(G1_drivefre_textBox.Text) < 2000000)
                {
                    sendBuffers[4] = 1; //ID
                    communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[0], 5);//type
                    if (openLoopEnableG1.BackColor == Color.Green)
                        sendBuffers[10] = 1;
                    else sendBuffers[10] = 0;

                    communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G1_drivefre_textBox.Text) * 4294967296 / 5000000.0), 11);
                    communication.GetCrc_Send(sendBuffers);//CRC
                    Event.setValue(1);//Event

                }
            }
            catch 
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }


        private void G1_MISCbutton_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;

                communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[8], 5);//type

                double SA_value = Math.PI * Convert.ToDouble(HV_SA_textBox.Text) / 180.0;
                Int32 SA = ((Convert.ToInt16(Math.Sin(SA_value) * (1 << 14))) << 16) | (Convert.ToInt16(Math.Cos(SA_value) * (1 << 14)));
                communication.from_u32_to_u8(sendBuffers, (UInt32)SA, 7);

                double SB_value = Math.PI * Convert.ToDouble(HV_SB_textBox.Text) / 180;
                Int32 SB = ((Convert.ToInt16(Math.Sin(SB_value) * (1 << 14))) << 16) | (Convert.ToInt16(Math.Cos(SB_value) * (1 << 14)));
                communication.from_u32_to_u8(sendBuffers, (UInt32)SB, 11);

                double CA_value = Math.PI * Convert.ToDouble(HV_CA_textBox.Text) / 180;
                Int32 CA = ((Convert.ToInt16(Math.Sin(CA_value) * (1 << 14))) << 16) | (Convert.ToInt16(Math.Cos(CA_value) * (1 << 14)));
                communication.from_u32_to_u8(sendBuffers, (UInt32)CA, 15);

                double CB_value = Math.PI * Convert.ToDouble(HV_CB_textBox.Text) / 180;
                Int32 value = ((Convert.ToInt16(Math.Sin(CB_value) * (1 << 14))) << 16) | (Convert.ToInt16(Math.Cos(CB_value) * (1 << 14)));
                communication.from_u32_to_u8(sendBuffers, (UInt32)value, 19);

                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
            //string str = String.Join(" ", sendBuffers);
            //textBox89.AppendText(str + "\r\n");
        }

        

        private void radioButton1_Click(object sender, EventArgs e)
        {
            if (rb1)
            {
                radioButton1.Checked = true;
                rb1 = false;
            }
            else
            {
                radioButton1.Checked = false;
                rb1 = true;
            }
        }

        private void radioButton2_Click(object sender, EventArgs e)
        {
            if (rb2)
            {
                radioButton2.Checked = true;
                rb2 = false;
            }
            else
            {
                radioButton2.Checked = false;
                rb2 = true;
            }
        }

        private void radioButton3_Click(object sender, EventArgs e)
        {
            if (rb3)
            {
                radioButton3.Checked = true;
                rb3 = false;
            }
            else
            {
                radioButton3.Checked = false;
                rb3 = true;
            }
        }

        private void radioButton4_Click(object sender, EventArgs e)
        {
            if (rb4)
            {
                radioButton4.Checked = true;
                rb4 = false;
            }
            else
            {
                radioButton4.Checked = false;
                rb4 = true;
            }
        }

        private void radioButton6_Click(object sender, EventArgs e)
        {
            if (rb6)
            {
                radioButton6.Checked = true;
                rb6 = false;
            }
            else
            {
                radioButton6.Checked = false;
                rb6 = true;
            }
        }

        private void radioButton5_Click(object sender, EventArgs e)
        {
            if (rb5)
            {
                radioButton5.Checked = true;
                rb5 = false;
            }
            else
            {
                radioButton5.Checked = false;
                rb5 = true;
            }
        }


        private void G1_scanfre_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;

                communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[3], 5);//type

                byte Control_PON = 0;
                byte Control_SOC = 0;
                byte Control_SOS = 0;
                if (radioButton1.Checked)
                    Control_PON = 1;
                else Control_PON = 0;
                if (radioButton2.Checked)
                    Control_SOC = 1;
                else Control_SOC = 0;
                if (radioButton3.Checked)
                    Control_SOS = 0x01;
                else Control_SOS = 0;

                sendBuffers[7] = Control_SOS;
                sendBuffers[8] = Control_SOC;
                sendBuffers[9] = Control_PON;




                // 单次 0   正扫 0   停 0

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G1_hfre_textBox.Text) * (4294967295 / 5000000.0)), 15);

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G1_lfre_textBox.Text) * (4294967295 / 5000000.0)), 11);

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G1_stepfre_textBox.Text) * (4294967295 / 5000000.0)), 19);


                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(G1_wait_textBox.Text), 23);



                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);

            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G2_drivefre_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;
                communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[0], 5);//type
                if (openLoopEnableG2.BackColor == Color.Green)
                    sendBuffers[10] = 1;
                else sendBuffers[10] = 0;
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G2_drivefre_textBox.Text) * 4294967296 / 5000000.0), 11);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
            //string str = String.Join(" ", Send_buffer);
            //textBox89.AppendText(str + "\r\n");
        }


        private void G2_MISCbutton_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;

                communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[8], 5);//type

                double SA_value = Math.PI * Convert.ToDouble(G2_HV_SA_textBox.Text) / 180.0;
                Int32 SA = ((Convert.ToInt16(Math.Sin(SA_value) * (1 << 14))) << 16) | (Convert.ToInt16(Math.Cos(SA_value) * (1 << 14)));
                communication.from_u32_to_u8(sendBuffers, (UInt32)SA, 7);

                double SB_value = Math.PI * Convert.ToDouble(G2_HV_SB_textBox.Text) / 180;
                Int32 SB = ((Convert.ToInt16(Math.Sin(SB_value) * (1 << 14))) << 16) | (Convert.ToInt16(Math.Cos(SB_value) * (1 << 14)));
                communication.from_u32_to_u8(sendBuffers, (UInt32)SB, 11);

                double CA_value = Math.PI * Convert.ToDouble(G2_HV_CA_textBox.Text) / 180;
                Int32 CA = ((Convert.ToInt16(Math.Sin(CA_value) * (1 << 14))) << 16) | (Convert.ToInt16(Math.Cos(CA_value) * (1 << 14)));
                communication.from_u32_to_u8(sendBuffers, (UInt32)CA, 15);

                double CB_value = Math.PI * Convert.ToDouble(G2_HV_CB_textBox.Text) / 180;
                Int32 value = ((Convert.ToInt16(Math.Sin(CB_value) * (1 << 14))) << 16) | (Convert.ToInt16(Math.Cos(CB_value) * (1 << 14)));
                communication.from_u32_to_u8(sendBuffers, (UInt32)value, 19);

                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G2_scanfre_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;

                communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[3], 5);//type

                byte Control_PON = 0;
                byte Control_SOC = 0;
                byte Control_SOS = 0;
                if (radioButton4.Checked)
                    Control_PON = 1;
                else Control_PON = 0;
                if (radioButton6.Checked)
                    Control_SOC = 1;
                else Control_SOC = 0;
                if (radioButton5.Checked)
                    Control_SOS = 0x01;
                else Control_SOS = 0;

                sendBuffers[7] = Control_SOS;
                sendBuffers[8] = Control_SOC;
                sendBuffers[9] = Control_PON;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G2_hfre_textBox.Text) * (4294967295 / 5000000.0)), 15);

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G2_lfre_textBox.Text) * (4294967295 / 5000000.0)), 11);

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G2_stepfre_textBox.Text) * (4294967295 / 5000000.0)), 19);


                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(G2_waitfre_textBox.Text), 23);

                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox89.Text = string.Empty;  
        }

        private void G1_PLL_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;

                communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[4], 5);//type

                switch (comboBox1.Text)
                {
                    case "关":
                        sendBuffers[10] = 0;
                        break;
                    case "SA":
                        sendBuffers[10] = 1;
                        break;
                    case "SB":
                        sendBuffers[10] = 2;
                        break;
                }
                communication.from_u32_to_u8(sendBuffers, (UInt32)(Convert.ToDouble(PLL_Lockphase_textBox.Text) * (536870912 / 180.0)), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(PLL_middlefre_textBox.Text) * (4294967295 / 5000000.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(PLL_Lockpha_Limiteamp_textBox.Text) * (4294967295 / 5000000.0)), 31);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(PLL_P_textBox.Text) * 100000), 19);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(PLL_I_textBox.Text) * 100000), 23);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(PLL_D_textBox.Text) * 100000), 27);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G2_PLL_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;

                communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[4], 5);//type

                switch (comboBox2.Text)
                {
                    case "关":
                        sendBuffers[10] = 0;
                        break;
                    case "SA":
                        sendBuffers[10] = 1;
                        break;
                    case "SB":
                        sendBuffers[10] = 2;
                        break;
                }
                communication.from_u32_to_u8(sendBuffers, (UInt32)(Convert.ToDouble(G2_PLL_Lockphase_textBox.Text) * (536870912 / 180.0)), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G2_PLL_middlefre_textBox.Text) * (4294967295 / 5000000.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G2_PLL_Lockpha_Limiteamp_textBox.Text) * (4294967295 / 5000000.0)), 31);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(G2_PLL_P_textBox.Text) * 100000), 19);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(G2_PLL_I_textBox.Text) * 100000), 23);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(G2_PLL_D_textBox.Text) * 100000), 27);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }


        private void Delete_fre_button_Click(object sender, EventArgs e)
        {
            plt21.Plot.Clear();
            plt22.Plot.Clear();
            plt21.Render();
            plt22.Render();
            Init_scanfre_line1();
            G1_dataLineEnable_button.Text = "开";
            label179.Text = "0.00";
            label183.Text = "0.00";
            label184.Text = "0.00";
            label185.Text = "0.00";




        }

        private void button1_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 1 ;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 9;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void G1_HV_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;

                communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[2], 5);//type

                sendBuffers[10] = 1;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32((Convert.ToDouble(HV1_textBox.Text) + 20) * (65535 / 40.0)), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32((Convert.ToDouble(HV2_textBox.Text) + 20) * (65536 / 40.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32((Convert.ToDouble(HV3_textBox.Text) + 20) * (65536 / 40.0)), 19);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32((Convert.ToDouble(HV4_textBox.Text) + 20) * (65536 / 40.0)), 23);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G2_HV_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;

                communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[2], 5);//type

                sendBuffers[10] = 1;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32((Convert.ToDouble(G2_HV1_textBox.Text) + 20) * (65535 / 40.0)), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32((Convert.ToDouble(G2_HV2_textBox.Text) + 20) * (65536 / 40.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32((Convert.ToDouble(G2_HV3_textBox.Text) + 20) * (65536 / 40.0)), 19);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32((Convert.ToDouble(G2_HV4_textBox.Text) + 20) * (65536 / 40.0)), 23);
                communication.GetCrc_Send(sendBuffers);

                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 1;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 1;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        string storage_str = String.Empty;
        byte storage_count = 0;
        bool storage_OK = false;
        SaveFileDialog saveFileDialog = new SaveFileDialog();
        DateTime saveFailName = DateTime.Now;


        private void storage_button_Click(object sender, EventArgs e)
        {
            if (storage_button.Text == "开始保存")
            {
                storage_str = String.Empty;
                storage_button.Text = "停止保存";
                saveFailName = DateTime.Now;
                saveFileDialog.FileName = saveFailName.Year.ToString() + saveFailName.Month.ToString("00") + saveFailName.Day.ToString("00") + "-" + saveFailName.Hour.ToString("00") + saveFailName.Minute.ToString("00");
                saveFileDialog.Filter = "(*.txt)|*.csv";  //只允许保存为csv
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    storage_OK = true;
                    timerDataSave.Start();
                    storage_str = String.Empty;
                    Event.setValue(2);

                }
                else
                {
                    storage_button.Text = "开始保存";
                    storage_str = String.Empty;
                    timerDataSave.Stop();
                    Event.setValue(3);
                }

            }
            else
            {
                timerDataSave.Stop();
                storage_str = communication.getDataSaveStr();
                StreamWriter streamWriter = new StreamWriter(saveFileDialog.FileName, append: true);
                streamWriter.Write(storage_str);
                streamWriter.Close();
                storage_button.Text = "开始保存";
   
                storage_str = String.Empty;
       
                storage_OK = false;
                Event.setValue(3);
                Event.setValue(4);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 2;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 1;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 2;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 9;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void Delete_G2fre_button_Click(object sender, EventArgs e)
        {
            plt23.Plot.Clear();
            plt24.Plot.Clear();
            plt23.Render();
            plt24.Render();
            Init_scanfre_line2();
            G2_dataLineEnable_button.Text = "开";
            label182.Text = "0.00";
            label186.Text = "0.00";
            label187.Text = "0.00";
            label188.Text = "0.00";
        }

        private void openLoopEnableG1_Click(object sender, EventArgs e)
        {
            if(openLoopEnableG1.BackColor == Color.Red)
                openLoopEnableG1.BackColor = Color.Green;
            else
                openLoopEnableG1.BackColor = Color.Red;
        }

        private void openLoopEnableG2_Click(object sender, EventArgs e)
        {
            if (openLoopEnableG2.BackColor == Color.Red)
                openLoopEnableG2.BackColor = Color.Green;
            else
                openLoopEnableG2.BackColor = Color.Red;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CMD_OPENLOOP_ACT_button_Click_1(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;
                communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[1], 5);//type
                sendBuffers[10] = 1;
                communication.from_s32_to_u8(sendBuffers, Convert.ToInt32(Convert.ToDouble(Openloop_AS_textBox.Text) * 32768 / 2500.0), 11);
                communication.from_s32_to_u8(sendBuffers, Convert.ToInt32(Convert.ToDouble(Openloop_AC_textBox.Text) * 32768 / 2500.0), 15);
                communication.from_s32_to_u8(sendBuffers, Convert.ToInt32(Convert.ToDouble(Openloop_BS_textBox.Text) * 32768 / 2500.0), 19);
                communication.from_s32_to_u8(sendBuffers, Convert.ToInt32(Convert.ToDouble(Openloop_BC_textBox.Text) * 32768 / 2500.0), 23);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G2_CMD_OPENLOOP_ACT_button_Click_1(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;
                communication.from_u16_to_u8(sendBuffers, Communication.Downlink_communication[1], 5);//type
                sendBuffers[10] = 1;
                communication.from_s32_to_u8(sendBuffers, Convert.ToInt32(Convert.ToDouble(G2_Openloop_AS_textBox.Text) * 32768 / 2500.0), 11);
                communication.from_s32_to_u8(sendBuffers, Convert.ToInt32(Convert.ToDouble(G2_Openloop_AC_textBox.Text) * 32768 / 2500.0), 15);
                communication.from_s32_to_u8(sendBuffers, Convert.ToInt32(Convert.ToDouble(G2_Opebloop_BS_textBox.Text) * 32768 / 2500.0), 19);
                communication.from_s32_to_u8(sendBuffers, Convert.ToInt32(Convert.ToDouble(G2_Openloop_BC_textBox.Text) * 32768 / 2500.0), 23);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void pid1EnableG1_Click(object sender, EventArgs e)
        {
            if (pid1EnableG1.BackColor == Color.Red)
                pid1EnableG1.BackColor = Color.Green;
            else if(pid1EnableG1.BackColor == Color.Green)
                pid1EnableG1.BackColor = Color.Blue;
            else
                pid1EnableG1.BackColor = Color.Red;
        }

        private void pid2EnableG1_Click(object sender, EventArgs e)
        {
            if (pid2EnableG1.BackColor == Color.Red)
                pid2EnableG1.BackColor = Color.Green;
            else if (pid2EnableG1.BackColor == Color.Green)
                pid2EnableG1.BackColor = Color.Blue;
            else
                pid2EnableG1.BackColor = Color.Red;
        }

        private void pid3EnableG1_Click(object sender, EventArgs e)
        {
            if (pid3EnableG1.BackColor == Color.Red)
                pid3EnableG1.BackColor = Color.Green;
            else if (pid3EnableG1.BackColor == Color.Green)
                pid3EnableG1.BackColor = Color.Blue;
            else
                pid3EnableG1.BackColor = Color.Red;
        }

        private void pid4EnableG1_Click(object sender, EventArgs e)
        {
            if (pid4EnableG1.BackColor == Color.Red)
                pid4EnableG1.BackColor = Color.Green;
            else if (pid4EnableG1.BackColor == Color.Green)
                pid4EnableG1.BackColor = Color.Blue;
            else
                pid4EnableG1.BackColor = Color.Red;
        }

        private void pid1EnableG2_Click(object sender, EventArgs e)
        {
            if (pid1EnableG2.BackColor == Color.Red)
                pid1EnableG2.BackColor = Color.Green;
            else if (pid1EnableG2.BackColor == Color.Green)
                pid1EnableG2.BackColor = Color.Blue;
            else
                pid1EnableG2.BackColor = Color.Red;
        }

        private void pid2EnableG2_Click(object sender, EventArgs e)
        {
            if (pid2EnableG2.BackColor == Color.Red)
                pid2EnableG2.BackColor = Color.Green;
            else if (pid2EnableG2.BackColor == Color.Green)
                pid2EnableG2.BackColor = Color.Blue;
            else
                pid2EnableG2.BackColor = Color.Red;
        }

        private void pid3EnableG2_Click(object sender, EventArgs e)
        {
            if (pid3EnableG2.BackColor == Color.Red)
                pid3EnableG2.BackColor = Color.Green;
            else if (pid3EnableG2.BackColor == Color.Green)
                pid3EnableG2.BackColor = Color.Blue;
            else
                pid3EnableG2.BackColor = Color.Red;
        }

        private void pid4EnableG2_Click(object sender, EventArgs e)
        {
            if (pid4EnableG2.BackColor == Color.Red)
                pid4EnableG2.BackColor = Color.Green;
            else if (pid4EnableG2.BackColor == Color.Green)
                pid4EnableG2.BackColor = Color.Blue;
            else
                pid4EnableG2.BackColor = Color.Red;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 1;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 10;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 1;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 11;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 1;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 12;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 1;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 13;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 2;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 10;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 2;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 11;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 2;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 12;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 2;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 13;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void G1_pid1_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;

                communication.from_u16_to_u8(sendBuffers, 50, 5);//type

                if (pid1EnableG1.BackColor == Color.Red)
                    sendBuffers[10] = 0;
                else if (pid1EnableG1.BackColor == Color.Green)
                    sendBuffers[10] = 3;
                else
                    sendBuffers[10] = 4;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid1LockAmpG1.Text) * 2895), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid1MiddleAmpG1.Text) * (32768 / 2500.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid1LimitAmpG1.Text) * (32768 / 2500.0)), 31);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid1PG1.Text)*100000), 19);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid1IG1.Text)*100000), 23);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid1DG1.Text) * 100000), 27);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G1_pid2_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;

                communication.from_u16_to_u8(sendBuffers, 51, 5);//type

                if (pid2EnableG1.BackColor == Color.Red)
                    sendBuffers[10] = 0;
                else if (pid2EnableG1.BackColor == Color.Green)
                    sendBuffers[10] = 3;
                else
                    sendBuffers[10] = 4;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid2LockAmpG1.Text) * 2895), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid2MiddleAmpG1.Text) * (32768 / 2500.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid2LimitAmpG1.Text) * (32768 / 2500.0)), 31);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid2PG1.Text) * 100000), 19);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid2IG1.Text) * 100000), 23);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid2DG1.Text) * 100000), 27);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G1_pid3_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;

                communication.from_u16_to_u8(sendBuffers, 52, 5);//type

                if (pid3EnableG1.BackColor == Color.Red)
                    sendBuffers[10] = 0;
                else if (pid3EnableG1.BackColor == Color.Green)
                    sendBuffers[10] = 3;
                else
                    sendBuffers[10] = 4;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid3LockAmpG1.Text) * 2895), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid3MiddleAmpG1.Text) * (32768 / 2500.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid3LimitAmpG1.Text) * (32768 / 2500.0)), 31);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid3PG1.Text) * 100000), 19);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid3IG1.Text) * 100000), 23);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid3DG1.Text) * 100000), 27);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G1_pid4_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;

                communication.from_u16_to_u8(sendBuffers, 53, 5);//type

                if (pid4EnableG1.BackColor == Color.Red)
                    sendBuffers[10] = 0;
                else if (pid4EnableG1.BackColor == Color.Green)
                    sendBuffers[10] = 3;
                else
                    sendBuffers[10] = 4;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid4LockAmpG1.Text) * 2895), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid4MiddleAmpG1.Text) * (32768 / 2500.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid4LimitAmpG1.Text) * (32768 / 2500.0)), 31);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid4PG1.Text) * 100000), 19);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid4IG1.Text) * 100000), 23);
                communication.from_s32_to_u8(sendBuffers, (int)(Convert.ToDouble(pid4DG1.Text) * 100000), 27);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G2_pid1_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;

                communication.from_u16_to_u8(sendBuffers, 50, 5);//type

                if (pid1EnableG2.BackColor == Color.Red)
                    sendBuffers[10] = 0;
                else if (pid1EnableG2.BackColor == Color.Green)
                    sendBuffers[10] = 3;
                else
                    sendBuffers[10] = 4;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid1LockAmpG2.Text) * 2895), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid1MiddleAmpG2.Text) * (32768 / 2500.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid1LimitAmpG2.Text) * (32768 / 2500.0)), 31);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid1PG2.Text) * 100000), 19);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid1IG2.Text) * 100000), 23);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid1DG2.Text) * 100000), 27);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G2_pid2_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;

                communication.from_u16_to_u8(sendBuffers, 51, 5);//type

                if (pid2EnableG2.BackColor == Color.Red)
                    sendBuffers[10] = 0;
                else if (pid2EnableG2.BackColor == Color.Green)
                    sendBuffers[10] = 3;
                else
                    sendBuffers[10] = 4;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid2LockAmpG2.Text) * 2895), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid2MiddleAmpG2.Text) * (32768 / 2500.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid2LimitAmpG2.Text) * (32768 / 2500.0)), 31);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid2PG2.Text) * 100000), 19);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid2IG2.Text) * 100000), 23);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid2DG2.Text) * 100000), 27);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G2_pid3_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;

                communication.from_u16_to_u8(sendBuffers, 52, 5);//type

                if (pid3EnableG2.BackColor == Color.Red)
                    sendBuffers[10] = 0;
                else if (pid3EnableG2.BackColor == Color.Green)
                    sendBuffers[10] = 3;
                else
                    sendBuffers[10] = 4;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid3LockAmpG2.Text) * 2895), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid3MiddleAmpG2.Text) * (32768 / 2500.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid3LimitAmpG2.Text) * (32768 / 2500.0)), 31);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid3PG2.Text) * 100000) ,19);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid3IG2.Text) * 100000), 23);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid3DG2.Text) * 100000), 27);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void G2_pid4_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;

                communication.from_u16_to_u8(sendBuffers, 53, 5);//type

                if (pid4EnableG2.BackColor == Color.Red)
                    sendBuffers[10] = 0;
                else if (pid4EnableG2.BackColor == Color.Green)
                    sendBuffers[10] = 3;
                else
                    sendBuffers[10] = 4;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid4LockAmpG2.Text) * 2895), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid4MiddleAmpG2.Text) * (32768 / 2500.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(pid4LimitAmpG2.Text) * (32768 / 2500.0)), 31);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid4PG2.Text) * 100000), 19);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid4IG2.Text) * 100000), 23);
                communication.from_s32_to_u8(sendBuffers, (Int32)(Convert.ToDouble(pid4DG2.Text) * 100000), 27);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void button17_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 1;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 15;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 2;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 15;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void G1_Qfactor_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;
                communication.from_u16_to_u8(sendBuffers, 65, 5);//type
                if (qFactorG1Enable.BackColor == Color.Green)
                    sendBuffers[10] = 1;
                else sendBuffers[10] = 0;
                switch (comboBox3.Text)
                {
                    case "AI":
                        sendBuffers[14] = 2;
                        break;
                    case "AQ":
                        sendBuffers[14] = 3;
                        break;
                    case "BI":
                        sendBuffers[14] = 4;
                        break;
                    case "BQ":
                        sendBuffers[14] = 5;
                        break;
                }

                communication.from_u32_to_u8(sendBuffers, 859, 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(qfactorDelayG1_textBox.Text)), 19);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void qFactorG1Enable_Click(object sender, EventArgs e)
        {
            if (qFactorG1Enable.BackColor == Color.Red)
                qFactorG1Enable.BackColor = Color.Green;
            else
                qFactorG1Enable.BackColor = Color.Red;
        }

        private void G2_Qfactor_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;
                communication.from_u16_to_u8(sendBuffers, 65, 5);//type
                if (qFactorG2Enable.BackColor == Color.Green)
                    sendBuffers[10] = 1;
                else sendBuffers[10] = 0;
                switch (comboBox4.Text)
                {
                    case "AI":
                        sendBuffers[14] = 2;
                        break;
                    case "AQ":
                        sendBuffers[14] = 3;
                        break;
                    case "BI":
                        sendBuffers[14] = 4;
                        break;
                    case "BQ":
                        sendBuffers[14] = 5;
                        break;
                }
                communication.from_u32_to_u8(sendBuffers, 859, 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(qfactorDelayG2_textBox.Text)), 19);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
           
        }

        private void qFactorG2Enable_Click(object sender, EventArgs e)
        {
            if (qFactorG2Enable.BackColor == Color.Red)
                qFactorG2Enable.BackColor = Color.Green;
            else
                qFactorG2Enable.BackColor = Color.Red;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if(G1_dataLineEnable_button.Text == "关")
            {
                string message11 = $"X={(vLine11.X).ToString("0.00")}";
                string message12 = $"Y={(hLine12.Y).ToString("0.00")}";
                string message21 = $"X={(vLine21.X).ToString("0.00")}";
                string message22 = $"Y={(hLine22.Y).ToString("0.00")}";
                label179.Text = message11;
                label183.Text = message12;
                label185.Text = message21;
                label184.Text = message22;
            }
            if(G2_dataLineEnable_button.Text == "关")
            {
                string message31 = $"X={(vLine31.X).ToString("0.00")}";
                string message32 = $"Y={(hLine32.Y).ToString("0.00")}";
                string message41 = $"X={(vLine41.X).ToString("0.00")}";
                string message42 = $"Y={(hLine42.Y).ToString("0.00")}";

                label182.Text = message31;
                label186.Text = message32;
                label187.Text = message41;
                label188.Text = message42;
            }
            
        }

        private void ResonantG1_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;
                communication.from_u16_to_u8(sendBuffers, 81, 5);//type
                
                switch (comboBox5.Text)
                {
                    case "AI":
                        sendBuffers[10] = 2;
                        break;
                    case "AQ":
                        sendBuffers[10] = 3;
                        break;
                    case "BI":
                        sendBuffers[10] = 4;
                        break;
                    case "BQ":
                        sendBuffers[10] = 5;
                        break;
                    case "关闭":
                        sendBuffers[10] = 0;
                        break;
                }

                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 1;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 16;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 2;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 16;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void ResonantG2_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;
                communication.from_u16_to_u8(sendBuffers, 81, 5);//type

                switch (comboBox5.Text)
                {
                    case "AI":
                        sendBuffers[10] = 2;
                        break;
                    case "AQ":
                        sendBuffers[10] = 3;
                        break;
                    case "BI":
                        sendBuffers[10] = 4;
                        break;
                    case "BQ":
                        sendBuffers[10] = 5;
                        break;
                    case "关闭":
                        sendBuffers[10] = 0;
                        break;
                }

                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void pilotFrequncyEnableG2_Click(object sender, EventArgs e)
        {
            if (pilotFrequncyEnableG2.BackColor == Color.Red)
                pilotFrequncyEnableG2.BackColor = Color.Green;
            else
                pilotFrequncyEnableG2.BackColor = Color.Red;
        }

        private void G2_pilotFrequncy_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 2;
                communication.from_u16_to_u8(sendBuffers, 97, 5);//type
                if (pilotFrequncyEnableG2.BackColor == Color.Green)
                    sendBuffers[10] = 1;
                else sendBuffers[10] = 0;

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G2_pilotFre_textBox.Text) * (4294967295 / 5000000.0)), 11);
                communication.from_s32_to_u8(sendBuffers, Convert.ToInt32(Convert.ToDouble(G2_pilotFreSin_textBox.Text) * 32768 / 2500.0), 15);
                communication.from_s32_to_u8(sendBuffers, Convert.ToInt32(Convert.ToDouble(G2_pilotFreCos_textBox.Text) * 32768 / 2500.0), 19);
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 2;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 17;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void G1_dataLineEnable_button_Click(object sender, EventArgs e)
        {
            if(G1_dataLineEnable_button.Text == "开")
            {
                G1_dataLineEnable_button.Text = "关";
                Init_XY_lineEnable();
            }
            else
            {
                G1_dataLineEnable_button.Text = "开";
                Init_XY_lineDisable();
            }
        }

        private void G2_dataLineEnable_button_Click(object sender, EventArgs e)
        {
            if (G2_dataLineEnable_button.Text == "开")
            {
                G2_dataLineEnable_button.Text = "关";
                Init_XY_linesEnable2();
            }
            else
            {
                G2_dataLineEnable_button.Text = "开";
                Init_XY_linesDisable2();
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 1;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 17;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 2;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 17;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }

        private void phaseFindG1Enable_Click(object sender, EventArgs e)
        {

            if (phaseFindG1Enable.BackColor == Color.Red)
                phaseFindG1Enable.BackColor = Color.Green;
            else
                phaseFindG1Enable.BackColor = Color.Red;
        }

        private void phaseFindG1_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;
                communication.from_u16_to_u8(sendBuffers, 97, 5);//type
                if (phaseFindG1Enable.BackColor == Color.Green)
                    sendBuffers[8] = 1;
                else sendBuffers[8] = 0;
                switch (comboBox7.Text)
                {
                    case "AI":
                        sendBuffers[10] = 2;
                        break;
                    case "AQ":
                        sendBuffers[10] = 3;
                        break;
                    case "BI":
                        sendBuffers[10] = 4;
                        break;
                    case "BQ":
                        sendBuffers[10] = 5;
                        break;
                }

                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(setTimeG1_textBox.Text)), 11);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(leftPhaseG1_textBox.Text) * (536870912 / 180.0)), 15);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(rightPhaseG1_textBox.Text) * (536870912 / 180.0)), 19);
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(minPhaseG1_textBox.Text) * (536870912 / 180.0)), 23);
             
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void G1_modeSwitchEnable_Click(object sender, EventArgs e)
        {
            if (G1_modeSwitchEnable.BackColor == Color.Red)
                G1_modeSwitchEnable.BackColor = Color.Green;
            else
                G1_modeSwitchEnable.BackColor = Color.Red;
        }

        private void G1_modeCopySA_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;

                communication.from_u16_to_u8(sendBuffers, 113, 5);//type
                sendBuffers[14] = 1;
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void G1_modeCopySB_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;

                communication.from_u16_to_u8(sendBuffers, 113, 5);//type
                sendBuffers[14] = 2;
                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void G1_modeSwitch_button_Click(object sender, EventArgs e)
        {
            try
            {
                sendBuffers[4] = 1;
                communication.from_u16_to_u8(sendBuffers, 113, 5);//type
                if (G1_modeSwitchEnable.BackColor == Color.Green)
                    sendBuffers[10] = 1;
                else sendBuffers[10] = 0;
                sendBuffers[14] = 0;
               
                communication.from_u32_to_u8(sendBuffers, Convert.ToUInt32(Convert.ToDouble(G1_modeSwitchDelay_textBox.Text)), 15);

                communication.GetCrc_Send(sendBuffers);
                Event.setValue(1);
            }
            catch
            {
                MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); MessageBox.Show("\t数据不合法\r\n 有特殊字符/数字太大/数字太小", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            pltphasefinder1.Plot.Clear();

            pltphasefinder1.Render();

            Init_phasefinder_line1();
        }

        private void button25_Click(object sender, EventArgs e)
        {
            sendBuffers[4] = 1;
            communication.from_u16_to_u8(sendBuffers, 0x08, 5);//type
            sendBuffers[7] = 18;
            communication.GetCrc_Send(sendBuffers);
            Event.setValue(1);
        }
    }
}
