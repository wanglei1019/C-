﻿namespace ut64configurator
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label185 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.label183 = new System.Windows.Forms.Label();
            this.Delete_fre_button = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.G1_dataLineEnable_button = new System.Windows.Forms.Button();
            this.plt22 = new ScottPlot.FormsPlot();
            this.plt21 = new ScottPlot.FormsPlot();
            this.label179 = new System.Windows.Forms.Label();
            this.Scanfre_PhaseB_checkBox = new System.Windows.Forms.CheckBox();
            this.Scanfre_AmpB_checkBox = new System.Windows.Forms.CheckBox();
            this.Scanfre_PhaseA_checkBox = new System.Windows.Forms.CheckBox();
            this.Scanfre_AmpA_checkBox = new System.Windows.Forms.CheckBox();
            this.label126 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.SB_IQ_AcheckBox = new System.Windows.Forms.CheckBox();
            this.SA_IQ_AcheckBox = new System.Windows.Forms.CheckBox();
            this.SB_IQ_QcheckBox = new System.Windows.Forms.CheckBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.SA_IQ_QcheckBox = new System.Windows.Forms.CheckBox();
            this.SB_IQ_IcheckBox = new System.Windows.Forms.CheckBox();
            this.SA_IQ_IcheckBox = new System.Windows.Forms.CheckBox();
            this.label124 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.plt1 = new ScottPlot.FormsPlot();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.plt2 = new ScottPlot.FormsPlot();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.plt8 = new ScottPlot.FormsPlot();
            this.plt7 = new ScottPlot.FormsPlot();
            this.plt6 = new ScottPlot.FormsPlot();
            this.plt5 = new ScottPlot.FormsPlot();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.checkBox33 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.plt10 = new ScottPlot.FormsPlot();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.checkBox31 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.plt32 = new ScottPlot.FormsPlot();
            this.plt31 = new ScottPlot.FormsPlot();
            this.tabPage27 = new System.Windows.Forms.TabPage();
            this.button24 = new System.Windows.Forms.Button();
            this.pltphasefinder1 = new ScottPlot.FormsPlot();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.plt18 = new ScottPlot.FormsPlot();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.label188 = new System.Windows.Forms.Label();
            this.label187 = new System.Windows.Forms.Label();
            this.label186 = new System.Windows.Forms.Label();
            this.label182 = new System.Windows.Forms.Label();
            this.Delete_G2fre_button = new System.Windows.Forms.Button();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.plt17 = new ScottPlot.FormsPlot();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.plt16 = new ScottPlot.FormsPlot();
            this.plt15 = new ScottPlot.FormsPlot();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.label180 = new System.Windows.Forms.Label();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.G2_dataLineEnable_button = new System.Windows.Forms.Button();
            this.plt24 = new ScottPlot.FormsPlot();
            this.plt23 = new ScottPlot.FormsPlot();
            this.label181 = new System.Windows.Forms.Label();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.label142 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.storage_timetoend_textBox = new System.Windows.Forms.TextBox();
            this.timer_storage_button = new System.Windows.Forms.Button();
            this.storage_button = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.button_switch = new System.Windows.Forms.Button();
            this.port_list = new System.Windows.Forms.ComboBox();
            this.checkBox32 = new System.Windows.Forms.CheckBox();
            this.plt20 = new ScottPlot.FormsPlot();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.checkBox34 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.HV4_textBox = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.HV2_textBox = new System.Windows.Forms.TextBox();
            this.HV1_textBox = new System.Windows.Forms.TextBox();
            this.HV3_textBox = new System.Windows.Forms.TextBox();
            this.HV_SB_textBox = new System.Windows.Forms.TextBox();
            this.HV_CB_textBox = new System.Windows.Forms.TextBox();
            this.HV_SA_textBox = new System.Windows.Forms.TextBox();
            this.HV_CA_textBox = new System.Windows.Forms.TextBox();
            this.G1_HV_button = new System.Windows.Forms.Button();
            this.G1_MISCbutton = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.plt12 = new ScottPlot.FormsPlot();
            this.plt11 = new ScottPlot.FormsPlot();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.checkBox36 = new System.Windows.Forms.CheckBox();
            this.checkBox35 = new System.Windows.Forms.CheckBox();
            this.plt34 = new ScottPlot.FormsPlot();
            this.plt33 = new ScottPlot.FormsPlot();
            this.G1_wait_textBox = new System.Windows.Forms.TextBox();
            this.G1_stepfre_textBox = new System.Windows.Forms.TextBox();
            this.G1_lfre_textBox = new System.Windows.Forms.TextBox();
            this.G1_hfre_textBox = new System.Windows.Forms.TextBox();
            this.G1_scanfre_button = new System.Windows.Forms.Button();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.G1_modeSwitchEnable = new System.Windows.Forms.Button();
            this.label144 = new System.Windows.Forms.Label();
            this.G1_modeSwitch_button = new System.Windows.Forms.Button();
            this.G1_modeSwitchDelay_textBox = new System.Windows.Forms.TextBox();
            this.label143 = new System.Windows.Forms.Label();
            this.G1_modeCopySB_button = new System.Windows.Forms.Button();
            this.G1_modeCopySA_button = new System.Windows.Forms.Button();
            this.G1_PLL_button = new System.Windows.Forms.Button();
            this.label176 = new System.Windows.Forms.Label();
            this.label175 = new System.Windows.Forms.Label();
            this.PLL_D_textBox = new System.Windows.Forms.TextBox();
            this.PLL_relativeerror_textBox = new System.Windows.Forms.TextBox();
            this.PLL_Nowphase_textBox = new System.Windows.Forms.TextBox();
            this.PLL_Nowfre_textBox = new System.Windows.Forms.TextBox();
            this.PLL_Lockpha_Limiteamp_textBox = new System.Windows.Forms.TextBox();
            this.PLL_I_textBox = new System.Windows.Forms.TextBox();
            this.PLL_P_textBox = new System.Windows.Forms.TextBox();
            this.PLL_middlefre_textBox = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.PLL_Lockphase_textBox = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label173 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.openLoopEnableG1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.G1_drivefre_textBox = new System.Windows.Forms.TextBox();
            this.G1_drivefre_button = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.openLoopLedG1 = new System.Windows.Forms.Button();
            this.sweepLedG1 = new System.Windows.Forms.Button();
            this.pllLedG1 = new System.Windows.Forms.Button();
            this.openLoopLedG2 = new System.Windows.Forms.Button();
            this.sweepLedG2 = new System.Windows.Forms.Button();
            this.pllLedG2 = new System.Windows.Forms.Button();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.openLoopEnableG2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.G2_drivefre_textBox = new System.Windows.Forms.TextBox();
            this.G2_drivefre_button = new System.Windows.Forms.Button();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.G2_waitfre_textBox = new System.Windows.Forms.TextBox();
            this.G2_stepfre_textBox = new System.Windows.Forms.TextBox();
            this.G2_lfre_textBox = new System.Windows.Forms.TextBox();
            this.G2_hfre_textBox = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.G2_scanfre_button = new System.Windows.Forms.Button();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.G2_PLL_button = new System.Windows.Forms.Button();
            this.label178 = new System.Windows.Forms.Label();
            this.label177 = new System.Windows.Forms.Label();
            this.G2_PLL_D_textBox = new System.Windows.Forms.TextBox();
            this.G2_PLL_Lockpha_Limiteamp_textBox = new System.Windows.Forms.TextBox();
            this.G2_PLL_relativeerror_textBox = new System.Windows.Forms.TextBox();
            this.G2_PLL_Nowphase_textBox = new System.Windows.Forms.TextBox();
            this.G2_PLL_Nowfre_textBox = new System.Windows.Forms.TextBox();
            this.G2_PLL_I_textBox = new System.Windows.Forms.TextBox();
            this.G2_PLL_P_textBox = new System.Windows.Forms.TextBox();
            this.G2_PLL_middlefre_textBox = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.G2_PLL_Lockphase_textBox = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label174 = new System.Windows.Forms.Label();
            this.tabControl7 = new System.Windows.Forms.TabControl();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.label92 = new System.Windows.Forms.Label();
            this.G2_CMD_OPENLOOP_ACT_button = new System.Windows.Forms.Button();
            this.label90 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.pidAmpOutputG2_textBox = new System.Windows.Forms.TextBox();
            this.pidAmpErrorG2_textBox = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.G2_pid4_button = new System.Windows.Forms.Button();
            this.pid4EnableG2 = new System.Windows.Forms.Button();
            this.pid4DG2 = new System.Windows.Forms.TextBox();
            this.pid4IG2 = new System.Windows.Forms.TextBox();
            this.pid4PG2 = new System.Windows.Forms.TextBox();
            this.pid4LimitAmpG2 = new System.Windows.Forms.TextBox();
            this.pid4MiddleAmpG2 = new System.Windows.Forms.TextBox();
            this.pid4LockAmpG2 = new System.Windows.Forms.TextBox();
            this.G2_pid3_button = new System.Windows.Forms.Button();
            this.pid3EnableG2 = new System.Windows.Forms.Button();
            this.pid3DG2 = new System.Windows.Forms.TextBox();
            this.pid3IG2 = new System.Windows.Forms.TextBox();
            this.pid3PG2 = new System.Windows.Forms.TextBox();
            this.pid3LimitAmpG2 = new System.Windows.Forms.TextBox();
            this.pid3MiddleAmpG2 = new System.Windows.Forms.TextBox();
            this.pid3LockAmpG2 = new System.Windows.Forms.TextBox();
            this.G2_pid2_button = new System.Windows.Forms.Button();
            this.pid2EnableG2 = new System.Windows.Forms.Button();
            this.pid2DG2 = new System.Windows.Forms.TextBox();
            this.pid2IG2 = new System.Windows.Forms.TextBox();
            this.pid2PG2 = new System.Windows.Forms.TextBox();
            this.pid2LimitAmpG2 = new System.Windows.Forms.TextBox();
            this.pid2MiddleAmpG2 = new System.Windows.Forms.TextBox();
            this.pid2LockAmpG2 = new System.Windows.Forms.TextBox();
            this.G2_pid1_button = new System.Windows.Forms.Button();
            this.pid1EnableG2 = new System.Windows.Forms.Button();
            this.pid1DG2 = new System.Windows.Forms.TextBox();
            this.pid1IG2 = new System.Windows.Forms.TextBox();
            this.pid1PG2 = new System.Windows.Forms.TextBox();
            this.pid1LimitAmpG2 = new System.Windows.Forms.TextBox();
            this.pid1MiddleAmpG2 = new System.Windows.Forms.TextBox();
            this.pid1LockAmpG2 = new System.Windows.Forms.TextBox();
            this.G2_Openloop_BC_textBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.G2_Opebloop_BS_textBox = new System.Windows.Forms.TextBox();
            this.G2_Openloop_AC_textBox = new System.Windows.Forms.TextBox();
            this.G2_Openloop_AS_textBox = new System.Windows.Forms.TextBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.qFactorG2Enable = new System.Windows.Forms.Button();
            this.qfactorLongTauG2_textBox = new System.Windows.Forms.TextBox();
            this.qfactorMaxG2_textBox = new System.Windows.Forms.TextBox();
            this.qfactorShortTauG2_textBox = new System.Windows.Forms.TextBox();
            this.qfactorMinG2_textBox = new System.Windows.Forms.TextBox();
            this.qfactorStartFreG2_textBox = new System.Windows.Forms.TextBox();
            this.qfactorDelayG2_textBox = new System.Windows.Forms.TextBox();
            this.G2_Qfactor_button = new System.Windows.Forms.Button();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.agcMinOutG2_textBox = new System.Windows.Forms.TextBox();
            this.freResonantG2_textBox = new System.Windows.Forms.TextBox();
            this.ResonantG2_button = new System.Windows.Forms.Button();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.button21 = new System.Windows.Forms.Button();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.G2_pilotFre_leftAmp_textBox = new System.Windows.Forms.TextBox();
            this.pilotFrequncyEnableG2 = new System.Windows.Forms.Button();
            this.G2_pilotFrequncy_button = new System.Windows.Forms.Button();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.G2_pilotFre_textBox = new System.Windows.Forms.TextBox();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.G2_pilotFreSin_textBox = new System.Windows.Forms.TextBox();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.G2_pilotFre_rightAmp_textBox = new System.Windows.Forms.TextBox();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.G2_pilotFreCos_textBox = new System.Windows.Forms.TextBox();
            this.tabControl8 = new System.Windows.Forms.TabControl();
            this.tabPage26 = new System.Windows.Forms.TabPage();
            this.G2_HV_button = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.G2_MISCbutton = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.G2_HV4_textBox = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.G2_HV3_textBox = new System.Windows.Forms.TextBox();
            this.G2_HV2_textBox = new System.Windows.Forms.TextBox();
            this.G2_HV1_textBox = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.G2_HV_SB_textBox = new System.Windows.Forms.TextBox();
            this.G2_HV_CB_textBox = new System.Windows.Forms.TextBox();
            this.G2_HV_SA_textBox = new System.Windows.Forms.TextBox();
            this.G2_HV_CA_textBox = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label91 = new System.Windows.Forms.Label();
            this.CMD_OPENLOOP_ACT_button = new System.Windows.Forms.Button();
            this.label189 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.pidAmpOutputG1_textBox = new System.Windows.Forms.TextBox();
            this.pidAmpErrorG1_textBox = new System.Windows.Forms.TextBox();
            this.pid4DG1 = new System.Windows.Forms.TextBox();
            this.pid4IG1 = new System.Windows.Forms.TextBox();
            this.pid4PG1 = new System.Windows.Forms.TextBox();
            this.pid4LimitAmpG1 = new System.Windows.Forms.TextBox();
            this.pid4MiddleAmpG1 = new System.Windows.Forms.TextBox();
            this.pid4LockAmpG1 = new System.Windows.Forms.TextBox();
            this.pid3DG1 = new System.Windows.Forms.TextBox();
            this.pid3IG1 = new System.Windows.Forms.TextBox();
            this.pid3PG1 = new System.Windows.Forms.TextBox();
            this.pid3LimitAmpG1 = new System.Windows.Forms.TextBox();
            this.pid3MiddleAmpG1 = new System.Windows.Forms.TextBox();
            this.pid3LockAmpG1 = new System.Windows.Forms.TextBox();
            this.pid2DG1 = new System.Windows.Forms.TextBox();
            this.pid2IG1 = new System.Windows.Forms.TextBox();
            this.pid2PG1 = new System.Windows.Forms.TextBox();
            this.pid2LimitAmpG1 = new System.Windows.Forms.TextBox();
            this.pid2MiddleAmpG1 = new System.Windows.Forms.TextBox();
            this.pid2LockAmpG1 = new System.Windows.Forms.TextBox();
            this.pid1DG1 = new System.Windows.Forms.TextBox();
            this.pid1IG1 = new System.Windows.Forms.TextBox();
            this.pid1PG1 = new System.Windows.Forms.TextBox();
            this.pid1LimitAmpG1 = new System.Windows.Forms.TextBox();
            this.pid1MiddleAmpG1 = new System.Windows.Forms.TextBox();
            this.pid1LockAmpG1 = new System.Windows.Forms.TextBox();
            this.Openloop_BC_textBox = new System.Windows.Forms.TextBox();
            this.Openloop_BS_textBox = new System.Windows.Forms.TextBox();
            this.Openloop_AC_textBox = new System.Windows.Forms.TextBox();
            this.Openloop_AS_textBox = new System.Windows.Forms.TextBox();
            this.label191 = new System.Windows.Forms.Label();
            this.label192 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.G1_pid4_button = new System.Windows.Forms.Button();
            this.pid4EnableG1 = new System.Windows.Forms.Button();
            this.G1_pid3_button = new System.Windows.Forms.Button();
            this.pid3EnableG1 = new System.Windows.Forms.Button();
            this.G1_pid2_button = new System.Windows.Forms.Button();
            this.pid2EnableG1 = new System.Windows.Forms.Button();
            this.G1_pid1_button = new System.Windows.Forms.Button();
            this.pid1EnableG1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label108 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.qFactorG1Enable = new System.Windows.Forms.Button();
            this.qfactorLongTauG1_textBox = new System.Windows.Forms.TextBox();
            this.qfactorMaxG1_textBox = new System.Windows.Forms.TextBox();
            this.qfactorShortTauG1_textBox = new System.Windows.Forms.TextBox();
            this.qfactorMinG1_textBox = new System.Windows.Forms.TextBox();
            this.qfactorStartFreG1_textBox = new System.Windows.Forms.TextBox();
            this.qfactorDelayG1_textBox = new System.Windows.Forms.TextBox();
            this.G1_Qfactor_button = new System.Windows.Forms.Button();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.agcMinOutG1_textBox = new System.Windows.Forms.TextBox();
            this.freResonantG1_textBox = new System.Windows.Forms.TextBox();
            this.ResonantG1_button = new System.Windows.Forms.Button();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label133 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.phaseFindG1Enable = new System.Windows.Forms.Button();
            this.minPhaseG1_textBox = new System.Windows.Forms.TextBox();
            this.rightPhaseG1_textBox = new System.Windows.Forms.TextBox();
            this.leftPhaseG1_textBox = new System.Windows.Forms.TextBox();
            this.setTimeG1_textBox = new System.Windows.Forms.TextBox();
            this.phaseFindG1_button = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.tabPage6.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.tabPage27.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage18.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage19.SuspendLayout();
            this.tabPage20.SuspendLayout();
            this.tabPage21.SuspendLayout();
            this.tabControl7.SuspendLayout();
            this.tabPage22.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.tabPage24.SuspendLayout();
            this.tabControl8.SuspendLayout();
            this.tabPage26.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage25.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 35;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label185
            // 
            this.label185.AutoSize = true;
            this.label185.Location = new System.Drawing.Point(168, 284);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(29, 12);
            this.label185.TabIndex = 17;
            this.label185.Text = "0.00";
            // 
            // label184
            // 
            this.label184.AutoSize = true;
            this.label184.Location = new System.Drawing.Point(242, 284);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(29, 12);
            this.label184.TabIndex = 17;
            this.label184.Text = "0.00";
            // 
            // label183
            // 
            this.label183.AutoSize = true;
            this.label183.Location = new System.Drawing.Point(242, 10);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(29, 12);
            this.label183.TabIndex = 16;
            this.label183.Text = "0.00";
            // 
            // Delete_fre_button
            // 
            this.Delete_fre_button.Location = new System.Drawing.Point(77, 5);
            this.Delete_fre_button.Name = "Delete_fre_button";
            this.Delete_fre_button.Size = new System.Drawing.Size(75, 23);
            this.Delete_fre_button.TabIndex = 14;
            this.Delete_fre_button.Text = "清除曲线";
            this.Delete_fre_button.UseVisualStyleBackColor = true;
            this.Delete_fre_button.Click += new System.EventHandler(this.Delete_fre_button_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.G1_dataLineEnable_button);
            this.tabPage6.Controls.Add(this.plt22);
            this.tabPage6.Controls.Add(this.plt21);
            this.tabPage6.Controls.Add(this.label185);
            this.tabPage6.Controls.Add(this.label184);
            this.tabPage6.Controls.Add(this.label183);
            this.tabPage6.Controls.Add(this.label179);
            this.tabPage6.Controls.Add(this.Delete_fre_button);
            this.tabPage6.Controls.Add(this.Scanfre_PhaseB_checkBox);
            this.tabPage6.Controls.Add(this.Scanfre_AmpB_checkBox);
            this.tabPage6.Controls.Add(this.Scanfre_PhaseA_checkBox);
            this.tabPage6.Controls.Add(this.Scanfre_AmpA_checkBox);
            this.tabPage6.Controls.Add(this.label126);
            this.tabPage6.Controls.Add(this.label125);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(472, 575);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "扫频曲线";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // G1_dataLineEnable_button
            // 
            this.G1_dataLineEnable_button.Location = new System.Drawing.Point(414, 13);
            this.G1_dataLineEnable_button.Name = "G1_dataLineEnable_button";
            this.G1_dataLineEnable_button.Size = new System.Drawing.Size(43, 23);
            this.G1_dataLineEnable_button.TabIndex = 20;
            this.G1_dataLineEnable_button.Text = "开";
            this.G1_dataLineEnable_button.UseVisualStyleBackColor = true;
            this.G1_dataLineEnable_button.Click += new System.EventHandler(this.G1_dataLineEnable_button_Click);
            // 
            // plt22
            // 
            this.plt22.Location = new System.Drawing.Point(9, 320);
            this.plt22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt22.Name = "plt22";
            this.plt22.Size = new System.Drawing.Size(457, 244);
            this.plt22.TabIndex = 19;
            // 
            // plt21
            // 
            this.plt21.Location = new System.Drawing.Point(9, 33);
            this.plt21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt21.Name = "plt21";
            this.plt21.Size = new System.Drawing.Size(457, 244);
            this.plt21.TabIndex = 18;
            // 
            // label179
            // 
            this.label179.AutoSize = true;
            this.label179.Location = new System.Drawing.Point(168, 10);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(29, 12);
            this.label179.TabIndex = 15;
            this.label179.Text = "0.00";
            // 
            // Scanfre_PhaseB_checkBox
            // 
            this.Scanfre_PhaseB_checkBox.AutoSize = true;
            this.Scanfre_PhaseB_checkBox.Checked = true;
            this.Scanfre_PhaseB_checkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Scanfre_PhaseB_checkBox.Location = new System.Drawing.Point(354, 288);
            this.Scanfre_PhaseB_checkBox.Name = "Scanfre_PhaseB_checkBox";
            this.Scanfre_PhaseB_checkBox.Size = new System.Drawing.Size(54, 16);
            this.Scanfre_PhaseB_checkBox.TabIndex = 2;
            this.Scanfre_PhaseB_checkBox.Text = "曲线1";
            this.Scanfre_PhaseB_checkBox.UseVisualStyleBackColor = true;
            // 
            // Scanfre_AmpB_checkBox
            // 
            this.Scanfre_AmpB_checkBox.AutoSize = true;
            this.Scanfre_AmpB_checkBox.Checked = true;
            this.Scanfre_AmpB_checkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Scanfre_AmpB_checkBox.Location = new System.Drawing.Point(354, 5);
            this.Scanfre_AmpB_checkBox.Name = "Scanfre_AmpB_checkBox";
            this.Scanfre_AmpB_checkBox.Size = new System.Drawing.Size(54, 16);
            this.Scanfre_AmpB_checkBox.TabIndex = 2;
            this.Scanfre_AmpB_checkBox.Text = "曲线1";
            this.Scanfre_AmpB_checkBox.UseVisualStyleBackColor = true;
            // 
            // Scanfre_PhaseA_checkBox
            // 
            this.Scanfre_PhaseA_checkBox.AutoSize = true;
            this.Scanfre_PhaseA_checkBox.Checked = true;
            this.Scanfre_PhaseA_checkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Scanfre_PhaseA_checkBox.Location = new System.Drawing.Point(294, 288);
            this.Scanfre_PhaseA_checkBox.Name = "Scanfre_PhaseA_checkBox";
            this.Scanfre_PhaseA_checkBox.Size = new System.Drawing.Size(54, 16);
            this.Scanfre_PhaseA_checkBox.TabIndex = 2;
            this.Scanfre_PhaseA_checkBox.Text = "曲线0";
            this.Scanfre_PhaseA_checkBox.UseVisualStyleBackColor = true;
            // 
            // Scanfre_AmpA_checkBox
            // 
            this.Scanfre_AmpA_checkBox.AutoSize = true;
            this.Scanfre_AmpA_checkBox.Checked = true;
            this.Scanfre_AmpA_checkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Scanfre_AmpA_checkBox.Location = new System.Drawing.Point(294, 5);
            this.Scanfre_AmpA_checkBox.Name = "Scanfre_AmpA_checkBox";
            this.Scanfre_AmpA_checkBox.Size = new System.Drawing.Size(54, 16);
            this.Scanfre_AmpA_checkBox.TabIndex = 2;
            this.Scanfre_AmpA_checkBox.Text = "曲线0";
            this.Scanfre_AmpA_checkBox.UseVisualStyleBackColor = true;
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(7, 279);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(53, 12);
            this.label126.TabIndex = 1;
            this.label126.Text = "相频曲线";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(7, 10);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(53, 12);
            this.label125.TabIndex = 1;
            this.label125.Text = "幅频曲线";
            // 
            // SB_IQ_AcheckBox
            // 
            this.SB_IQ_AcheckBox.AutoSize = true;
            this.SB_IQ_AcheckBox.Checked = true;
            this.SB_IQ_AcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SB_IQ_AcheckBox.Location = new System.Drawing.Point(284, 280);
            this.SB_IQ_AcheckBox.Name = "SB_IQ_AcheckBox";
            this.SB_IQ_AcheckBox.Size = new System.Drawing.Size(102, 16);
            this.SB_IQ_AcheckBox.TabIndex = 2;
            this.SB_IQ_AcheckBox.Text = "B通道解调幅值";
            this.SB_IQ_AcheckBox.UseVisualStyleBackColor = true;
            // 
            // SA_IQ_AcheckBox
            // 
            this.SA_IQ_AcheckBox.AutoSize = true;
            this.SA_IQ_AcheckBox.Checked = true;
            this.SA_IQ_AcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SA_IQ_AcheckBox.Location = new System.Drawing.Point(284, 6);
            this.SA_IQ_AcheckBox.Name = "SA_IQ_AcheckBox";
            this.SA_IQ_AcheckBox.Size = new System.Drawing.Size(102, 16);
            this.SA_IQ_AcheckBox.TabIndex = 2;
            this.SA_IQ_AcheckBox.Text = "A通道解调幅值";
            this.SA_IQ_AcheckBox.UseVisualStyleBackColor = true;
            // 
            // SB_IQ_QcheckBox
            // 
            this.SB_IQ_QcheckBox.AutoSize = true;
            this.SB_IQ_QcheckBox.Checked = true;
            this.SB_IQ_QcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SB_IQ_QcheckBox.Location = new System.Drawing.Point(179, 280);
            this.SB_IQ_QcheckBox.Name = "SB_IQ_QcheckBox";
            this.SB_IQ_QcheckBox.Size = new System.Drawing.Size(84, 16);
            this.SB_IQ_QcheckBox.TabIndex = 2;
            this.SB_IQ_QcheckBox.Text = "B通道解调Q";
            this.SB_IQ_QcheckBox.UseVisualStyleBackColor = true;
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "自动",
            "手动",
            "X轴",
            "Y轴"});
            this.comboBox9.Location = new System.Drawing.Point(392, 6);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(74, 20);
            this.comboBox9.TabIndex = 4;
            this.comboBox9.Text = "自动";
            // 
            // SA_IQ_QcheckBox
            // 
            this.SA_IQ_QcheckBox.AutoSize = true;
            this.SA_IQ_QcheckBox.Checked = true;
            this.SA_IQ_QcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SA_IQ_QcheckBox.Location = new System.Drawing.Point(179, 6);
            this.SA_IQ_QcheckBox.Name = "SA_IQ_QcheckBox";
            this.SA_IQ_QcheckBox.Size = new System.Drawing.Size(84, 16);
            this.SA_IQ_QcheckBox.TabIndex = 2;
            this.SA_IQ_QcheckBox.Text = "A通道解调Q";
            this.SA_IQ_QcheckBox.UseVisualStyleBackColor = true;
            // 
            // SB_IQ_IcheckBox
            // 
            this.SB_IQ_IcheckBox.AutoSize = true;
            this.SB_IQ_IcheckBox.Checked = true;
            this.SB_IQ_IcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SB_IQ_IcheckBox.Location = new System.Drawing.Point(70, 280);
            this.SB_IQ_IcheckBox.Name = "SB_IQ_IcheckBox";
            this.SB_IQ_IcheckBox.Size = new System.Drawing.Size(84, 16);
            this.SB_IQ_IcheckBox.TabIndex = 2;
            this.SB_IQ_IcheckBox.Text = "B通道解调I";
            this.SB_IQ_IcheckBox.UseVisualStyleBackColor = true;
            // 
            // SA_IQ_IcheckBox
            // 
            this.SA_IQ_IcheckBox.AutoSize = true;
            this.SA_IQ_IcheckBox.Checked = true;
            this.SA_IQ_IcheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SA_IQ_IcheckBox.Location = new System.Drawing.Point(70, 6);
            this.SA_IQ_IcheckBox.Name = "SA_IQ_IcheckBox";
            this.SA_IQ_IcheckBox.Size = new System.Drawing.Size(84, 16);
            this.SA_IQ_IcheckBox.TabIndex = 2;
            this.SA_IQ_IcheckBox.Text = "A通道解调I";
            this.SA_IQ_IcheckBox.UseVisualStyleBackColor = true;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(6, 293);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(41, 12);
            this.label124.TabIndex = 1;
            this.label124.Text = "模态SB";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(6, 14);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(41, 12);
            this.label123.TabIndex = 1;
            this.label123.Text = "模态SA";
            // 
            // plt1
            // 
            this.plt1.Location = new System.Drawing.Point(28, 14);
            this.plt1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt1.Name = "plt1";
            this.plt1.Size = new System.Drawing.Size(400, 277);
            this.plt1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.SB_IQ_AcheckBox);
            this.tabPage5.Controls.Add(this.SA_IQ_AcheckBox);
            this.tabPage5.Controls.Add(this.SB_IQ_QcheckBox);
            this.tabPage5.Controls.Add(this.comboBox9);
            this.tabPage5.Controls.Add(this.SA_IQ_QcheckBox);
            this.tabPage5.Controls.Add(this.SB_IQ_IcheckBox);
            this.tabPage5.Controls.Add(this.SA_IQ_IcheckBox);
            this.tabPage5.Controls.Add(this.label124);
            this.tabPage5.Controls.Add(this.label123);
            this.tabPage5.Controls.Add(this.plt2);
            this.tabPage5.Controls.Add(this.plt1);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(472, 575);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "IQ曲线";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // plt2
            // 
            this.plt2.Location = new System.Drawing.Point(28, 288);
            this.plt2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt2.Name = "plt2";
            this.plt2.Size = new System.Drawing.Size(400, 277);
            this.plt2.TabIndex = 0;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage5);
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Controls.Add(this.tabPage12);
            this.tabControl3.Controls.Add(this.tabPage27);
            this.tabControl3.Location = new System.Drawing.Point(456, 98);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(480, 601);
            this.tabControl3.TabIndex = 15;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.checkBox2);
            this.tabPage7.Controls.Add(this.checkBox9);
            this.tabPage7.Controls.Add(this.checkBox8);
            this.tabPage7.Controls.Add(this.checkBox5);
            this.tabPage7.Controls.Add(this.checkBox7);
            this.tabPage7.Controls.Add(this.checkBox4);
            this.tabPage7.Controls.Add(this.checkBox6);
            this.tabPage7.Controls.Add(this.checkBox3);
            this.tabPage7.Controls.Add(this.checkBox1);
            this.tabPage7.Controls.Add(this.plt8);
            this.tabPage7.Controls.Add(this.plt7);
            this.tabPage7.Controls.Add(this.plt6);
            this.tabPage7.Controls.Add(this.plt5);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(472, 575);
            this.tabPage7.TabIndex = 2;
            this.tabPage7.Text = "锁相环";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(368, 3);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(72, 16);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "当前频率";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(368, 424);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(72, 16);
            this.checkBox9.TabIndex = 1;
            this.checkBox9.Text = "当前相位";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(368, 275);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(102, 16);
            this.checkBox8.TabIndex = 1;
            this.checkBox8.Text = "A通道解调幅值";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(368, 137);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(102, 16);
            this.checkBox5.TabIndex = 1;
            this.checkBox5.Text = "A通道解调幅值";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(284, 275);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(84, 16);
            this.checkBox7.TabIndex = 1;
            this.checkBox7.Text = "A通道解调Q";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(284, 137);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(84, 16);
            this.checkBox4.TabIndex = 1;
            this.checkBox4.Text = "A通道解调Q";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(189, 275);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(84, 16);
            this.checkBox6.TabIndex = 1;
            this.checkBox6.Text = "A通道解调I";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(189, 137);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(84, 16);
            this.checkBox3.TabIndex = 1;
            this.checkBox3.Text = "A通道解调I";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(284, 3);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(72, 16);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "相位误差";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // plt8
            // 
            this.plt8.Location = new System.Drawing.Point(20, 434);
            this.plt8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt8.Name = "plt8";
            this.plt8.Size = new System.Drawing.Size(417, 131);
            this.plt8.TabIndex = 0;
            // 
            // plt7
            // 
            this.plt7.Location = new System.Drawing.Point(23, 296);
            this.plt7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt7.Name = "plt7";
            this.plt7.Size = new System.Drawing.Size(417, 131);
            this.plt7.TabIndex = 0;
            // 
            // plt6
            // 
            this.plt6.Location = new System.Drawing.Point(20, 149);
            this.plt6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt6.Name = "plt6";
            this.plt6.Size = new System.Drawing.Size(417, 131);
            this.plt6.TabIndex = 0;
            // 
            // plt5
            // 
            this.plt5.Location = new System.Drawing.Point(20, 14);
            this.plt5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt5.Name = "plt5";
            this.plt5.Size = new System.Drawing.Size(417, 131);
            this.plt5.TabIndex = 0;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.checkBox33);
            this.tabPage9.Controls.Add(this.checkBox11);
            this.tabPage9.Controls.Add(this.plt10);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(472, 575);
            this.tabPage9.TabIndex = 4;
            this.tabPage9.Text = "PID";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // checkBox33
            // 
            this.checkBox33.AutoSize = true;
            this.checkBox33.Location = new System.Drawing.Point(385, 14);
            this.checkBox33.Name = "checkBox33";
            this.checkBox33.Size = new System.Drawing.Size(72, 16);
            this.checkBox33.TabIndex = 2;
            this.checkBox33.Text = "输出误差";
            this.checkBox33.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(313, 14);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(72, 16);
            this.checkBox11.TabIndex = 1;
            this.checkBox11.Text = "输出幅值";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // plt10
            // 
            this.plt10.Location = new System.Drawing.Point(37, 19);
            this.plt10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt10.Name = "plt10";
            this.plt10.Size = new System.Drawing.Size(400, 277);
            this.plt10.TabIndex = 0;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.checkBox31);
            this.tabPage12.Controls.Add(this.checkBox10);
            this.tabPage12.Controls.Add(this.plt32);
            this.tabPage12.Controls.Add(this.plt31);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(472, 575);
            this.tabPage12.TabIndex = 5;
            this.tabPage12.Text = "谐振频率";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // checkBox31
            // 
            this.checkBox31.AutoSize = true;
            this.checkBox31.Location = new System.Drawing.Point(364, 289);
            this.checkBox31.Name = "checkBox31";
            this.checkBox31.Size = new System.Drawing.Size(90, 16);
            this.checkBox31.TabIndex = 98;
            this.checkBox31.Text = "AGC最小输出";
            this.checkBox31.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(364, 6);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(48, 16);
            this.checkBox10.TabIndex = 98;
            this.checkBox10.Text = "频率";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // plt32
            // 
            this.plt32.Location = new System.Drawing.Point(34, 290);
            this.plt32.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt32.Name = "plt32";
            this.plt32.Size = new System.Drawing.Size(419, 277);
            this.plt32.TabIndex = 1;
            // 
            // plt31
            // 
            this.plt31.Location = new System.Drawing.Point(34, 6);
            this.plt31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt31.Name = "plt31";
            this.plt31.Size = new System.Drawing.Size(419, 270);
            this.plt31.TabIndex = 0;
            // 
            // tabPage27
            // 
            this.tabPage27.Controls.Add(this.button24);
            this.tabPage27.Controls.Add(this.pltphasefinder1);
            this.tabPage27.Location = new System.Drawing.Point(4, 22);
            this.tabPage27.Name = "tabPage27";
            this.tabPage27.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage27.Size = new System.Drawing.Size(472, 575);
            this.tabPage27.TabIndex = 6;
            this.tabPage27.Text = "最佳相位";
            this.tabPage27.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(347, 14);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(75, 23);
            this.button24.TabIndex = 15;
            this.button24.Text = "清除曲线";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // pltphasefinder1
            // 
            this.pltphasefinder1.Location = new System.Drawing.Point(45, 51);
            this.pltphasefinder1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pltphasefinder1.Name = "pltphasefinder1";
            this.pltphasefinder1.Size = new System.Drawing.Size(400, 277);
            this.pltphasefinder1.TabIndex = 0;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Checked = true;
            this.checkBox17.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox17.Location = new System.Drawing.Point(282, 275);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(102, 16);
            this.checkBox17.TabIndex = 2;
            this.checkBox17.Text = "B通道解调幅值";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // plt18
            // 
            this.plt18.Location = new System.Drawing.Point(36, 434);
            this.plt18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt18.Name = "plt18";
            this.plt18.Size = new System.Drawing.Size(417, 131);
            this.plt18.TabIndex = 0;
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Location = new System.Drawing.Point(367, 278);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(102, 16);
            this.checkBox29.TabIndex = 1;
            this.checkBox29.Text = "A通道解调幅值";
            this.checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Location = new System.Drawing.Point(304, 3);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(72, 16);
            this.checkBox22.TabIndex = 1;
            this.checkBox22.Text = "相位误差";
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // label188
            // 
            this.label188.AutoSize = true;
            this.label188.Location = new System.Drawing.Point(253, 291);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(29, 12);
            this.label188.TabIndex = 15;
            this.label188.Text = "0.00";
            // 
            // label187
            // 
            this.label187.AutoSize = true;
            this.label187.Location = new System.Drawing.Point(180, 292);
            this.label187.Name = "label187";
            this.label187.Size = new System.Drawing.Size(29, 12);
            this.label187.TabIndex = 15;
            this.label187.Text = "0.00";
            // 
            // label186
            // 
            this.label186.AutoSize = true;
            this.label186.Location = new System.Drawing.Point(253, 11);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(29, 12);
            this.label186.TabIndex = 15;
            this.label186.Text = "0.00";
            // 
            // label182
            // 
            this.label182.AutoSize = true;
            this.label182.Location = new System.Drawing.Point(180, 10);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(29, 12);
            this.label182.TabIndex = 15;
            this.label182.Text = "0.00";
            // 
            // Delete_G2fre_button
            // 
            this.Delete_G2fre_button.Location = new System.Drawing.Point(77, 6);
            this.Delete_G2fre_button.Name = "Delete_G2fre_button";
            this.Delete_G2fre_button.Size = new System.Drawing.Size(75, 23);
            this.Delete_G2fre_button.TabIndex = 14;
            this.Delete_G2fre_button.Text = "清除曲线";
            this.Delete_G2fre_button.UseVisualStyleBackColor = true;
            this.Delete_G2fre_button.Click += new System.EventHandler(this.Delete_G2fre_button_Click);
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Checked = true;
            this.checkBox21.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox21.Location = new System.Drawing.Point(377, 287);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(54, 16);
            this.checkBox21.TabIndex = 2;
            this.checkBox21.Text = "曲线1";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Checked = true;
            this.checkBox18.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox18.Location = new System.Drawing.Point(303, 5);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(54, 16);
            this.checkBox18.TabIndex = 2;
            this.checkBox18.Text = "曲线0";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Location = new System.Drawing.Point(382, 3);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(72, 16);
            this.checkBox23.TabIndex = 1;
            this.checkBox23.Text = "当前频率";
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox30
            // 
            this.checkBox30.AutoSize = true;
            this.checkBox30.Location = new System.Drawing.Point(382, 435);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(72, 16);
            this.checkBox30.TabIndex = 1;
            this.checkBox30.Text = "当前相位";
            this.checkBox30.UseVisualStyleBackColor = true;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.checkBox23);
            this.tabPage16.Controls.Add(this.checkBox30);
            this.tabPage16.Controls.Add(this.plt18);
            this.tabPage16.Controls.Add(this.checkBox29);
            this.tabPage16.Controls.Add(this.checkBox22);
            this.tabPage16.Controls.Add(this.checkBox26);
            this.tabPage16.Controls.Add(this.checkBox28);
            this.tabPage16.Controls.Add(this.checkBox25);
            this.tabPage16.Controls.Add(this.plt17);
            this.tabPage16.Controls.Add(this.checkBox27);
            this.tabPage16.Controls.Add(this.checkBox24);
            this.tabPage16.Controls.Add(this.plt16);
            this.tabPage16.Controls.Add(this.plt15);
            this.tabPage16.Location = new System.Drawing.Point(4, 22);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Size = new System.Drawing.Size(472, 575);
            this.tabPage16.TabIndex = 2;
            this.tabPage16.Text = "锁相环";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Location = new System.Drawing.Point(367, 137);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(102, 16);
            this.checkBox26.TabIndex = 1;
            this.checkBox26.Text = "A通道解调幅值";
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Location = new System.Drawing.Point(282, 280);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(84, 16);
            this.checkBox28.TabIndex = 1;
            this.checkBox28.Text = "A通道解调Q";
            this.checkBox28.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Location = new System.Drawing.Point(282, 137);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(84, 16);
            this.checkBox25.TabIndex = 1;
            this.checkBox25.Text = "A通道解调Q";
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // plt17
            // 
            this.plt17.Location = new System.Drawing.Point(36, 299);
            this.plt17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt17.Name = "plt17";
            this.plt17.Size = new System.Drawing.Size(417, 131);
            this.plt17.TabIndex = 0;
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Location = new System.Drawing.Point(187, 283);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(84, 16);
            this.checkBox27.TabIndex = 1;
            this.checkBox27.Text = "A通道解调I";
            this.checkBox27.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Location = new System.Drawing.Point(187, 137);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(84, 16);
            this.checkBox24.TabIndex = 1;
            this.checkBox24.Text = "A通道解调I";
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // plt16
            // 
            this.plt16.Location = new System.Drawing.Point(36, 149);
            this.plt16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt16.Name = "plt16";
            this.plt16.Size = new System.Drawing.Size(417, 131);
            this.plt16.TabIndex = 0;
            // 
            // plt15
            // 
            this.plt15.Location = new System.Drawing.Point(36, 14);
            this.plt15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt15.Name = "plt15";
            this.plt15.Size = new System.Drawing.Size(417, 131);
            this.plt15.TabIndex = 0;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Checked = true;
            this.checkBox20.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox20.Location = new System.Drawing.Point(317, 288);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(54, 16);
            this.checkBox20.TabIndex = 2;
            this.checkBox20.Text = "曲线0";
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Checked = true;
            this.checkBox19.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox19.Location = new System.Drawing.Point(363, 5);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(54, 16);
            this.checkBox19.TabIndex = 2;
            this.checkBox19.Text = "曲线1";
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // label180
            // 
            this.label180.AutoSize = true;
            this.label180.Location = new System.Drawing.Point(6, 13);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(53, 12);
            this.label180.TabIndex = 1;
            this.label180.Text = "幅频曲线";
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.G2_dataLineEnable_button);
            this.tabPage15.Controls.Add(this.plt24);
            this.tabPage15.Controls.Add(this.plt23);
            this.tabPage15.Controls.Add(this.label188);
            this.tabPage15.Controls.Add(this.label187);
            this.tabPage15.Controls.Add(this.label186);
            this.tabPage15.Controls.Add(this.label182);
            this.tabPage15.Controls.Add(this.Delete_G2fre_button);
            this.tabPage15.Controls.Add(this.checkBox21);
            this.tabPage15.Controls.Add(this.checkBox18);
            this.tabPage15.Controls.Add(this.checkBox20);
            this.tabPage15.Controls.Add(this.checkBox19);
            this.tabPage15.Controls.Add(this.label181);
            this.tabPage15.Controls.Add(this.label180);
            this.tabPage15.Location = new System.Drawing.Point(4, 22);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(472, 575);
            this.tabPage15.TabIndex = 1;
            this.tabPage15.Text = "扫频曲线";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // G2_dataLineEnable_button
            // 
            this.G2_dataLineEnable_button.Location = new System.Drawing.Point(423, 13);
            this.G2_dataLineEnable_button.Name = "G2_dataLineEnable_button";
            this.G2_dataLineEnable_button.Size = new System.Drawing.Size(43, 23);
            this.G2_dataLineEnable_button.TabIndex = 100;
            this.G2_dataLineEnable_button.Text = "开";
            this.G2_dataLineEnable_button.UseVisualStyleBackColor = true;
            this.G2_dataLineEnable_button.Click += new System.EventHandler(this.G2_dataLineEnable_button_Click);
            // 
            // plt24
            // 
            this.plt24.Location = new System.Drawing.Point(8, 320);
            this.plt24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt24.Name = "plt24";
            this.plt24.Size = new System.Drawing.Size(457, 244);
            this.plt24.TabIndex = 20;
            // 
            // plt23
            // 
            this.plt23.Location = new System.Drawing.Point(6, 33);
            this.plt23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt23.Name = "plt23";
            this.plt23.Size = new System.Drawing.Size(457, 244);
            this.plt23.TabIndex = 19;
            // 
            // label181
            // 
            this.label181.AutoSize = true;
            this.label181.Location = new System.Drawing.Point(6, 288);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(53, 12);
            this.label181.TabIndex = 1;
            this.label181.Text = "相频曲线";
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Checked = true;
            this.checkBox13.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox13.Location = new System.Drawing.Point(190, 3);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(84, 16);
            this.checkBox13.TabIndex = 2;
            this.checkBox13.Text = "A通道解调Q";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Checked = true;
            this.checkBox15.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox15.Location = new System.Drawing.Point(70, 277);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(84, 16);
            this.checkBox15.TabIndex = 2;
            this.checkBox15.Text = "B通道解调I";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(1266, 10);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(53, 12);
            this.label142.TabIndex = 29;
            this.label142.Text = "定时保存";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(1363, 36);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(23, 12);
            this.label140.TabIndex = 28;
            this.label140.Text = "min";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(1279, 36);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(29, 12);
            this.label139.TabIndex = 27;
            this.label139.Text = "定时";
            // 
            // storage_timetoend_textBox
            // 
            this.storage_timetoend_textBox.Location = new System.Drawing.Point(1313, 29);
            this.storage_timetoend_textBox.Name = "storage_timetoend_textBox";
            this.storage_timetoend_textBox.Size = new System.Drawing.Size(47, 21);
            this.storage_timetoend_textBox.TabIndex = 26;
            // 
            // timer_storage_button
            // 
            this.timer_storage_button.Location = new System.Drawing.Point(1198, 27);
            this.timer_storage_button.Name = "timer_storage_button";
            this.timer_storage_button.Size = new System.Drawing.Size(75, 23);
            this.timer_storage_button.TabIndex = 25;
            this.timer_storage_button.Text = "开始保存";
            this.timer_storage_button.UseVisualStyleBackColor = true;
            // 
            // storage_button
            // 
            this.storage_button.Location = new System.Drawing.Point(1116, 27);
            this.storage_button.Name = "storage_button";
            this.storage_button.Size = new System.Drawing.Size(75, 23);
            this.storage_button.TabIndex = 24;
            this.storage_button.Text = "开始保存";
            this.storage_button.UseVisualStyleBackColor = true;
            this.storage_button.Click += new System.EventHandler(this.storage_button_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(875, 10);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 23;
            this.button9.Text = "清空";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(220, 4);
            this.textBox89.MaxLength = 3276700;
            this.textBox89.Multiline = true;
            this.textBox89.Name = "textBox89";
            this.textBox89.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox89.Size = new System.Drawing.Size(640, 33);
            this.textBox89.TabIndex = 22;
            // 
            // button_switch
            // 
            this.button_switch.BackColor = System.Drawing.SystemColors.Window;
            this.button_switch.Location = new System.Drawing.Point(136, 5);
            this.button_switch.Name = "button_switch";
            this.button_switch.Size = new System.Drawing.Size(75, 23);
            this.button_switch.TabIndex = 21;
            this.button_switch.Text = "START";
            this.button_switch.UseVisualStyleBackColor = false;
            this.button_switch.Click += new System.EventHandler(this.button_switch_Click);
            // 
            // port_list
            // 
            this.port_list.FormattingEnabled = true;
            this.port_list.Location = new System.Drawing.Point(27, 7);
            this.port_list.Name = "port_list";
            this.port_list.Size = new System.Drawing.Size(92, 20);
            this.port_list.TabIndex = 20;
            // 
            // checkBox32
            // 
            this.checkBox32.AutoSize = true;
            this.checkBox32.Location = new System.Drawing.Point(311, 14);
            this.checkBox32.Name = "checkBox32";
            this.checkBox32.Size = new System.Drawing.Size(72, 16);
            this.checkBox32.TabIndex = 1;
            this.checkBox32.Text = "输出幅值";
            this.checkBox32.UseVisualStyleBackColor = true;
            // 
            // plt20
            // 
            this.plt20.Location = new System.Drawing.Point(37, 16);
            this.plt20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt20.Name = "plt20";
            this.plt20.Size = new System.Drawing.Size(400, 277);
            this.plt20.TabIndex = 0;
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.checkBox34);
            this.tabPage18.Controls.Add(this.checkBox32);
            this.tabPage18.Controls.Add(this.plt20);
            this.tabPage18.Location = new System.Drawing.Point(4, 22);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Size = new System.Drawing.Size(472, 575);
            this.tabPage18.TabIndex = 4;
            this.tabPage18.Text = "PID";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // checkBox34
            // 
            this.checkBox34.AutoSize = true;
            this.checkBox34.Location = new System.Drawing.Point(397, 14);
            this.checkBox34.Name = "checkBox34";
            this.checkBox34.Size = new System.Drawing.Size(72, 16);
            this.checkBox34.TabIndex = 4;
            this.checkBox34.Text = "输出误差";
            this.checkBox34.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Checked = true;
            this.checkBox16.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox16.Location = new System.Drawing.Point(190, 277);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(84, 16);
            this.checkBox16.TabIndex = 2;
            this.checkBox16.Text = "B通道解调Q";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(7, 127);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(31, 16);
            this.label32.TabIndex = 3;
            this.label32.Text = "HV4";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.Location = new System.Drawing.Point(219, 116);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(17, 24);
            this.label28.TabIndex = 3;
            this.label28.Text = "DB\r\nφ";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(219, 86);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(17, 24);
            this.label27.TabIndex = 3;
            this.label27.Text = "DA\r\nφ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(220, 53);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(17, 24);
            this.label26.TabIndex = 3;
            this.label26.Text = "SB\r\nφ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(220, 20);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(17, 24);
            this.label25.TabIndex = 3;
            this.label25.Text = "SA\r\nφ";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(7, 97);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(31, 16);
            this.label31.TabIndex = 3;
            this.label31.Text = "HV3";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.Location = new System.Drawing.Point(8, 64);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(31, 16);
            this.label30.TabIndex = 3;
            this.label30.Text = "HV2";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.Location = new System.Drawing.Point(8, 31);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(31, 16);
            this.label29.TabIndex = 3;
            this.label29.Text = "HV1";
            // 
            // HV4_textBox
            // 
            this.HV4_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV4_textBox.Location = new System.Drawing.Point(39, 119);
            this.HV4_textBox.Name = "HV4_textBox";
            this.HV4_textBox.Size = new System.Drawing.Size(65, 26);
            this.HV4_textBox.TabIndex = 1;
            this.HV4_textBox.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.Location = new System.Drawing.Point(105, 127);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(15, 16);
            this.label36.TabIndex = 3;
            this.label36.Text = "V";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.Location = new System.Drawing.Point(105, 97);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(15, 16);
            this.label35.TabIndex = 3;
            this.label35.Text = "V";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.Location = new System.Drawing.Point(105, 64);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(15, 16);
            this.label34.TabIndex = 3;
            this.label34.Text = "V";
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.HV2_textBox);
            this.tabPage13.Controls.Add(this.HV1_textBox);
            this.tabPage13.Controls.Add(this.HV4_textBox);
            this.tabPage13.Controls.Add(this.HV3_textBox);
            this.tabPage13.Controls.Add(this.HV_SB_textBox);
            this.tabPage13.Controls.Add(this.HV_CB_textBox);
            this.tabPage13.Controls.Add(this.HV_SA_textBox);
            this.tabPage13.Controls.Add(this.HV_CA_textBox);
            this.tabPage13.Controls.Add(this.G1_HV_button);
            this.tabPage13.Controls.Add(this.label32);
            this.tabPage13.Controls.Add(this.label28);
            this.tabPage13.Controls.Add(this.label27);
            this.tabPage13.Controls.Add(this.label26);
            this.tabPage13.Controls.Add(this.label25);
            this.tabPage13.Controls.Add(this.label31);
            this.tabPage13.Controls.Add(this.label30);
            this.tabPage13.Controls.Add(this.label29);
            this.tabPage13.Controls.Add(this.G1_MISCbutton);
            this.tabPage13.Controls.Add(this.label36);
            this.tabPage13.Controls.Add(this.label35);
            this.tabPage13.Controls.Add(this.label34);
            this.tabPage13.Controls.Add(this.label33);
            this.tabPage13.Controls.Add(this.label24);
            this.tabPage13.Controls.Add(this.label23);
            this.tabPage13.Controls.Add(this.label22);
            this.tabPage13.Controls.Add(this.label21);
            this.tabPage13.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(415, 169);
            this.tabPage13.TabIndex = 0;
            this.tabPage13.Text = "辅助参数";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // HV2_textBox
            // 
            this.HV2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV2_textBox.Location = new System.Drawing.Point(39, 53);
            this.HV2_textBox.Name = "HV2_textBox";
            this.HV2_textBox.Size = new System.Drawing.Size(65, 26);
            this.HV2_textBox.TabIndex = 1;
            this.HV2_textBox.Text = "0";
            // 
            // HV1_textBox
            // 
            this.HV1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV1_textBox.Location = new System.Drawing.Point(39, 20);
            this.HV1_textBox.Name = "HV1_textBox";
            this.HV1_textBox.Size = new System.Drawing.Size(65, 26);
            this.HV1_textBox.TabIndex = 1;
            this.HV1_textBox.Text = "0";
            // 
            // HV3_textBox
            // 
            this.HV3_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV3_textBox.Location = new System.Drawing.Point(39, 86);
            this.HV3_textBox.Name = "HV3_textBox";
            this.HV3_textBox.Size = new System.Drawing.Size(65, 26);
            this.HV3_textBox.TabIndex = 1;
            this.HV3_textBox.Text = "0";
            // 
            // HV_SB_textBox
            // 
            this.HV_SB_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV_SB_textBox.Location = new System.Drawing.Point(236, 50);
            this.HV_SB_textBox.Name = "HV_SB_textBox";
            this.HV_SB_textBox.Size = new System.Drawing.Size(59, 26);
            this.HV_SB_textBox.TabIndex = 1;
            this.HV_SB_textBox.Text = "0";
            // 
            // HV_CB_textBox
            // 
            this.HV_CB_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV_CB_textBox.Location = new System.Drawing.Point(236, 116);
            this.HV_CB_textBox.Name = "HV_CB_textBox";
            this.HV_CB_textBox.Size = new System.Drawing.Size(59, 26);
            this.HV_CB_textBox.TabIndex = 1;
            this.HV_CB_textBox.Text = "0";
            // 
            // HV_SA_textBox
            // 
            this.HV_SA_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV_SA_textBox.Location = new System.Drawing.Point(237, 17);
            this.HV_SA_textBox.Name = "HV_SA_textBox";
            this.HV_SA_textBox.Size = new System.Drawing.Size(58, 26);
            this.HV_SA_textBox.TabIndex = 1;
            this.HV_SA_textBox.Text = "0";
            // 
            // HV_CA_textBox
            // 
            this.HV_CA_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HV_CA_textBox.Location = new System.Drawing.Point(236, 83);
            this.HV_CA_textBox.Name = "HV_CA_textBox";
            this.HV_CA_textBox.Size = new System.Drawing.Size(59, 26);
            this.HV_CA_textBox.TabIndex = 1;
            this.HV_CA_textBox.Text = "0";
            // 
            // G1_HV_button
            // 
            this.G1_HV_button.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_HV_button.Location = new System.Drawing.Point(121, 78);
            this.G1_HV_button.Name = "G1_HV_button";
            this.G1_HV_button.Size = new System.Drawing.Size(75, 23);
            this.G1_HV_button.TabIndex = 4;
            this.G1_HV_button.Text = "G1发送";
            this.G1_HV_button.UseVisualStyleBackColor = true;
            this.G1_HV_button.Click += new System.EventHandler(this.G1_HV_button_Click);
            // 
            // G1_MISCbutton
            // 
            this.G1_MISCbutton.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_MISCbutton.Location = new System.Drawing.Point(334, 74);
            this.G1_MISCbutton.Name = "G1_MISCbutton";
            this.G1_MISCbutton.Size = new System.Drawing.Size(75, 23);
            this.G1_MISCbutton.TabIndex = 0;
            this.G1_MISCbutton.Text = "G1发送";
            this.G1_MISCbutton.UseVisualStyleBackColor = true;
            this.G1_MISCbutton.Click += new System.EventHandler(this.G1_MISCbutton_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(105, 31);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(15, 16);
            this.label33.TabIndex = 3;
            this.label33.Text = "V";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(300, 127);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(31, 16);
            this.label24.TabIndex = 3;
            this.label24.Text = "deg";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(300, 94);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(31, 16);
            this.label23.TabIndex = 3;
            this.label23.Text = "deg";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(300, 61);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(31, 16);
            this.label22.TabIndex = 3;
            this.label22.Text = "deg";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(301, 28);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(31, 16);
            this.label21.TabIndex = 3;
            this.label21.Text = "deg";
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage13);
            this.tabControl4.Location = new System.Drawing.Point(27, 555);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(423, 195);
            this.tabControl4.TabIndex = 17;
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage14);
            this.tabControl5.Controls.Add(this.tabPage15);
            this.tabControl5.Controls.Add(this.tabPage16);
            this.tabControl5.Controls.Add(this.tabPage18);
            this.tabControl5.Controls.Add(this.tabPage17);
            this.tabControl5.Location = new System.Drawing.Point(938, 98);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(480, 601);
            this.tabControl5.TabIndex = 16;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.checkBox17);
            this.tabPage14.Controls.Add(this.checkBox15);
            this.tabPage14.Controls.Add(this.checkBox13);
            this.tabPage14.Controls.Add(this.checkBox16);
            this.tabPage14.Controls.Add(this.checkBox14);
            this.tabPage14.Controls.Add(this.checkBox12);
            this.tabPage14.Controls.Add(this.comboBox11);
            this.tabPage14.Controls.Add(this.plt12);
            this.tabPage14.Controls.Add(this.plt11);
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(472, 575);
            this.tabPage14.TabIndex = 0;
            this.tabPage14.Text = "IQ曲线";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Checked = true;
            this.checkBox14.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox14.Location = new System.Drawing.Point(282, 3);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(102, 16);
            this.checkBox14.TabIndex = 2;
            this.checkBox14.Text = "A通道解调幅值";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Checked = true;
            this.checkBox12.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox12.Location = new System.Drawing.Point(70, 6);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(84, 16);
            this.checkBox12.TabIndex = 2;
            this.checkBox12.Text = "A通道解调I";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // comboBox11
            // 
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "自动",
            "手动",
            "X轴",
            "Y轴"});
            this.comboBox11.Location = new System.Drawing.Point(395, 4);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(74, 20);
            this.comboBox11.TabIndex = 4;
            this.comboBox11.Text = "自动";
            // 
            // plt12
            // 
            this.plt12.Location = new System.Drawing.Point(28, 288);
            this.plt12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt12.Name = "plt12";
            this.plt12.Size = new System.Drawing.Size(400, 277);
            this.plt12.TabIndex = 0;
            // 
            // plt11
            // 
            this.plt11.Location = new System.Drawing.Point(28, 14);
            this.plt11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt11.Name = "plt11";
            this.plt11.Size = new System.Drawing.Size(400, 277);
            this.plt11.TabIndex = 0;
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.checkBox36);
            this.tabPage17.Controls.Add(this.checkBox35);
            this.tabPage17.Controls.Add(this.plt34);
            this.tabPage17.Controls.Add(this.plt33);
            this.tabPage17.Location = new System.Drawing.Point(4, 22);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage17.Size = new System.Drawing.Size(472, 575);
            this.tabPage17.TabIndex = 5;
            this.tabPage17.Text = "谐振频率";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // checkBox36
            // 
            this.checkBox36.AutoSize = true;
            this.checkBox36.Location = new System.Drawing.Point(350, 276);
            this.checkBox36.Name = "checkBox36";
            this.checkBox36.Size = new System.Drawing.Size(90, 16);
            this.checkBox36.TabIndex = 100;
            this.checkBox36.Text = "AGC最小输出";
            this.checkBox36.UseVisualStyleBackColor = true;
            // 
            // checkBox35
            // 
            this.checkBox35.AutoSize = true;
            this.checkBox35.Location = new System.Drawing.Point(392, 6);
            this.checkBox35.Name = "checkBox35";
            this.checkBox35.Size = new System.Drawing.Size(48, 16);
            this.checkBox35.TabIndex = 99;
            this.checkBox35.Text = "频率";
            this.checkBox35.UseVisualStyleBackColor = true;
            // 
            // plt34
            // 
            this.plt34.Location = new System.Drawing.Point(30, 289);
            this.plt34.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt34.Name = "plt34";
            this.plt34.Size = new System.Drawing.Size(419, 277);
            this.plt34.TabIndex = 2;
            // 
            // plt33
            // 
            this.plt33.Location = new System.Drawing.Point(30, 2);
            this.plt33.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.plt33.Name = "plt33";
            this.plt33.Size = new System.Drawing.Size(419, 270);
            this.plt33.TabIndex = 1;
            // 
            // G1_wait_textBox
            // 
            this.G1_wait_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_wait_textBox.Location = new System.Drawing.Point(88, 136);
            this.G1_wait_textBox.Name = "G1_wait_textBox";
            this.G1_wait_textBox.Size = new System.Drawing.Size(75, 26);
            this.G1_wait_textBox.TabIndex = 1;
            this.G1_wait_textBox.Text = "0";
            // 
            // G1_stepfre_textBox
            // 
            this.G1_stepfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_stepfre_textBox.Location = new System.Drawing.Point(88, 103);
            this.G1_stepfre_textBox.Name = "G1_stepfre_textBox";
            this.G1_stepfre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G1_stepfre_textBox.TabIndex = 1;
            this.G1_stepfre_textBox.Text = "0";
            // 
            // G1_lfre_textBox
            // 
            this.G1_lfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_lfre_textBox.Location = new System.Drawing.Point(88, 70);
            this.G1_lfre_textBox.Name = "G1_lfre_textBox";
            this.G1_lfre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G1_lfre_textBox.TabIndex = 1;
            this.G1_lfre_textBox.Text = "0";
            // 
            // G1_hfre_textBox
            // 
            this.G1_hfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_hfre_textBox.Location = new System.Drawing.Point(88, 37);
            this.G1_hfre_textBox.Name = "G1_hfre_textBox";
            this.G1_hfre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G1_hfre_textBox.TabIndex = 1;
            this.G1_hfre_textBox.Text = "0";
            // 
            // G1_scanfre_button
            // 
            this.G1_scanfre_button.Location = new System.Drawing.Point(329, 100);
            this.G1_scanfre_button.Name = "G1_scanfre_button";
            this.G1_scanfre_button.Size = new System.Drawing.Size(75, 23);
            this.G1_scanfre_button.TabIndex = 0;
            this.G1_scanfre_button.Text = "G1发送";
            this.G1_scanfre_button.UseVisualStyleBackColor = true;
            this.G1_scanfre_button.Click += new System.EventHandler(this.G1_scanfre_button_Click);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(19, 151);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(65, 12);
            this.label56.TabIndex = 2;
            this.label56.Text = "G1等待时间";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(41, 118);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(41, 12);
            this.label55.TabIndex = 2;
            this.label55.Text = "G1步长";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(29, 85);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(53, 12);
            this.label54.TabIndex = 2;
            this.label54.Text = "下限频率";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(31, 52);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(53, 12);
            this.label53.TabIndex = 2;
            this.label53.Text = "上限频率";
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.panel1);
            this.tabPage10.Controls.Add(this.G1_PLL_button);
            this.tabPage10.Controls.Add(this.label176);
            this.tabPage10.Controls.Add(this.label175);
            this.tabPage10.Controls.Add(this.PLL_D_textBox);
            this.tabPage10.Controls.Add(this.PLL_relativeerror_textBox);
            this.tabPage10.Controls.Add(this.PLL_Nowphase_textBox);
            this.tabPage10.Controls.Add(this.PLL_Nowfre_textBox);
            this.tabPage10.Controls.Add(this.PLL_Lockpha_Limiteamp_textBox);
            this.tabPage10.Controls.Add(this.PLL_I_textBox);
            this.tabPage10.Controls.Add(this.PLL_P_textBox);
            this.tabPage10.Controls.Add(this.PLL_middlefre_textBox);
            this.tabPage10.Controls.Add(this.label71);
            this.tabPage10.Controls.Add(this.PLL_Lockphase_textBox);
            this.tabPage10.Controls.Add(this.label70);
            this.tabPage10.Controls.Add(this.label118);
            this.tabPage10.Controls.Add(this.label119);
            this.tabPage10.Controls.Add(this.label117);
            this.tabPage10.Controls.Add(this.label74);
            this.tabPage10.Controls.Add(this.label69);
            this.tabPage10.Controls.Add(this.label75);
            this.tabPage10.Controls.Add(this.label76);
            this.tabPage10.Controls.Add(this.comboBox1);
            this.tabPage10.Controls.Add(this.label173);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(415, 193);
            this.tabPage10.TabIndex = 2;
            this.tabPage10.Text = "PLL";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSalmon;
            this.panel1.Controls.Add(this.G1_modeSwitchEnable);
            this.panel1.Controls.Add(this.label144);
            this.panel1.Controls.Add(this.G1_modeSwitch_button);
            this.panel1.Controls.Add(this.G1_modeSwitchDelay_textBox);
            this.panel1.Controls.Add(this.label143);
            this.panel1.Controls.Add(this.G1_modeCopySB_button);
            this.panel1.Controls.Add(this.G1_modeCopySA_button);
            this.panel1.Location = new System.Drawing.Point(8, 47);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(95, 137);
            this.panel1.TabIndex = 37;
            // 
            // G1_modeSwitchEnable
            // 
            this.G1_modeSwitchEnable.BackColor = System.Drawing.Color.Red;
            this.G1_modeSwitchEnable.Location = new System.Drawing.Point(69, 3);
            this.G1_modeSwitchEnable.Name = "G1_modeSwitchEnable";
            this.G1_modeSwitchEnable.Size = new System.Drawing.Size(22, 17);
            this.G1_modeSwitchEnable.TabIndex = 45;
            this.G1_modeSwitchEnable.UseVisualStyleBackColor = false;
            this.G1_modeSwitchEnable.Click += new System.EventHandler(this.G1_modeSwitchEnable_Click);
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(6, 7);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(53, 12);
            this.label144.TabIndex = 37;
            this.label144.Text = "模态切换";
            // 
            // G1_modeSwitch_button
            // 
            this.G1_modeSwitch_button.Location = new System.Drawing.Point(11, 109);
            this.G1_modeSwitch_button.Name = "G1_modeSwitch_button";
            this.G1_modeSwitch_button.Size = new System.Drawing.Size(75, 23);
            this.G1_modeSwitch_button.TabIndex = 35;
            this.G1_modeSwitch_button.Text = "发送";
            this.G1_modeSwitch_button.UseVisualStyleBackColor = true;
            this.G1_modeSwitch_button.Click += new System.EventHandler(this.G1_modeSwitch_button_Click);
            // 
            // G1_modeSwitchDelay_textBox
            // 
            this.G1_modeSwitchDelay_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_modeSwitchDelay_textBox.Location = new System.Drawing.Point(37, 73);
            this.G1_modeSwitchDelay_textBox.Name = "G1_modeSwitchDelay_textBox";
            this.G1_modeSwitchDelay_textBox.Size = new System.Drawing.Size(57, 26);
            this.G1_modeSwitchDelay_textBox.TabIndex = 15;
            this.G1_modeSwitchDelay_textBox.Text = "0";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label143.Location = new System.Drawing.Point(4, 73);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(29, 24);
            this.label143.TabIndex = 36;
            this.label143.Text = "切换\r\n时间";
            // 
            // G1_modeCopySB_button
            // 
            this.G1_modeCopySB_button.Location = new System.Drawing.Point(49, 37);
            this.G1_modeCopySB_button.Name = "G1_modeCopySB_button";
            this.G1_modeCopySB_button.Size = new System.Drawing.Size(41, 19);
            this.G1_modeCopySB_button.TabIndex = 34;
            this.G1_modeCopySB_button.Text = "SB";
            this.G1_modeCopySB_button.UseVisualStyleBackColor = true;
            this.G1_modeCopySB_button.Click += new System.EventHandler(this.G1_modeCopySB_button_Click);
            // 
            // G1_modeCopySA_button
            // 
            this.G1_modeCopySA_button.Location = new System.Drawing.Point(3, 37);
            this.G1_modeCopySA_button.Name = "G1_modeCopySA_button";
            this.G1_modeCopySA_button.Size = new System.Drawing.Size(41, 19);
            this.G1_modeCopySA_button.TabIndex = 33;
            this.G1_modeCopySA_button.Text = "SA";
            this.G1_modeCopySA_button.UseVisualStyleBackColor = true;
            this.G1_modeCopySA_button.Click += new System.EventHandler(this.G1_modeCopySA_button_Click);
            // 
            // G1_PLL_button
            // 
            this.G1_PLL_button.Location = new System.Drawing.Point(334, 145);
            this.G1_PLL_button.Name = "G1_PLL_button";
            this.G1_PLL_button.Size = new System.Drawing.Size(75, 23);
            this.G1_PLL_button.TabIndex = 14;
            this.G1_PLL_button.Text = "PLL发送";
            this.G1_PLL_button.UseVisualStyleBackColor = true;
            this.G1_PLL_button.Click += new System.EventHandler(this.G1_PLL_button_Click);
            // 
            // label176
            // 
            this.label176.AutoSize = true;
            this.label176.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label176.Location = new System.Drawing.Point(233, 124);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(23, 16);
            this.label176.TabIndex = 13;
            this.label176.Text = "Hz";
            // 
            // label175
            // 
            this.label175.AutoSize = true;
            this.label175.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label175.Location = new System.Drawing.Point(233, 91);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(23, 16);
            this.label175.TabIndex = 13;
            this.label175.Text = "Hz";
            // 
            // PLL_D_textBox
            // 
            this.PLL_D_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_D_textBox.Location = new System.Drawing.Point(273, 113);
            this.PLL_D_textBox.Name = "PLL_D_textBox";
            this.PLL_D_textBox.Size = new System.Drawing.Size(57, 26);
            this.PLL_D_textBox.TabIndex = 6;
            this.PLL_D_textBox.Text = "0";
            // 
            // PLL_relativeerror_textBox
            // 
            this.PLL_relativeerror_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_relativeerror_textBox.Location = new System.Drawing.Point(57, 7);
            this.PLL_relativeerror_textBox.Multiline = true;
            this.PLL_relativeerror_textBox.Name = "PLL_relativeerror_textBox";
            this.PLL_relativeerror_textBox.ReadOnly = true;
            this.PLL_relativeerror_textBox.Size = new System.Drawing.Size(80, 27);
            this.PLL_relativeerror_textBox.TabIndex = 6;
            // 
            // PLL_Nowphase_textBox
            // 
            this.PLL_Nowphase_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_Nowphase_textBox.Location = new System.Drawing.Point(189, 6);
            this.PLL_Nowphase_textBox.Multiline = true;
            this.PLL_Nowphase_textBox.Name = "PLL_Nowphase_textBox";
            this.PLL_Nowphase_textBox.ReadOnly = true;
            this.PLL_Nowphase_textBox.Size = new System.Drawing.Size(75, 27);
            this.PLL_Nowphase_textBox.TabIndex = 6;
            // 
            // PLL_Nowfre_textBox
            // 
            this.PLL_Nowfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_Nowfre_textBox.Location = new System.Drawing.Point(333, 6);
            this.PLL_Nowfre_textBox.Multiline = true;
            this.PLL_Nowfre_textBox.Name = "PLL_Nowfre_textBox";
            this.PLL_Nowfre_textBox.ReadOnly = true;
            this.PLL_Nowfre_textBox.Size = new System.Drawing.Size(75, 27);
            this.PLL_Nowfre_textBox.TabIndex = 6;
            // 
            // PLL_Lockpha_Limiteamp_textBox
            // 
            this.PLL_Lockpha_Limiteamp_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_Lockpha_Limiteamp_textBox.Location = new System.Drawing.Point(161, 113);
            this.PLL_Lockpha_Limiteamp_textBox.Name = "PLL_Lockpha_Limiteamp_textBox";
            this.PLL_Lockpha_Limiteamp_textBox.Size = new System.Drawing.Size(70, 26);
            this.PLL_Lockpha_Limiteamp_textBox.TabIndex = 6;
            this.PLL_Lockpha_Limiteamp_textBox.Text = "0";
            // 
            // PLL_I_textBox
            // 
            this.PLL_I_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_I_textBox.Location = new System.Drawing.Point(273, 80);
            this.PLL_I_textBox.Name = "PLL_I_textBox";
            this.PLL_I_textBox.Size = new System.Drawing.Size(57, 26);
            this.PLL_I_textBox.TabIndex = 7;
            this.PLL_I_textBox.Text = "0";
            // 
            // PLL_P_textBox
            // 
            this.PLL_P_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_P_textBox.Location = new System.Drawing.Point(273, 47);
            this.PLL_P_textBox.Name = "PLL_P_textBox";
            this.PLL_P_textBox.Size = new System.Drawing.Size(57, 26);
            this.PLL_P_textBox.TabIndex = 8;
            this.PLL_P_textBox.Text = "0";
            // 
            // PLL_middlefre_textBox
            // 
            this.PLL_middlefre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_middlefre_textBox.Location = new System.Drawing.Point(161, 80);
            this.PLL_middlefre_textBox.Name = "PLL_middlefre_textBox";
            this.PLL_middlefre_textBox.Size = new System.Drawing.Size(70, 26);
            this.PLL_middlefre_textBox.TabIndex = 7;
            this.PLL_middlefre_textBox.Text = "0";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label71.Location = new System.Drawing.Point(257, 124);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(15, 16);
            this.label71.TabIndex = 10;
            this.label71.Text = "D";
            // 
            // PLL_Lockphase_textBox
            // 
            this.PLL_Lockphase_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PLL_Lockphase_textBox.Location = new System.Drawing.Point(161, 47);
            this.PLL_Lockphase_textBox.Name = "PLL_Lockphase_textBox";
            this.PLL_Lockphase_textBox.Size = new System.Drawing.Size(70, 26);
            this.PLL_Lockphase_textBox.TabIndex = 8;
            this.PLL_Lockphase_textBox.Text = "0";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label70.Location = new System.Drawing.Point(257, 91);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(15, 16);
            this.label70.TabIndex = 11;
            this.label70.Text = "I";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(157, 9);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(29, 24);
            this.label118.TabIndex = 10;
            this.label118.Text = "当前\r\n相位";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(25, 9);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(29, 24);
            this.label119.TabIndex = 10;
            this.label119.Text = "相对\r\n误差";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(301, 9);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(29, 24);
            this.label117.TabIndex = 10;
            this.label117.Text = "当前\r\n频率";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(105, 128);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(53, 12);
            this.label74.TabIndex = 10;
            this.label74.Text = "锁相限幅";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label69.Location = new System.Drawing.Point(257, 58);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(15, 16);
            this.label69.TabIndex = 12;
            this.label69.Text = "P";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(106, 95);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(53, 12);
            this.label75.TabIndex = 11;
            this.label75.Text = "中心频率";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(106, 62);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(53, 12);
            this.label76.TabIndex = 12;
            this.label76.Text = "锁定相位";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "关",
            "SA",
            "SB"});
            this.comboBox1.Location = new System.Drawing.Point(338, 80);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(69, 20);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.Text = "关";
            // 
            // label173
            // 
            this.label173.AutoSize = true;
            this.label173.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label173.Location = new System.Drawing.Point(229, 57);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(31, 16);
            this.label173.TabIndex = 3;
            this.label173.Text = "deg";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label57.Location = new System.Drawing.Point(169, 48);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(23, 16);
            this.label57.TabIndex = 4;
            this.label57.Text = "Hz";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.openLoopEnableG1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.G1_drivefre_textBox);
            this.tabPage1.Controls.Add(this.G1_drivefre_button);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(415, 193);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "开环频率";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // openLoopEnableG1
            // 
            this.openLoopEnableG1.BackColor = System.Drawing.Color.Red;
            this.openLoopEnableG1.Location = new System.Drawing.Point(195, 33);
            this.openLoopEnableG1.Name = "openLoopEnableG1";
            this.openLoopEnableG1.Size = new System.Drawing.Size(22, 17);
            this.openLoopEnableG1.TabIndex = 41;
            this.openLoopEnableG1.UseVisualStyleBackColor = false;
            this.openLoopEnableG1.Click += new System.EventHandler(this.openLoopEnableG1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(256, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Hz";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(130, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "G1驱动\r\n频率";
            // 
            // G1_drivefre_textBox
            // 
            this.G1_drivefre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G1_drivefre_textBox.Location = new System.Drawing.Point(175, 75);
            this.G1_drivefre_textBox.Name = "G1_drivefre_textBox";
            this.G1_drivefre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G1_drivefre_textBox.TabIndex = 1;
            this.G1_drivefre_textBox.Text = "0";
            // 
            // G1_drivefre_button
            // 
            this.G1_drivefre_button.Location = new System.Drawing.Point(175, 127);
            this.G1_drivefre_button.Name = "G1_drivefre_button";
            this.G1_drivefre_button.Size = new System.Drawing.Size(75, 23);
            this.G1_drivefre_button.TabIndex = 0;
            this.G1_drivefre_button.Text = "调频";
            this.G1_drivefre_button.UseVisualStyleBackColor = true;
            this.G1_drivefre_button.Click += new System.EventHandler(this.G1_drivefre_button_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Location = new System.Drawing.Point(27, 98);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(423, 219);
            this.tabControl1.TabIndex = 13;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.radioButton2);
            this.tabPage2.Controls.Add(this.radioButton3);
            this.tabPage2.Controls.Add(this.radioButton1);
            this.tabPage2.Controls.Add(this.label60);
            this.tabPage2.Controls.Add(this.label59);
            this.tabPage2.Controls.Add(this.label58);
            this.tabPage2.Controls.Add(this.label57);
            this.tabPage2.Controls.Add(this.G1_wait_textBox);
            this.tabPage2.Controls.Add(this.G1_stepfre_textBox);
            this.tabPage2.Controls.Add(this.G1_lfre_textBox);
            this.tabPage2.Controls.Add(this.G1_hfre_textBox);
            this.tabPage2.Controls.Add(this.G1_scanfre_button);
            this.tabPage2.Controls.Add(this.label56);
            this.tabPage2.Controls.Add(this.label55);
            this.tabPage2.Controls.Add(this.label54);
            this.tabPage2.Controls.Add(this.label53);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(415, 193);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "扫频";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoCheck = false;
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(218, 103);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(77, 16);
            this.radioButton2.TabIndex = 5;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "单扫/连扫";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.Click += new System.EventHandler(this.radioButton2_Click);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoCheck = false;
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(218, 136);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(71, 16);
            this.radioButton3.TabIndex = 5;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "扫频启停";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.Click += new System.EventHandler(this.radioButton3_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoCheck = false;
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(218, 69);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(77, 16);
            this.radioButton1.TabIndex = 5;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "正扫/反扫";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            this.radioButton1.Click += new System.EventHandler(this.radioButton1_Click);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label60.Location = new System.Drawing.Point(169, 147);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(23, 16);
            this.label60.TabIndex = 4;
            this.label60.Text = "ms";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label59.Location = new System.Drawing.Point(169, 114);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(23, 16);
            this.label59.TabIndex = 4;
            this.label59.Text = "Hz";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label58.Location = new System.Drawing.Point(169, 81);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(23, 16);
            this.label58.TabIndex = 4;
            this.label58.Text = "Hz";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(1127, 11);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(53, 12);
            this.label141.TabIndex = 30;
            this.label141.Text = "手动保存";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(184, 70);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 31;
            this.button1.Text = "G1PLL";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(184, 43);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 32;
            this.button2.Text = "G1扫频";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1434, 14);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 33;
            this.button3.Text = "G2扫频";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1434, 43);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 34;
            this.button4.Text = "G2PLL";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // openLoopLedG1
            // 
            this.openLoopLedG1.BackColor = System.Drawing.Color.Red;
            this.openLoopLedG1.Location = new System.Drawing.Point(46, 75);
            this.openLoopLedG1.Name = "openLoopLedG1";
            this.openLoopLedG1.Size = new System.Drawing.Size(22, 17);
            this.openLoopLedG1.TabIndex = 35;
            this.openLoopLedG1.UseVisualStyleBackColor = false;
            // 
            // sweepLedG1
            // 
            this.sweepLedG1.BackColor = System.Drawing.Color.Red;
            this.sweepLedG1.Location = new System.Drawing.Point(97, 75);
            this.sweepLedG1.Name = "sweepLedG1";
            this.sweepLedG1.Size = new System.Drawing.Size(22, 17);
            this.sweepLedG1.TabIndex = 36;
            this.sweepLedG1.UseVisualStyleBackColor = false;
            // 
            // pllLedG1
            // 
            this.pllLedG1.BackColor = System.Drawing.Color.Red;
            this.pllLedG1.Location = new System.Drawing.Point(147, 75);
            this.pllLedG1.Name = "pllLedG1";
            this.pllLedG1.Size = new System.Drawing.Size(22, 17);
            this.pllLedG1.TabIndex = 37;
            this.pllLedG1.UseVisualStyleBackColor = false;
            // 
            // openLoopLedG2
            // 
            this.openLoopLedG2.BackColor = System.Drawing.Color.Red;
            this.openLoopLedG2.Location = new System.Drawing.Point(1439, 88);
            this.openLoopLedG2.Name = "openLoopLedG2";
            this.openLoopLedG2.Size = new System.Drawing.Size(22, 17);
            this.openLoopLedG2.TabIndex = 38;
            this.openLoopLedG2.UseVisualStyleBackColor = false;
            // 
            // sweepLedG2
            // 
            this.sweepLedG2.BackColor = System.Drawing.Color.Red;
            this.sweepLedG2.Location = new System.Drawing.Point(1485, 88);
            this.sweepLedG2.Name = "sweepLedG2";
            this.sweepLedG2.Size = new System.Drawing.Size(22, 17);
            this.sweepLedG2.TabIndex = 39;
            this.sweepLedG2.UseVisualStyleBackColor = false;
            // 
            // pllLedG2
            // 
            this.pllLedG2.BackColor = System.Drawing.Color.Red;
            this.pllLedG2.Location = new System.Drawing.Point(1536, 88);
            this.pllLedG2.Name = "pllLedG2";
            this.pllLedG2.Size = new System.Drawing.Size(22, 17);
            this.pllLedG2.TabIndex = 40;
            this.pllLedG2.UseVisualStyleBackColor = false;
            // 
            // tabControl6
            // 
            this.tabControl6.Controls.Add(this.tabPage19);
            this.tabControl6.Controls.Add(this.tabPage20);
            this.tabControl6.Controls.Add(this.tabPage21);
            this.tabControl6.Location = new System.Drawing.Point(1420, 102);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(453, 220);
            this.tabControl6.TabIndex = 41;
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.openLoopEnableG2);
            this.tabPage19.Controls.Add(this.label4);
            this.tabPage19.Controls.Add(this.label2);
            this.tabPage19.Controls.Add(this.G2_drivefre_textBox);
            this.tabPage19.Controls.Add(this.G2_drivefre_button);
            this.tabPage19.Location = new System.Drawing.Point(4, 22);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage19.Size = new System.Drawing.Size(445, 194);
            this.tabPage19.TabIndex = 0;
            this.tabPage19.Text = "开环频率";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // openLoopEnableG2
            // 
            this.openLoopEnableG2.BackColor = System.Drawing.Color.Red;
            this.openLoopEnableG2.Location = new System.Drawing.Point(147, 47);
            this.openLoopEnableG2.Name = "openLoopEnableG2";
            this.openLoopEnableG2.Size = new System.Drawing.Size(22, 17);
            this.openLoopEnableG2.TabIndex = 47;
            this.openLoopEnableG2.UseVisualStyleBackColor = false;
            this.openLoopEnableG2.Click += new System.EventHandler(this.openLoopEnableG2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(273, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 16);
            this.label4.TabIndex = 46;
            this.label4.Text = "Hz";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(145, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 24);
            this.label2.TabIndex = 45;
            this.label2.Text = "G2驱动\r\n频率";
            // 
            // G2_drivefre_textBox
            // 
            this.G2_drivefre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_drivefre_textBox.Location = new System.Drawing.Point(192, 93);
            this.G2_drivefre_textBox.Name = "G2_drivefre_textBox";
            this.G2_drivefre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_drivefre_textBox.TabIndex = 44;
            this.G2_drivefre_textBox.Text = "0";
            // 
            // G2_drivefre_button
            // 
            this.G2_drivefre_button.Location = new System.Drawing.Point(192, 145);
            this.G2_drivefre_button.Name = "G2_drivefre_button";
            this.G2_drivefre_button.Size = new System.Drawing.Size(75, 23);
            this.G2_drivefre_button.TabIndex = 43;
            this.G2_drivefre_button.Text = "调频";
            this.G2_drivefre_button.UseVisualStyleBackColor = true;
            this.G2_drivefre_button.Click += new System.EventHandler(this.G2_drivefre_button_Click);
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.radioButton6);
            this.tabPage20.Controls.Add(this.radioButton5);
            this.tabPage20.Controls.Add(this.radioButton4);
            this.tabPage20.Controls.Add(this.label68);
            this.tabPage20.Controls.Add(this.label67);
            this.tabPage20.Controls.Add(this.label66);
            this.tabPage20.Controls.Add(this.label65);
            this.tabPage20.Controls.Add(this.G2_waitfre_textBox);
            this.tabPage20.Controls.Add(this.G2_stepfre_textBox);
            this.tabPage20.Controls.Add(this.G2_lfre_textBox);
            this.tabPage20.Controls.Add(this.G2_hfre_textBox);
            this.tabPage20.Controls.Add(this.label64);
            this.tabPage20.Controls.Add(this.G2_scanfre_button);
            this.tabPage20.Controls.Add(this.label63);
            this.tabPage20.Controls.Add(this.label62);
            this.tabPage20.Controls.Add(this.label61);
            this.tabPage20.Location = new System.Drawing.Point(4, 22);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage20.Size = new System.Drawing.Size(445, 194);
            this.tabPage20.TabIndex = 1;
            this.tabPage20.Text = "扫频";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoCheck = false;
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(235, 85);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(77, 16);
            this.radioButton6.TabIndex = 19;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "单扫/连扫";
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.Click += new System.EventHandler(this.radioButton6_Click);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoCheck = false;
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(235, 113);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(71, 16);
            this.radioButton5.TabIndex = 20;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "扫频启停";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.Click += new System.EventHandler(this.radioButton5_Click);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoCheck = false;
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(235, 47);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(77, 16);
            this.radioButton4.TabIndex = 21;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "正扫/反扫";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.Click += new System.EventHandler(this.radioButton4_Click);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label68.Location = new System.Drawing.Point(186, 131);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(23, 16);
            this.label68.TabIndex = 15;
            this.label68.Text = "ms";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label67.Location = new System.Drawing.Point(186, 98);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(23, 16);
            this.label67.TabIndex = 16;
            this.label67.Text = "Hz";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label66.Location = new System.Drawing.Point(186, 65);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(23, 16);
            this.label66.TabIndex = 17;
            this.label66.Text = "Hz";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label65.Location = new System.Drawing.Point(186, 32);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(23, 16);
            this.label65.TabIndex = 18;
            this.label65.Text = "Hz";
            // 
            // G2_waitfre_textBox
            // 
            this.G2_waitfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_waitfre_textBox.Location = new System.Drawing.Point(105, 120);
            this.G2_waitfre_textBox.Name = "G2_waitfre_textBox";
            this.G2_waitfre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_waitfre_textBox.TabIndex = 7;
            this.G2_waitfre_textBox.Text = "0";
            // 
            // G2_stepfre_textBox
            // 
            this.G2_stepfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_stepfre_textBox.Location = new System.Drawing.Point(105, 87);
            this.G2_stepfre_textBox.Name = "G2_stepfre_textBox";
            this.G2_stepfre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_stepfre_textBox.TabIndex = 8;
            this.G2_stepfre_textBox.Text = "0";
            // 
            // G2_lfre_textBox
            // 
            this.G2_lfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_lfre_textBox.Location = new System.Drawing.Point(105, 54);
            this.G2_lfre_textBox.Name = "G2_lfre_textBox";
            this.G2_lfre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_lfre_textBox.TabIndex = 9;
            this.G2_lfre_textBox.Text = "0";
            // 
            // G2_hfre_textBox
            // 
            this.G2_hfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_hfre_textBox.Location = new System.Drawing.Point(105, 21);
            this.G2_hfre_textBox.Name = "G2_hfre_textBox";
            this.G2_hfre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_hfre_textBox.TabIndex = 10;
            this.G2_hfre_textBox.Text = "0";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(36, 135);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(65, 12);
            this.label64.TabIndex = 11;
            this.label64.Text = "G2等待时间";
            // 
            // G2_scanfre_button
            // 
            this.G2_scanfre_button.Location = new System.Drawing.Point(364, 82);
            this.G2_scanfre_button.Name = "G2_scanfre_button";
            this.G2_scanfre_button.Size = new System.Drawing.Size(75, 23);
            this.G2_scanfre_button.TabIndex = 6;
            this.G2_scanfre_button.Text = "G2发送";
            this.G2_scanfre_button.UseVisualStyleBackColor = true;
            this.G2_scanfre_button.Click += new System.EventHandler(this.G2_scanfre_button_Click);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(58, 102);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(41, 12);
            this.label63.TabIndex = 12;
            this.label63.Text = "G2步长";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(46, 69);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(53, 12);
            this.label62.TabIndex = 13;
            this.label62.Text = "下限频率";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(48, 36);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(53, 12);
            this.label61.TabIndex = 14;
            this.label61.Text = "上限频率";
            // 
            // tabPage21
            // 
            this.tabPage21.Controls.Add(this.G2_PLL_button);
            this.tabPage21.Controls.Add(this.label178);
            this.tabPage21.Controls.Add(this.label177);
            this.tabPage21.Controls.Add(this.G2_PLL_D_textBox);
            this.tabPage21.Controls.Add(this.G2_PLL_Lockpha_Limiteamp_textBox);
            this.tabPage21.Controls.Add(this.G2_PLL_relativeerror_textBox);
            this.tabPage21.Controls.Add(this.G2_PLL_Nowphase_textBox);
            this.tabPage21.Controls.Add(this.G2_PLL_Nowfre_textBox);
            this.tabPage21.Controls.Add(this.G2_PLL_I_textBox);
            this.tabPage21.Controls.Add(this.G2_PLL_P_textBox);
            this.tabPage21.Controls.Add(this.G2_PLL_middlefre_textBox);
            this.tabPage21.Controls.Add(this.label80);
            this.tabPage21.Controls.Add(this.G2_PLL_Lockphase_textBox);
            this.tabPage21.Controls.Add(this.label79);
            this.tabPage21.Controls.Add(this.label78);
            this.tabPage21.Controls.Add(this.label122);
            this.tabPage21.Controls.Add(this.label77);
            this.tabPage21.Controls.Add(this.label121);
            this.tabPage21.Controls.Add(this.label120);
            this.tabPage21.Controls.Add(this.label73);
            this.tabPage21.Controls.Add(this.label72);
            this.tabPage21.Controls.Add(this.comboBox2);
            this.tabPage21.Controls.Add(this.label174);
            this.tabPage21.Location = new System.Drawing.Point(4, 22);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Size = new System.Drawing.Size(445, 194);
            this.tabPage21.TabIndex = 2;
            this.tabPage21.Text = "PLL";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // G2_PLL_button
            // 
            this.G2_PLL_button.Location = new System.Drawing.Point(250, 161);
            this.G2_PLL_button.Name = "G2_PLL_button";
            this.G2_PLL_button.Size = new System.Drawing.Size(75, 23);
            this.G2_PLL_button.TabIndex = 37;
            this.G2_PLL_button.Text = "PLL发送";
            this.G2_PLL_button.UseVisualStyleBackColor = true;
            this.G2_PLL_button.Click += new System.EventHandler(this.G2_PLL_button_Click);
            // 
            // label178
            // 
            this.label178.AutoSize = true;
            this.label178.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label178.Location = new System.Drawing.Point(228, 124);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(23, 16);
            this.label178.TabIndex = 36;
            this.label178.Text = "Hz";
            // 
            // label177
            // 
            this.label177.AutoSize = true;
            this.label177.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label177.Location = new System.Drawing.Point(228, 91);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(23, 16);
            this.label177.TabIndex = 35;
            this.label177.Text = "Hz";
            // 
            // G2_PLL_D_textBox
            // 
            this.G2_PLL_D_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_PLL_D_textBox.Location = new System.Drawing.Point(268, 113);
            this.G2_PLL_D_textBox.Multiline = true;
            this.G2_PLL_D_textBox.Name = "G2_PLL_D_textBox";
            this.G2_PLL_D_textBox.Size = new System.Drawing.Size(57, 27);
            this.G2_PLL_D_textBox.TabIndex = 17;
            this.G2_PLL_D_textBox.Text = "0";
            // 
            // G2_PLL_Lockpha_Limiteamp_textBox
            // 
            this.G2_PLL_Lockpha_Limiteamp_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_PLL_Lockpha_Limiteamp_textBox.Location = new System.Drawing.Point(150, 113);
            this.G2_PLL_Lockpha_Limiteamp_textBox.Name = "G2_PLL_Lockpha_Limiteamp_textBox";
            this.G2_PLL_Lockpha_Limiteamp_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_PLL_Lockpha_Limiteamp_textBox.TabIndex = 18;
            this.G2_PLL_Lockpha_Limiteamp_textBox.Text = "0";
            // 
            // G2_PLL_relativeerror_textBox
            // 
            this.G2_PLL_relativeerror_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_PLL_relativeerror_textBox.Location = new System.Drawing.Point(44, 11);
            this.G2_PLL_relativeerror_textBox.Multiline = true;
            this.G2_PLL_relativeerror_textBox.Name = "G2_PLL_relativeerror_textBox";
            this.G2_PLL_relativeerror_textBox.ReadOnly = true;
            this.G2_PLL_relativeerror_textBox.Size = new System.Drawing.Size(81, 27);
            this.G2_PLL_relativeerror_textBox.TabIndex = 19;
            // 
            // G2_PLL_Nowphase_textBox
            // 
            this.G2_PLL_Nowphase_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_PLL_Nowphase_textBox.Location = new System.Drawing.Point(208, 11);
            this.G2_PLL_Nowphase_textBox.Multiline = true;
            this.G2_PLL_Nowphase_textBox.Name = "G2_PLL_Nowphase_textBox";
            this.G2_PLL_Nowphase_textBox.ReadOnly = true;
            this.G2_PLL_Nowphase_textBox.Size = new System.Drawing.Size(77, 27);
            this.G2_PLL_Nowphase_textBox.TabIndex = 20;
            // 
            // G2_PLL_Nowfre_textBox
            // 
            this.G2_PLL_Nowfre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_PLL_Nowfre_textBox.Location = new System.Drawing.Point(354, 11);
            this.G2_PLL_Nowfre_textBox.Multiline = true;
            this.G2_PLL_Nowfre_textBox.Name = "G2_PLL_Nowfre_textBox";
            this.G2_PLL_Nowfre_textBox.ReadOnly = true;
            this.G2_PLL_Nowfre_textBox.Size = new System.Drawing.Size(85, 27);
            this.G2_PLL_Nowfre_textBox.TabIndex = 21;
            // 
            // G2_PLL_I_textBox
            // 
            this.G2_PLL_I_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_PLL_I_textBox.Location = new System.Drawing.Point(268, 80);
            this.G2_PLL_I_textBox.Multiline = true;
            this.G2_PLL_I_textBox.Name = "G2_PLL_I_textBox";
            this.G2_PLL_I_textBox.Size = new System.Drawing.Size(57, 27);
            this.G2_PLL_I_textBox.TabIndex = 22;
            this.G2_PLL_I_textBox.Text = "0";
            // 
            // G2_PLL_P_textBox
            // 
            this.G2_PLL_P_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_PLL_P_textBox.Location = new System.Drawing.Point(268, 49);
            this.G2_PLL_P_textBox.Multiline = true;
            this.G2_PLL_P_textBox.Name = "G2_PLL_P_textBox";
            this.G2_PLL_P_textBox.Size = new System.Drawing.Size(57, 27);
            this.G2_PLL_P_textBox.TabIndex = 24;
            this.G2_PLL_P_textBox.Text = "0";
            // 
            // G2_PLL_middlefre_textBox
            // 
            this.G2_PLL_middlefre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_PLL_middlefre_textBox.Location = new System.Drawing.Point(150, 80);
            this.G2_PLL_middlefre_textBox.Name = "G2_PLL_middlefre_textBox";
            this.G2_PLL_middlefre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_PLL_middlefre_textBox.TabIndex = 23;
            this.G2_PLL_middlefre_textBox.Text = "0";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label80.Location = new System.Drawing.Point(251, 124);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(15, 16);
            this.label80.TabIndex = 29;
            this.label80.Text = "D";
            // 
            // G2_PLL_Lockphase_textBox
            // 
            this.G2_PLL_Lockphase_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_PLL_Lockphase_textBox.Location = new System.Drawing.Point(150, 47);
            this.G2_PLL_Lockphase_textBox.Name = "G2_PLL_Lockphase_textBox";
            this.G2_PLL_Lockphase_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_PLL_Lockphase_textBox.TabIndex = 25;
            this.G2_PLL_Lockphase_textBox.Text = "0";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label79.Location = new System.Drawing.Point(251, 91);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(15, 16);
            this.label79.TabIndex = 31;
            this.label79.Text = "I";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(91, 128);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(53, 12);
            this.label78.TabIndex = 30;
            this.label78.Text = "锁定限幅";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(178, 14);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(29, 24);
            this.label122.TabIndex = 28;
            this.label122.Text = "当前\r\n相位";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label77.Location = new System.Drawing.Point(251, 58);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(15, 16);
            this.label77.TabIndex = 33;
            this.label77.Text = "P";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(9, 11);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(29, 24);
            this.label121.TabIndex = 27;
            this.label121.Text = "相对\r\n误差";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(324, 11);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(29, 24);
            this.label120.TabIndex = 26;
            this.label120.Text = "当前\r\n频率";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(92, 95);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(53, 12);
            this.label73.TabIndex = 32;
            this.label73.Text = "中心频率";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(91, 62);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(53, 12);
            this.label72.TabIndex = 34;
            this.label72.Text = "锁定相位";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "关",
            "SA",
            "SB"});
            this.comboBox2.Location = new System.Drawing.Point(126, 164);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(69, 20);
            this.comboBox2.TabIndex = 15;
            this.comboBox2.Text = "关";
            // 
            // label174
            // 
            this.label174.AutoSize = true;
            this.label174.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label174.Location = new System.Drawing.Point(223, 57);
            this.label174.Name = "label174";
            this.label174.Size = new System.Drawing.Size(31, 16);
            this.label174.TabIndex = 16;
            this.label174.Text = "deg";
            // 
            // tabControl7
            // 
            this.tabControl7.Controls.Add(this.tabPage22);
            this.tabControl7.Controls.Add(this.tabPage8);
            this.tabControl7.Controls.Add(this.tabPage23);
            this.tabControl7.Controls.Add(this.tabPage24);
            this.tabControl7.Location = new System.Drawing.Point(1420, 328);
            this.tabControl7.Name = "tabControl7";
            this.tabControl7.SelectedIndex = 0;
            this.tabControl7.Size = new System.Drawing.Size(453, 228);
            this.tabControl7.TabIndex = 42;
            // 
            // tabPage22
            // 
            this.tabPage22.Controls.Add(this.label92);
            this.tabPage22.Controls.Add(this.G2_CMD_OPENLOOP_ACT_button);
            this.tabPage22.Controls.Add(this.label90);
            this.tabPage22.Controls.Add(this.label89);
            this.tabPage22.Controls.Add(this.label88);
            this.tabPage22.Controls.Add(this.label87);
            this.tabPage22.Controls.Add(this.label86);
            this.tabPage22.Controls.Add(this.label85);
            this.tabPage22.Controls.Add(this.label81);
            this.tabPage22.Controls.Add(this.label82);
            this.tabPage22.Controls.Add(this.pidAmpOutputG2_textBox);
            this.tabPage22.Controls.Add(this.pidAmpErrorG2_textBox);
            this.tabPage22.Controls.Add(this.label83);
            this.tabPage22.Controls.Add(this.label84);
            this.tabPage22.Controls.Add(this.G2_pid4_button);
            this.tabPage22.Controls.Add(this.pid4EnableG2);
            this.tabPage22.Controls.Add(this.pid4DG2);
            this.tabPage22.Controls.Add(this.pid4IG2);
            this.tabPage22.Controls.Add(this.pid4PG2);
            this.tabPage22.Controls.Add(this.pid4LimitAmpG2);
            this.tabPage22.Controls.Add(this.pid4MiddleAmpG2);
            this.tabPage22.Controls.Add(this.pid4LockAmpG2);
            this.tabPage22.Controls.Add(this.G2_pid3_button);
            this.tabPage22.Controls.Add(this.pid3EnableG2);
            this.tabPage22.Controls.Add(this.pid3DG2);
            this.tabPage22.Controls.Add(this.pid3IG2);
            this.tabPage22.Controls.Add(this.pid3PG2);
            this.tabPage22.Controls.Add(this.pid3LimitAmpG2);
            this.tabPage22.Controls.Add(this.pid3MiddleAmpG2);
            this.tabPage22.Controls.Add(this.pid3LockAmpG2);
            this.tabPage22.Controls.Add(this.G2_pid2_button);
            this.tabPage22.Controls.Add(this.pid2EnableG2);
            this.tabPage22.Controls.Add(this.pid2DG2);
            this.tabPage22.Controls.Add(this.pid2IG2);
            this.tabPage22.Controls.Add(this.pid2PG2);
            this.tabPage22.Controls.Add(this.pid2LimitAmpG2);
            this.tabPage22.Controls.Add(this.pid2MiddleAmpG2);
            this.tabPage22.Controls.Add(this.pid2LockAmpG2);
            this.tabPage22.Controls.Add(this.G2_pid1_button);
            this.tabPage22.Controls.Add(this.pid1EnableG2);
            this.tabPage22.Controls.Add(this.pid1DG2);
            this.tabPage22.Controls.Add(this.pid1IG2);
            this.tabPage22.Controls.Add(this.pid1PG2);
            this.tabPage22.Controls.Add(this.pid1LimitAmpG2);
            this.tabPage22.Controls.Add(this.pid1MiddleAmpG2);
            this.tabPage22.Controls.Add(this.pid1LockAmpG2);
            this.tabPage22.Controls.Add(this.G2_Openloop_BC_textBox);
            this.tabPage22.Controls.Add(this.label13);
            this.tabPage22.Controls.Add(this.label20);
            this.tabPage22.Controls.Add(this.label19);
            this.tabPage22.Controls.Add(this.label18);
            this.tabPage22.Controls.Add(this.label17);
            this.tabPage22.Controls.Add(this.G2_Opebloop_BS_textBox);
            this.tabPage22.Controls.Add(this.G2_Openloop_AC_textBox);
            this.tabPage22.Controls.Add(this.G2_Openloop_AS_textBox);
            this.tabPage22.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage22.Location = new System.Drawing.Point(4, 22);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage22.Size = new System.Drawing.Size(445, 202);
            this.tabPage22.TabIndex = 0;
            this.tabPage22.Text = "开环/PID";
            this.tabPage22.UseVisualStyleBackColor = true;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label92.Location = new System.Drawing.Point(85, 11);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(29, 12);
            this.label92.TabIndex = 115;
            this.label92.Text = "状态";
            // 
            // G2_CMD_OPENLOOP_ACT_button
            // 
            this.G2_CMD_OPENLOOP_ACT_button.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_CMD_OPENLOOP_ACT_button.Location = new System.Drawing.Point(15, 173);
            this.G2_CMD_OPENLOOP_ACT_button.Name = "G2_CMD_OPENLOOP_ACT_button";
            this.G2_CMD_OPENLOOP_ACT_button.Size = new System.Drawing.Size(75, 23);
            this.G2_CMD_OPENLOOP_ACT_button.TabIndex = 114;
            this.G2_CMD_OPENLOOP_ACT_button.Text = "G2发送";
            this.G2_CMD_OPENLOOP_ACT_button.UseVisualStyleBackColor = true;
            this.G2_CMD_OPENLOOP_ACT_button.Click += new System.EventHandler(this.G2_CMD_OPENLOOP_ACT_button_Click_1);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label90.Location = new System.Drawing.Point(351, 13);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(15, 16);
            this.label90.TabIndex = 113;
            this.label90.Text = "D";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label89.Location = new System.Drawing.Point(305, 11);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(15, 16);
            this.label89.TabIndex = 112;
            this.label89.Text = "I";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label88.Location = new System.Drawing.Point(251, 11);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(15, 16);
            this.label88.TabIndex = 111;
            this.label88.Text = "P";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label87.Location = new System.Drawing.Point(206, 4);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(29, 24);
            this.label87.TabIndex = 110;
            this.label87.Text = "稳幅\r\n限幅";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label86.Location = new System.Drawing.Point(161, 4);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(29, 24);
            this.label86.TabIndex = 109;
            this.label86.Text = "中心\r\n幅值";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label85.Location = new System.Drawing.Point(118, 4);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(29, 24);
            this.label85.TabIndex = 108;
            this.label85.Text = "锁定\r\n幅值";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label81.Location = new System.Drawing.Point(390, 176);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(23, 16);
            this.label81.TabIndex = 106;
            this.label81.Text = "mV";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label82.Location = new System.Drawing.Point(231, 180);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(23, 16);
            this.label82.TabIndex = 107;
            this.label82.Text = "mV";
            // 
            // pidAmpOutputG2_textBox
            // 
            this.pidAmpOutputG2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pidAmpOutputG2_textBox.Location = new System.Drawing.Point(308, 167);
            this.pidAmpOutputG2_textBox.Multiline = true;
            this.pidAmpOutputG2_textBox.Name = "pidAmpOutputG2_textBox";
            this.pidAmpOutputG2_textBox.ReadOnly = true;
            this.pidAmpOutputG2_textBox.Size = new System.Drawing.Size(84, 27);
            this.pidAmpOutputG2_textBox.TabIndex = 102;
            // 
            // pidAmpErrorG2_textBox
            // 
            this.pidAmpErrorG2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pidAmpErrorG2_textBox.Location = new System.Drawing.Point(150, 169);
            this.pidAmpErrorG2_textBox.Multiline = true;
            this.pidAmpErrorG2_textBox.Name = "pidAmpErrorG2_textBox";
            this.pidAmpErrorG2_textBox.ReadOnly = true;
            this.pidAmpErrorG2_textBox.Size = new System.Drawing.Size(79, 27);
            this.pidAmpErrorG2_textBox.TabIndex = 103;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label83.Location = new System.Drawing.Point(258, 181);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(53, 12);
            this.label83.TabIndex = 104;
            this.label83.Text = "输出幅值";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label84.Location = new System.Drawing.Point(99, 184);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(53, 12);
            this.label84.TabIndex = 105;
            this.label84.Text = "幅值误差";
            // 
            // G2_pid4_button
            // 
            this.G2_pid4_button.BackColor = System.Drawing.SystemColors.Window;
            this.G2_pid4_button.Location = new System.Drawing.Point(384, 141);
            this.G2_pid4_button.Name = "G2_pid4_button";
            this.G2_pid4_button.Size = new System.Drawing.Size(22, 17);
            this.G2_pid4_button.TabIndex = 101;
            this.G2_pid4_button.UseVisualStyleBackColor = false;
            this.G2_pid4_button.Click += new System.EventHandler(this.G2_pid4_button_Click);
            // 
            // pid4EnableG2
            // 
            this.pid4EnableG2.BackColor = System.Drawing.Color.Red;
            this.pid4EnableG2.Location = new System.Drawing.Point(91, 141);
            this.pid4EnableG2.Name = "pid4EnableG2";
            this.pid4EnableG2.Size = new System.Drawing.Size(22, 17);
            this.pid4EnableG2.TabIndex = 100;
            this.pid4EnableG2.UseVisualStyleBackColor = false;
            this.pid4EnableG2.Click += new System.EventHandler(this.pid4EnableG2_Click);
            // 
            // pid4DG2
            // 
            this.pid4DG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4DG2.Location = new System.Drawing.Point(336, 131);
            this.pid4DG2.Name = "pid4DG2";
            this.pid4DG2.Size = new System.Drawing.Size(39, 23);
            this.pid4DG2.TabIndex = 99;
            this.pid4DG2.Text = "0";
            // 
            // pid4IG2
            // 
            this.pid4IG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4IG2.Location = new System.Drawing.Point(291, 131);
            this.pid4IG2.Name = "pid4IG2";
            this.pid4IG2.Size = new System.Drawing.Size(39, 23);
            this.pid4IG2.TabIndex = 98;
            this.pid4IG2.Text = "0";
            // 
            // pid4PG2
            // 
            this.pid4PG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4PG2.Location = new System.Drawing.Point(246, 131);
            this.pid4PG2.Name = "pid4PG2";
            this.pid4PG2.Size = new System.Drawing.Size(39, 23);
            this.pid4PG2.TabIndex = 97;
            this.pid4PG2.Text = "0";
            // 
            // pid4LimitAmpG2
            // 
            this.pid4LimitAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4LimitAmpG2.Location = new System.Drawing.Point(201, 131);
            this.pid4LimitAmpG2.Name = "pid4LimitAmpG2";
            this.pid4LimitAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid4LimitAmpG2.TabIndex = 96;
            this.pid4LimitAmpG2.Text = "0";
            // 
            // pid4MiddleAmpG2
            // 
            this.pid4MiddleAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4MiddleAmpG2.Location = new System.Drawing.Point(156, 131);
            this.pid4MiddleAmpG2.Name = "pid4MiddleAmpG2";
            this.pid4MiddleAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid4MiddleAmpG2.TabIndex = 95;
            this.pid4MiddleAmpG2.Text = "0";
            // 
            // pid4LockAmpG2
            // 
            this.pid4LockAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4LockAmpG2.Location = new System.Drawing.Point(112, 131);
            this.pid4LockAmpG2.Name = "pid4LockAmpG2";
            this.pid4LockAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid4LockAmpG2.TabIndex = 94;
            this.pid4LockAmpG2.Text = "0";
            // 
            // G2_pid3_button
            // 
            this.G2_pid3_button.BackColor = System.Drawing.SystemColors.Window;
            this.G2_pid3_button.Location = new System.Drawing.Point(384, 108);
            this.G2_pid3_button.Name = "G2_pid3_button";
            this.G2_pid3_button.Size = new System.Drawing.Size(22, 17);
            this.G2_pid3_button.TabIndex = 93;
            this.G2_pid3_button.UseVisualStyleBackColor = false;
            this.G2_pid3_button.Click += new System.EventHandler(this.G2_pid3_button_Click);
            // 
            // pid3EnableG2
            // 
            this.pid3EnableG2.BackColor = System.Drawing.Color.Red;
            this.pid3EnableG2.Location = new System.Drawing.Point(91, 108);
            this.pid3EnableG2.Name = "pid3EnableG2";
            this.pid3EnableG2.Size = new System.Drawing.Size(22, 17);
            this.pid3EnableG2.TabIndex = 92;
            this.pid3EnableG2.UseVisualStyleBackColor = false;
            this.pid3EnableG2.Click += new System.EventHandler(this.pid3EnableG2_Click);
            // 
            // pid3DG2
            // 
            this.pid3DG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3DG2.Location = new System.Drawing.Point(336, 98);
            this.pid3DG2.Name = "pid3DG2";
            this.pid3DG2.Size = new System.Drawing.Size(39, 23);
            this.pid3DG2.TabIndex = 91;
            this.pid3DG2.Text = "0";
            // 
            // pid3IG2
            // 
            this.pid3IG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3IG2.Location = new System.Drawing.Point(291, 98);
            this.pid3IG2.Name = "pid3IG2";
            this.pid3IG2.Size = new System.Drawing.Size(39, 23);
            this.pid3IG2.TabIndex = 90;
            this.pid3IG2.Text = "0";
            // 
            // pid3PG2
            // 
            this.pid3PG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3PG2.Location = new System.Drawing.Point(246, 98);
            this.pid3PG2.Name = "pid3PG2";
            this.pid3PG2.Size = new System.Drawing.Size(39, 23);
            this.pid3PG2.TabIndex = 89;
            this.pid3PG2.Text = "0";
            // 
            // pid3LimitAmpG2
            // 
            this.pid3LimitAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3LimitAmpG2.Location = new System.Drawing.Point(201, 98);
            this.pid3LimitAmpG2.Name = "pid3LimitAmpG2";
            this.pid3LimitAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid3LimitAmpG2.TabIndex = 88;
            this.pid3LimitAmpG2.Text = "0";
            // 
            // pid3MiddleAmpG2
            // 
            this.pid3MiddleAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3MiddleAmpG2.Location = new System.Drawing.Point(156, 98);
            this.pid3MiddleAmpG2.Name = "pid3MiddleAmpG2";
            this.pid3MiddleAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid3MiddleAmpG2.TabIndex = 87;
            this.pid3MiddleAmpG2.Text = "0";
            // 
            // pid3LockAmpG2
            // 
            this.pid3LockAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3LockAmpG2.Location = new System.Drawing.Point(112, 98);
            this.pid3LockAmpG2.Name = "pid3LockAmpG2";
            this.pid3LockAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid3LockAmpG2.TabIndex = 86;
            this.pid3LockAmpG2.Text = "0";
            // 
            // G2_pid2_button
            // 
            this.G2_pid2_button.BackColor = System.Drawing.SystemColors.Window;
            this.G2_pid2_button.Location = new System.Drawing.Point(384, 75);
            this.G2_pid2_button.Name = "G2_pid2_button";
            this.G2_pid2_button.Size = new System.Drawing.Size(22, 17);
            this.G2_pid2_button.TabIndex = 85;
            this.G2_pid2_button.UseVisualStyleBackColor = false;
            this.G2_pid2_button.Click += new System.EventHandler(this.G2_pid2_button_Click);
            // 
            // pid2EnableG2
            // 
            this.pid2EnableG2.BackColor = System.Drawing.Color.Red;
            this.pid2EnableG2.Location = new System.Drawing.Point(91, 75);
            this.pid2EnableG2.Name = "pid2EnableG2";
            this.pid2EnableG2.Size = new System.Drawing.Size(22, 17);
            this.pid2EnableG2.TabIndex = 84;
            this.pid2EnableG2.UseVisualStyleBackColor = false;
            this.pid2EnableG2.Click += new System.EventHandler(this.pid2EnableG2_Click);
            // 
            // pid2DG2
            // 
            this.pid2DG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2DG2.Location = new System.Drawing.Point(336, 65);
            this.pid2DG2.Name = "pid2DG2";
            this.pid2DG2.Size = new System.Drawing.Size(39, 23);
            this.pid2DG2.TabIndex = 83;
            this.pid2DG2.Text = "0";
            // 
            // pid2IG2
            // 
            this.pid2IG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2IG2.Location = new System.Drawing.Point(291, 65);
            this.pid2IG2.Name = "pid2IG2";
            this.pid2IG2.Size = new System.Drawing.Size(39, 23);
            this.pid2IG2.TabIndex = 82;
            this.pid2IG2.Text = "0";
            // 
            // pid2PG2
            // 
            this.pid2PG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2PG2.Location = new System.Drawing.Point(246, 65);
            this.pid2PG2.Name = "pid2PG2";
            this.pid2PG2.Size = new System.Drawing.Size(39, 23);
            this.pid2PG2.TabIndex = 81;
            this.pid2PG2.Text = "0";
            // 
            // pid2LimitAmpG2
            // 
            this.pid2LimitAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2LimitAmpG2.Location = new System.Drawing.Point(201, 65);
            this.pid2LimitAmpG2.Name = "pid2LimitAmpG2";
            this.pid2LimitAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid2LimitAmpG2.TabIndex = 80;
            this.pid2LimitAmpG2.Text = "0";
            // 
            // pid2MiddleAmpG2
            // 
            this.pid2MiddleAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2MiddleAmpG2.Location = new System.Drawing.Point(156, 65);
            this.pid2MiddleAmpG2.Name = "pid2MiddleAmpG2";
            this.pid2MiddleAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid2MiddleAmpG2.TabIndex = 79;
            this.pid2MiddleAmpG2.Text = "0";
            // 
            // pid2LockAmpG2
            // 
            this.pid2LockAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2LockAmpG2.Location = new System.Drawing.Point(112, 65);
            this.pid2LockAmpG2.Name = "pid2LockAmpG2";
            this.pid2LockAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid2LockAmpG2.TabIndex = 78;
            this.pid2LockAmpG2.Text = "0";
            // 
            // G2_pid1_button
            // 
            this.G2_pid1_button.BackColor = System.Drawing.SystemColors.Window;
            this.G2_pid1_button.Location = new System.Drawing.Point(384, 42);
            this.G2_pid1_button.Name = "G2_pid1_button";
            this.G2_pid1_button.Size = new System.Drawing.Size(22, 17);
            this.G2_pid1_button.TabIndex = 77;
            this.G2_pid1_button.UseVisualStyleBackColor = false;
            this.G2_pid1_button.Click += new System.EventHandler(this.G2_pid1_button_Click);
            // 
            // pid1EnableG2
            // 
            this.pid1EnableG2.BackColor = System.Drawing.Color.Red;
            this.pid1EnableG2.Location = new System.Drawing.Point(91, 42);
            this.pid1EnableG2.Name = "pid1EnableG2";
            this.pid1EnableG2.Size = new System.Drawing.Size(22, 17);
            this.pid1EnableG2.TabIndex = 76;
            this.pid1EnableG2.UseVisualStyleBackColor = false;
            this.pid1EnableG2.Click += new System.EventHandler(this.pid1EnableG2_Click);
            // 
            // pid1DG2
            // 
            this.pid1DG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1DG2.Location = new System.Drawing.Point(336, 32);
            this.pid1DG2.Name = "pid1DG2";
            this.pid1DG2.Size = new System.Drawing.Size(39, 23);
            this.pid1DG2.TabIndex = 75;
            this.pid1DG2.Text = "0";
            // 
            // pid1IG2
            // 
            this.pid1IG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1IG2.Location = new System.Drawing.Point(291, 32);
            this.pid1IG2.Name = "pid1IG2";
            this.pid1IG2.Size = new System.Drawing.Size(39, 23);
            this.pid1IG2.TabIndex = 74;
            this.pid1IG2.Text = "0";
            // 
            // pid1PG2
            // 
            this.pid1PG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1PG2.Location = new System.Drawing.Point(246, 32);
            this.pid1PG2.Name = "pid1PG2";
            this.pid1PG2.Size = new System.Drawing.Size(39, 23);
            this.pid1PG2.TabIndex = 73;
            this.pid1PG2.Text = "0";
            // 
            // pid1LimitAmpG2
            // 
            this.pid1LimitAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1LimitAmpG2.Location = new System.Drawing.Point(201, 32);
            this.pid1LimitAmpG2.Name = "pid1LimitAmpG2";
            this.pid1LimitAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid1LimitAmpG2.TabIndex = 72;
            this.pid1LimitAmpG2.Text = "0";
            // 
            // pid1MiddleAmpG2
            // 
            this.pid1MiddleAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1MiddleAmpG2.Location = new System.Drawing.Point(156, 32);
            this.pid1MiddleAmpG2.Name = "pid1MiddleAmpG2";
            this.pid1MiddleAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid1MiddleAmpG2.TabIndex = 71;
            this.pid1MiddleAmpG2.Text = "0";
            // 
            // pid1LockAmpG2
            // 
            this.pid1LockAmpG2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1LockAmpG2.Location = new System.Drawing.Point(112, 32);
            this.pid1LockAmpG2.Name = "pid1LockAmpG2";
            this.pid1LockAmpG2.Size = new System.Drawing.Size(39, 23);
            this.pid1LockAmpG2.TabIndex = 70;
            this.pid1LockAmpG2.Text = "0";
            // 
            // G2_Openloop_BC_textBox
            // 
            this.G2_Openloop_BC_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_Openloop_BC_textBox.Location = new System.Drawing.Point(49, 133);
            this.G2_Openloop_BC_textBox.Name = "G2_Openloop_BC_textBox";
            this.G2_Openloop_BC_textBox.Size = new System.Drawing.Size(39, 26);
            this.G2_Openloop_BC_textBox.TabIndex = 5;
            this.G2_Openloop_BC_textBox.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(58, 13);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 16);
            this.label13.TabIndex = 16;
            this.label13.Text = "mV";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(13, 136);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 24);
            this.label20.TabIndex = 9;
            this.label20.Text = "G2DB\r\ncos";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(13, 100);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 24);
            this.label19.TabIndex = 10;
            this.label19.Text = "G2DB\r\nsin";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(13, 70);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 24);
            this.label18.TabIndex = 11;
            this.label18.Text = "G2DA\r\ncos";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(13, 37);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 24);
            this.label17.TabIndex = 12;
            this.label17.Text = "G2DA\r\nsin";
            // 
            // G2_Opebloop_BS_textBox
            // 
            this.G2_Opebloop_BS_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_Opebloop_BS_textBox.Location = new System.Drawing.Point(49, 100);
            this.G2_Opebloop_BS_textBox.Name = "G2_Opebloop_BS_textBox";
            this.G2_Opebloop_BS_textBox.Size = new System.Drawing.Size(39, 26);
            this.G2_Opebloop_BS_textBox.TabIndex = 6;
            this.G2_Opebloop_BS_textBox.Text = "0";
            // 
            // G2_Openloop_AC_textBox
            // 
            this.G2_Openloop_AC_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_Openloop_AC_textBox.Location = new System.Drawing.Point(49, 67);
            this.G2_Openloop_AC_textBox.Name = "G2_Openloop_AC_textBox";
            this.G2_Openloop_AC_textBox.Size = new System.Drawing.Size(39, 26);
            this.G2_Openloop_AC_textBox.TabIndex = 7;
            this.G2_Openloop_AC_textBox.Text = "0";
            // 
            // G2_Openloop_AS_textBox
            // 
            this.G2_Openloop_AS_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_Openloop_AS_textBox.Location = new System.Drawing.Point(49, 34);
            this.G2_Openloop_AS_textBox.Name = "G2_Openloop_AS_textBox";
            this.G2_Openloop_AS_textBox.Size = new System.Drawing.Size(39, 26);
            this.G2_Openloop_AS_textBox.TabIndex = 8;
            this.G2_Openloop_AS_textBox.Text = "0";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.comboBox4);
            this.tabPage8.Controls.Add(this.label107);
            this.tabPage8.Controls.Add(this.label106);
            this.tabPage8.Controls.Add(this.label105);
            this.tabPage8.Controls.Add(this.label104);
            this.tabPage8.Controls.Add(this.label103);
            this.tabPage8.Controls.Add(this.label102);
            this.tabPage8.Controls.Add(this.qFactorG2Enable);
            this.tabPage8.Controls.Add(this.qfactorLongTauG2_textBox);
            this.tabPage8.Controls.Add(this.qfactorMaxG2_textBox);
            this.tabPage8.Controls.Add(this.qfactorShortTauG2_textBox);
            this.tabPage8.Controls.Add(this.qfactorMinG2_textBox);
            this.tabPage8.Controls.Add(this.qfactorStartFreG2_textBox);
            this.tabPage8.Controls.Add(this.qfactorDelayG2_textBox);
            this.tabPage8.Controls.Add(this.G2_Qfactor_button);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(445, 202);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "Q值";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "AI",
            "AQ",
            "BI",
            "BQ"});
            this.comboBox4.Location = new System.Drawing.Point(59, 9);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(84, 20);
            this.comboBox4.TabIndex = 52;
            this.comboBox4.Text = "AI";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(17, 68);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(29, 12);
            this.label107.TabIndex = 49;
            this.label107.Text = "延时";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(283, 102);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(29, 12);
            this.label106.TabIndex = 48;
            this.label106.Text = "Qmax";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(283, 54);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(29, 12);
            this.label105.TabIndex = 47;
            this.label105.Text = "Qmin";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(157, 151);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(29, 12);
            this.label104.TabIndex = 46;
            this.label104.Text = "长τ";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(157, 102);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(29, 12);
            this.label103.TabIndex = 45;
            this.label103.Text = "短τ";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(157, 59);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(29, 12);
            this.label102.TabIndex = 44;
            this.label102.Text = "频率";
            // 
            // qFactorG2Enable
            // 
            this.qFactorG2Enable.BackColor = System.Drawing.Color.Red;
            this.qFactorG2Enable.Location = new System.Drawing.Point(24, 24);
            this.qFactorG2Enable.Name = "qFactorG2Enable";
            this.qFactorG2Enable.Size = new System.Drawing.Size(22, 17);
            this.qFactorG2Enable.TabIndex = 42;
            this.qFactorG2Enable.UseVisualStyleBackColor = false;
            this.qFactorG2Enable.Click += new System.EventHandler(this.qFactorG2Enable_Click);
            // 
            // qfactorLongTauG2_textBox
            // 
            this.qfactorLongTauG2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorLongTauG2_textBox.Location = new System.Drawing.Point(187, 136);
            this.qfactorLongTauG2_textBox.Multiline = true;
            this.qfactorLongTauG2_textBox.Name = "qfactorLongTauG2_textBox";
            this.qfactorLongTauG2_textBox.ReadOnly = true;
            this.qfactorLongTauG2_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorLongTauG2_textBox.TabIndex = 15;
            this.qfactorLongTauG2_textBox.Text = "0";
            // 
            // qfactorMaxG2_textBox
            // 
            this.qfactorMaxG2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorMaxG2_textBox.Location = new System.Drawing.Point(318, 87);
            this.qfactorMaxG2_textBox.Multiline = true;
            this.qfactorMaxG2_textBox.Name = "qfactorMaxG2_textBox";
            this.qfactorMaxG2_textBox.ReadOnly = true;
            this.qfactorMaxG2_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorMaxG2_textBox.TabIndex = 14;
            this.qfactorMaxG2_textBox.Text = "0";
            // 
            // qfactorShortTauG2_textBox
            // 
            this.qfactorShortTauG2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorShortTauG2_textBox.Location = new System.Drawing.Point(187, 87);
            this.qfactorShortTauG2_textBox.Multiline = true;
            this.qfactorShortTauG2_textBox.Name = "qfactorShortTauG2_textBox";
            this.qfactorShortTauG2_textBox.ReadOnly = true;
            this.qfactorShortTauG2_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorShortTauG2_textBox.TabIndex = 13;
            this.qfactorShortTauG2_textBox.Text = "0";
            // 
            // qfactorMinG2_textBox
            // 
            this.qfactorMinG2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorMinG2_textBox.Location = new System.Drawing.Point(318, 39);
            this.qfactorMinG2_textBox.Multiline = true;
            this.qfactorMinG2_textBox.Name = "qfactorMinG2_textBox";
            this.qfactorMinG2_textBox.ReadOnly = true;
            this.qfactorMinG2_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorMinG2_textBox.TabIndex = 12;
            this.qfactorMinG2_textBox.Text = "0";
            // 
            // qfactorStartFreG2_textBox
            // 
            this.qfactorStartFreG2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorStartFreG2_textBox.Location = new System.Drawing.Point(187, 44);
            this.qfactorStartFreG2_textBox.Multiline = true;
            this.qfactorStartFreG2_textBox.Name = "qfactorStartFreG2_textBox";
            this.qfactorStartFreG2_textBox.ReadOnly = true;
            this.qfactorStartFreG2_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorStartFreG2_textBox.TabIndex = 11;
            this.qfactorStartFreG2_textBox.Text = "0";
            // 
            // qfactorDelayG2_textBox
            // 
            this.qfactorDelayG2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorDelayG2_textBox.Location = new System.Drawing.Point(52, 54);
            this.qfactorDelayG2_textBox.Multiline = true;
            this.qfactorDelayG2_textBox.Name = "qfactorDelayG2_textBox";
            this.qfactorDelayG2_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorDelayG2_textBox.TabIndex = 10;
            this.qfactorDelayG2_textBox.Text = "0";
            // 
            // G2_Qfactor_button
            // 
            this.G2_Qfactor_button.Location = new System.Drawing.Point(52, 124);
            this.G2_Qfactor_button.Name = "G2_Qfactor_button";
            this.G2_Qfactor_button.Size = new System.Drawing.Size(75, 23);
            this.G2_Qfactor_button.TabIndex = 9;
            this.G2_Qfactor_button.Text = "G2发送";
            this.G2_Qfactor_button.UseVisualStyleBackColor = true;
            this.G2_Qfactor_button.Click += new System.EventHandler(this.G2_Qfactor_button_Click);
            // 
            // tabPage23
            // 
            this.tabPage23.Controls.Add(this.comboBox6);
            this.tabPage23.Controls.Add(this.label111);
            this.tabPage23.Controls.Add(this.label112);
            this.tabPage23.Controls.Add(this.agcMinOutG2_textBox);
            this.tabPage23.Controls.Add(this.freResonantG2_textBox);
            this.tabPage23.Controls.Add(this.ResonantG2_button);
            this.tabPage23.Location = new System.Drawing.Point(4, 22);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage23.Size = new System.Drawing.Size(445, 202);
            this.tabPage23.TabIndex = 2;
            this.tabPage23.Text = "谐振频率";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "AI",
            "AQ",
            "BI",
            "BQ",
            "关"});
            this.comboBox6.Location = new System.Drawing.Point(101, 56);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(84, 20);
            this.comboBox6.TabIndex = 63;
            this.comboBox6.Text = "AI";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(234, 134);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(29, 12);
            this.label111.TabIndex = 62;
            this.label111.Text = "幅值";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(234, 91);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(29, 12);
            this.label112.TabIndex = 61;
            this.label112.Text = "频率";
            // 
            // agcMinOutG2_textBox
            // 
            this.agcMinOutG2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.agcMinOutG2_textBox.Location = new System.Drawing.Point(269, 119);
            this.agcMinOutG2_textBox.Multiline = true;
            this.agcMinOutG2_textBox.Name = "agcMinOutG2_textBox";
            this.agcMinOutG2_textBox.ReadOnly = true;
            this.agcMinOutG2_textBox.Size = new System.Drawing.Size(75, 27);
            this.agcMinOutG2_textBox.TabIndex = 60;
            this.agcMinOutG2_textBox.Text = "0";
            // 
            // freResonantG2_textBox
            // 
            this.freResonantG2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.freResonantG2_textBox.Location = new System.Drawing.Point(269, 76);
            this.freResonantG2_textBox.Multiline = true;
            this.freResonantG2_textBox.Name = "freResonantG2_textBox";
            this.freResonantG2_textBox.ReadOnly = true;
            this.freResonantG2_textBox.Size = new System.Drawing.Size(75, 27);
            this.freResonantG2_textBox.TabIndex = 59;
            this.freResonantG2_textBox.Text = "0";
            // 
            // ResonantG2_button
            // 
            this.ResonantG2_button.Location = new System.Drawing.Point(101, 123);
            this.ResonantG2_button.Name = "ResonantG2_button";
            this.ResonantG2_button.Size = new System.Drawing.Size(75, 23);
            this.ResonantG2_button.TabIndex = 58;
            this.ResonantG2_button.Text = "G1发送";
            this.ResonantG2_button.UseVisualStyleBackColor = true;
            this.ResonantG2_button.Click += new System.EventHandler(this.ResonantG2_button_Click);
            // 
            // tabPage24
            // 
            this.tabPage24.Controls.Add(this.button21);
            this.tabPage24.Controls.Add(this.label131);
            this.tabPage24.Controls.Add(this.label132);
            this.tabPage24.Controls.Add(this.G2_pilotFre_leftAmp_textBox);
            this.tabPage24.Controls.Add(this.pilotFrequncyEnableG2);
            this.tabPage24.Controls.Add(this.G2_pilotFrequncy_button);
            this.tabPage24.Controls.Add(this.label129);
            this.tabPage24.Controls.Add(this.label130);
            this.tabPage24.Controls.Add(this.G2_pilotFre_textBox);
            this.tabPage24.Controls.Add(this.label127);
            this.tabPage24.Controls.Add(this.label128);
            this.tabPage24.Controls.Add(this.G2_pilotFreSin_textBox);
            this.tabPage24.Controls.Add(this.label115);
            this.tabPage24.Controls.Add(this.label116);
            this.tabPage24.Controls.Add(this.G2_pilotFre_rightAmp_textBox);
            this.tabPage24.Controls.Add(this.label113);
            this.tabPage24.Controls.Add(this.label114);
            this.tabPage24.Controls.Add(this.G2_pilotFreCos_textBox);
            this.tabPage24.Location = new System.Drawing.Point(4, 22);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage24.Size = new System.Drawing.Size(445, 202);
            this.tabPage24.TabIndex = 3;
            this.tabPage24.Text = "planD";
            this.tabPage24.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(185, 14);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 23);
            this.button21.TabIndex = 100;
            this.button21.Text = "G2pilotFre";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label131.Location = new System.Drawing.Point(383, 64);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(23, 16);
            this.label131.TabIndex = 63;
            this.label131.Text = "mV";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(255, 63);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(41, 12);
            this.label132.TabIndex = 62;
            this.label132.Text = "左幅值";
            // 
            // G2_pilotFre_leftAmp_textBox
            // 
            this.G2_pilotFre_leftAmp_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_pilotFre_leftAmp_textBox.Location = new System.Drawing.Point(302, 53);
            this.G2_pilotFre_leftAmp_textBox.Name = "G2_pilotFre_leftAmp_textBox";
            this.G2_pilotFre_leftAmp_textBox.ReadOnly = true;
            this.G2_pilotFre_leftAmp_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_pilotFre_leftAmp_textBox.TabIndex = 61;
            this.G2_pilotFre_leftAmp_textBox.Text = "0";
            // 
            // pilotFrequncyEnableG2
            // 
            this.pilotFrequncyEnableG2.BackColor = System.Drawing.Color.Red;
            this.pilotFrequncyEnableG2.Location = new System.Drawing.Point(24, 20);
            this.pilotFrequncyEnableG2.Name = "pilotFrequncyEnableG2";
            this.pilotFrequncyEnableG2.Size = new System.Drawing.Size(22, 17);
            this.pilotFrequncyEnableG2.TabIndex = 60;
            this.pilotFrequncyEnableG2.UseVisualStyleBackColor = false;
            this.pilotFrequncyEnableG2.Click += new System.EventHandler(this.pilotFrequncyEnableG2_Click);
            // 
            // G2_pilotFrequncy_button
            // 
            this.G2_pilotFrequncy_button.Location = new System.Drawing.Point(168, 168);
            this.G2_pilotFrequncy_button.Name = "G2_pilotFrequncy_button";
            this.G2_pilotFrequncy_button.Size = new System.Drawing.Size(75, 23);
            this.G2_pilotFrequncy_button.TabIndex = 59;
            this.G2_pilotFrequncy_button.Text = "G2发送";
            this.G2_pilotFrequncy_button.UseVisualStyleBackColor = true;
            this.G2_pilotFrequncy_button.Click += new System.EventHandler(this.G2_pilotFrequncy_button_Click);
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label129.Location = new System.Drawing.Point(153, 55);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(23, 16);
            this.label129.TabIndex = 58;
            this.label129.Text = "Hz";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(37, 54);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(29, 12);
            this.label130.TabIndex = 57;
            this.label130.Text = "步长";
            // 
            // G2_pilotFre_textBox
            // 
            this.G2_pilotFre_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_pilotFre_textBox.Location = new System.Drawing.Point(72, 44);
            this.G2_pilotFre_textBox.Name = "G2_pilotFre_textBox";
            this.G2_pilotFre_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_pilotFre_textBox.TabIndex = 56;
            this.G2_pilotFre_textBox.Text = "0";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label127.Location = new System.Drawing.Point(153, 100);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(23, 16);
            this.label127.TabIndex = 55;
            this.label127.Text = "mV";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(31, 102);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(35, 12);
            this.label128.TabIndex = 54;
            this.label128.Text = "驱动I\r\n";
            // 
            // G2_pilotFreSin_textBox
            // 
            this.G2_pilotFreSin_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_pilotFreSin_textBox.Location = new System.Drawing.Point(72, 89);
            this.G2_pilotFreSin_textBox.Name = "G2_pilotFreSin_textBox";
            this.G2_pilotFreSin_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_pilotFreSin_textBox.TabIndex = 53;
            this.G2_pilotFreSin_textBox.Text = "0";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label115.Location = new System.Drawing.Point(383, 116);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(23, 16);
            this.label115.TabIndex = 52;
            this.label115.Text = "mV";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(255, 112);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(41, 12);
            this.label116.TabIndex = 51;
            this.label116.Text = "右幅值";
            // 
            // G2_pilotFre_rightAmp_textBox
            // 
            this.G2_pilotFre_rightAmp_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_pilotFre_rightAmp_textBox.Location = new System.Drawing.Point(302, 105);
            this.G2_pilotFre_rightAmp_textBox.Name = "G2_pilotFre_rightAmp_textBox";
            this.G2_pilotFre_rightAmp_textBox.ReadOnly = true;
            this.G2_pilotFre_rightAmp_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_pilotFre_rightAmp_textBox.TabIndex = 50;
            this.G2_pilotFre_rightAmp_textBox.Text = "0";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label113.Location = new System.Drawing.Point(153, 138);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(23, 16);
            this.label113.TabIndex = 49;
            this.label113.Text = "mV";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(31, 138);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(35, 12);
            this.label114.TabIndex = 48;
            this.label114.Text = "驱动Q";
            // 
            // G2_pilotFreCos_textBox
            // 
            this.G2_pilotFreCos_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_pilotFreCos_textBox.Location = new System.Drawing.Point(72, 127);
            this.G2_pilotFreCos_textBox.Name = "G2_pilotFreCos_textBox";
            this.G2_pilotFreCos_textBox.Size = new System.Drawing.Size(75, 26);
            this.G2_pilotFreCos_textBox.TabIndex = 47;
            this.G2_pilotFreCos_textBox.Text = "0";
            // 
            // tabControl8
            // 
            this.tabControl8.Controls.Add(this.tabPage26);
            this.tabControl8.Location = new System.Drawing.Point(1424, 558);
            this.tabControl8.Name = "tabControl8";
            this.tabControl8.SelectedIndex = 0;
            this.tabControl8.Size = new System.Drawing.Size(449, 195);
            this.tabControl8.TabIndex = 43;
            // 
            // tabPage26
            // 
            this.tabPage26.Controls.Add(this.G2_HV_button);
            this.tabPage26.Controls.Add(this.label52);
            this.tabPage26.Controls.Add(this.label51);
            this.tabPage26.Controls.Add(this.label50);
            this.tabPage26.Controls.Add(this.label49);
            this.tabPage26.Controls.Add(this.label48);
            this.tabPage26.Controls.Add(this.G2_MISCbutton);
            this.tabPage26.Controls.Add(this.label47);
            this.tabPage26.Controls.Add(this.label46);
            this.tabPage26.Controls.Add(this.label45);
            this.tabPage26.Controls.Add(this.G2_HV4_textBox);
            this.tabPage26.Controls.Add(this.label44);
            this.tabPage26.Controls.Add(this.label43);
            this.tabPage26.Controls.Add(this.label42);
            this.tabPage26.Controls.Add(this.label41);
            this.tabPage26.Controls.Add(this.G2_HV3_textBox);
            this.tabPage26.Controls.Add(this.G2_HV2_textBox);
            this.tabPage26.Controls.Add(this.G2_HV1_textBox);
            this.tabPage26.Controls.Add(this.label40);
            this.tabPage26.Controls.Add(this.label39);
            this.tabPage26.Controls.Add(this.label38);
            this.tabPage26.Controls.Add(this.label37);
            this.tabPage26.Controls.Add(this.G2_HV_SB_textBox);
            this.tabPage26.Controls.Add(this.G2_HV_CB_textBox);
            this.tabPage26.Controls.Add(this.G2_HV_SA_textBox);
            this.tabPage26.Controls.Add(this.G2_HV_CA_textBox);
            this.tabPage26.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage26.Location = new System.Drawing.Point(4, 22);
            this.tabPage26.Name = "tabPage26";
            this.tabPage26.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage26.Size = new System.Drawing.Size(441, 169);
            this.tabPage26.TabIndex = 0;
            this.tabPage26.Text = "辅助参数";
            this.tabPage26.UseVisualStyleBackColor = true;
            // 
            // G2_HV_button
            // 
            this.G2_HV_button.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_HV_button.Location = new System.Drawing.Point(142, 61);
            this.G2_HV_button.Name = "G2_HV_button";
            this.G2_HV_button.Size = new System.Drawing.Size(75, 23);
            this.G2_HV_button.TabIndex = 31;
            this.G2_HV_button.Text = "G2发送";
            this.G2_HV_button.UseVisualStyleBackColor = true;
            this.G2_HV_button.Click += new System.EventHandler(this.G2_HV_button_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label52.Location = new System.Drawing.Point(5, 111);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(31, 16);
            this.label52.TabIndex = 29;
            this.label52.Text = "HV4";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label51.Location = new System.Drawing.Point(241, 103);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(17, 24);
            this.label51.TabIndex = 28;
            this.label51.Text = "DB\r\nφ";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label50.Location = new System.Drawing.Point(240, 73);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(17, 24);
            this.label50.TabIndex = 27;
            this.label50.Text = "DA\r\nφ";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label49.Location = new System.Drawing.Point(240, 40);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(17, 24);
            this.label49.TabIndex = 26;
            this.label49.Text = "SB\r\nφ";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label48.Location = new System.Drawing.Point(239, 7);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(17, 24);
            this.label48.TabIndex = 25;
            this.label48.Text = "SA\r\nφ";
            // 
            // G2_MISCbutton
            // 
            this.G2_MISCbutton.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_MISCbutton.Location = new System.Drawing.Point(360, 60);
            this.G2_MISCbutton.Name = "G2_MISCbutton";
            this.G2_MISCbutton.Size = new System.Drawing.Size(75, 23);
            this.G2_MISCbutton.TabIndex = 6;
            this.G2_MISCbutton.Text = "G2发送";
            this.G2_MISCbutton.UseVisualStyleBackColor = true;
            this.G2_MISCbutton.Click += new System.EventHandler(this.G2_MISCbutton_Click);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.Location = new System.Drawing.Point(5, 81);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(31, 16);
            this.label47.TabIndex = 24;
            this.label47.Text = "HV3";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label46.Location = new System.Drawing.Point(5, 48);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(31, 16);
            this.label46.TabIndex = 23;
            this.label46.Text = "HV2";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label45.Location = new System.Drawing.Point(5, 14);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(31, 16);
            this.label45.TabIndex = 22;
            this.label45.Text = "HV1";
            // 
            // G2_HV4_textBox
            // 
            this.G2_HV4_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_HV4_textBox.Location = new System.Drawing.Point(40, 103);
            this.G2_HV4_textBox.Name = "G2_HV4_textBox";
            this.G2_HV4_textBox.Size = new System.Drawing.Size(68, 26);
            this.G2_HV4_textBox.TabIndex = 12;
            this.G2_HV4_textBox.Text = "0";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label44.Location = new System.Drawing.Point(114, 111);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(15, 16);
            this.label44.TabIndex = 21;
            this.label44.Text = "V";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.Location = new System.Drawing.Point(115, 81);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(15, 16);
            this.label43.TabIndex = 20;
            this.label43.Text = "V";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.Location = new System.Drawing.Point(116, 48);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(15, 16);
            this.label42.TabIndex = 30;
            this.label42.Text = "V";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.Location = new System.Drawing.Point(115, 15);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(15, 16);
            this.label41.TabIndex = 19;
            this.label41.Text = "V";
            // 
            // G2_HV3_textBox
            // 
            this.G2_HV3_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_HV3_textBox.Location = new System.Drawing.Point(40, 70);
            this.G2_HV3_textBox.Name = "G2_HV3_textBox";
            this.G2_HV3_textBox.Size = new System.Drawing.Size(69, 26);
            this.G2_HV3_textBox.TabIndex = 13;
            this.G2_HV3_textBox.Text = "0";
            // 
            // G2_HV2_textBox
            // 
            this.G2_HV2_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_HV2_textBox.Location = new System.Drawing.Point(40, 37);
            this.G2_HV2_textBox.Name = "G2_HV2_textBox";
            this.G2_HV2_textBox.Size = new System.Drawing.Size(69, 26);
            this.G2_HV2_textBox.TabIndex = 11;
            this.G2_HV2_textBox.Text = "0";
            // 
            // G2_HV1_textBox
            // 
            this.G2_HV1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_HV1_textBox.Location = new System.Drawing.Point(40, 4);
            this.G2_HV1_textBox.Name = "G2_HV1_textBox";
            this.G2_HV1_textBox.Size = new System.Drawing.Size(70, 26);
            this.G2_HV1_textBox.TabIndex = 10;
            this.G2_HV1_textBox.Text = "0";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.Location = new System.Drawing.Point(331, 114);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(31, 16);
            this.label40.TabIndex = 18;
            this.label40.Text = "deg";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label39.Location = new System.Drawing.Point(331, 81);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(31, 16);
            this.label39.TabIndex = 17;
            this.label39.Text = "deg";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.Location = new System.Drawing.Point(331, 48);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(31, 16);
            this.label38.TabIndex = 16;
            this.label38.Text = "deg";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.Location = new System.Drawing.Point(332, 15);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(31, 16);
            this.label37.TabIndex = 15;
            this.label37.Text = "deg";
            // 
            // G2_HV_SB_textBox
            // 
            this.G2_HV_SB_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_HV_SB_textBox.Location = new System.Drawing.Point(262, 37);
            this.G2_HV_SB_textBox.Name = "G2_HV_SB_textBox";
            this.G2_HV_SB_textBox.Size = new System.Drawing.Size(64, 26);
            this.G2_HV_SB_textBox.TabIndex = 9;
            this.G2_HV_SB_textBox.Text = "0";
            // 
            // G2_HV_CB_textBox
            // 
            this.G2_HV_CB_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_HV_CB_textBox.Location = new System.Drawing.Point(262, 103);
            this.G2_HV_CB_textBox.Name = "G2_HV_CB_textBox";
            this.G2_HV_CB_textBox.Size = new System.Drawing.Size(64, 26);
            this.G2_HV_CB_textBox.TabIndex = 8;
            this.G2_HV_CB_textBox.Text = "0";
            // 
            // G2_HV_SA_textBox
            // 
            this.G2_HV_SA_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_HV_SA_textBox.Location = new System.Drawing.Point(262, 4);
            this.G2_HV_SA_textBox.Name = "G2_HV_SA_textBox";
            this.G2_HV_SA_textBox.Size = new System.Drawing.Size(64, 26);
            this.G2_HV_SA_textBox.TabIndex = 14;
            this.G2_HV_SA_textBox.Text = "0";
            // 
            // G2_HV_CA_textBox
            // 
            this.G2_HV_CA_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.G2_HV_CA_textBox.Location = new System.Drawing.Point(262, 70);
            this.G2_HV_CA_textBox.Name = "G2_HV_CA_textBox";
            this.G2_HV_CA_textBox.Size = new System.Drawing.Size(64, 26);
            this.G2_HV_CA_textBox.TabIndex = 7;
            this.G2_HV_CA_textBox.Text = "0";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label91);
            this.tabPage3.Controls.Add(this.CMD_OPENLOOP_ACT_button);
            this.tabPage3.Controls.Add(this.label189);
            this.tabPage3.Controls.Add(this.label190);
            this.tabPage3.Controls.Add(this.pidAmpOutputG1_textBox);
            this.tabPage3.Controls.Add(this.pidAmpErrorG1_textBox);
            this.tabPage3.Controls.Add(this.pid4DG1);
            this.tabPage3.Controls.Add(this.pid4IG1);
            this.tabPage3.Controls.Add(this.pid4PG1);
            this.tabPage3.Controls.Add(this.pid4LimitAmpG1);
            this.tabPage3.Controls.Add(this.pid4MiddleAmpG1);
            this.tabPage3.Controls.Add(this.pid4LockAmpG1);
            this.tabPage3.Controls.Add(this.pid3DG1);
            this.tabPage3.Controls.Add(this.pid3IG1);
            this.tabPage3.Controls.Add(this.pid3PG1);
            this.tabPage3.Controls.Add(this.pid3LimitAmpG1);
            this.tabPage3.Controls.Add(this.pid3MiddleAmpG1);
            this.tabPage3.Controls.Add(this.pid3LockAmpG1);
            this.tabPage3.Controls.Add(this.pid2DG1);
            this.tabPage3.Controls.Add(this.pid2IG1);
            this.tabPage3.Controls.Add(this.pid2PG1);
            this.tabPage3.Controls.Add(this.pid2LimitAmpG1);
            this.tabPage3.Controls.Add(this.pid2MiddleAmpG1);
            this.tabPage3.Controls.Add(this.pid2LockAmpG1);
            this.tabPage3.Controls.Add(this.pid1DG1);
            this.tabPage3.Controls.Add(this.pid1IG1);
            this.tabPage3.Controls.Add(this.pid1PG1);
            this.tabPage3.Controls.Add(this.pid1LimitAmpG1);
            this.tabPage3.Controls.Add(this.pid1MiddleAmpG1);
            this.tabPage3.Controls.Add(this.pid1LockAmpG1);
            this.tabPage3.Controls.Add(this.Openloop_BC_textBox);
            this.tabPage3.Controls.Add(this.Openloop_BS_textBox);
            this.tabPage3.Controls.Add(this.Openloop_AC_textBox);
            this.tabPage3.Controls.Add(this.Openloop_AS_textBox);
            this.tabPage3.Controls.Add(this.label191);
            this.tabPage3.Controls.Add(this.label192);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.G1_pid4_button);
            this.tabPage3.Controls.Add(this.pid4EnableG1);
            this.tabPage3.Controls.Add(this.G1_pid3_button);
            this.tabPage3.Controls.Add(this.pid3EnableG1);
            this.tabPage3.Controls.Add(this.G1_pid2_button);
            this.tabPage3.Controls.Add(this.pid2EnableG1);
            this.tabPage3.Controls.Add(this.G1_pid1_button);
            this.tabPage3.Controls.Add(this.pid1EnableG1);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(415, 207);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "开环/PID";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label91.Location = new System.Drawing.Point(78, 10);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(29, 12);
            this.label91.TabIndex = 83;
            this.label91.Text = "状态";
            // 
            // CMD_OPENLOOP_ACT_button
            // 
            this.CMD_OPENLOOP_ACT_button.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CMD_OPENLOOP_ACT_button.Location = new System.Drawing.Point(8, 175);
            this.CMD_OPENLOOP_ACT_button.Name = "CMD_OPENLOOP_ACT_button";
            this.CMD_OPENLOOP_ACT_button.Size = new System.Drawing.Size(75, 23);
            this.CMD_OPENLOOP_ACT_button.TabIndex = 82;
            this.CMD_OPENLOOP_ACT_button.Text = "G1发送";
            this.CMD_OPENLOOP_ACT_button.UseVisualStyleBackColor = true;
            this.CMD_OPENLOOP_ACT_button.Click += new System.EventHandler(this.CMD_OPENLOOP_ACT_button_Click_1);
            // 
            // label189
            // 
            this.label189.AutoSize = true;
            this.label189.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label189.Location = new System.Drawing.Point(388, 182);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(23, 16);
            this.label189.TabIndex = 80;
            this.label189.Text = "mV";
            // 
            // label190
            // 
            this.label190.AutoSize = true;
            this.label190.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label190.Location = new System.Drawing.Point(229, 184);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(23, 16);
            this.label190.TabIndex = 81;
            this.label190.Text = "mV";
            // 
            // pidAmpOutputG1_textBox
            // 
            this.pidAmpOutputG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pidAmpOutputG1_textBox.Location = new System.Drawing.Point(304, 172);
            this.pidAmpOutputG1_textBox.Multiline = true;
            this.pidAmpOutputG1_textBox.Name = "pidAmpOutputG1_textBox";
            this.pidAmpOutputG1_textBox.ReadOnly = true;
            this.pidAmpOutputG1_textBox.Size = new System.Drawing.Size(78, 27);
            this.pidAmpOutputG1_textBox.TabIndex = 76;
            // 
            // pidAmpErrorG1_textBox
            // 
            this.pidAmpErrorG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pidAmpErrorG1_textBox.Location = new System.Drawing.Point(153, 173);
            this.pidAmpErrorG1_textBox.Multiline = true;
            this.pidAmpErrorG1_textBox.Name = "pidAmpErrorG1_textBox";
            this.pidAmpErrorG1_textBox.ReadOnly = true;
            this.pidAmpErrorG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.pidAmpErrorG1_textBox.TabIndex = 77;
            // 
            // pid4DG1
            // 
            this.pid4DG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4DG1.Location = new System.Drawing.Point(329, 130);
            this.pid4DG1.Name = "pid4DG1";
            this.pid4DG1.Size = new System.Drawing.Size(39, 23);
            this.pid4DG1.TabIndex = 67;
            this.pid4DG1.Text = "0";
            // 
            // pid4IG1
            // 
            this.pid4IG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4IG1.Location = new System.Drawing.Point(284, 130);
            this.pid4IG1.Name = "pid4IG1";
            this.pid4IG1.Size = new System.Drawing.Size(39, 23);
            this.pid4IG1.TabIndex = 66;
            this.pid4IG1.Text = "0";
            // 
            // pid4PG1
            // 
            this.pid4PG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4PG1.Location = new System.Drawing.Point(239, 130);
            this.pid4PG1.Name = "pid4PG1";
            this.pid4PG1.Size = new System.Drawing.Size(39, 23);
            this.pid4PG1.TabIndex = 65;
            this.pid4PG1.Text = "0";
            // 
            // pid4LimitAmpG1
            // 
            this.pid4LimitAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4LimitAmpG1.Location = new System.Drawing.Point(194, 130);
            this.pid4LimitAmpG1.Name = "pid4LimitAmpG1";
            this.pid4LimitAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid4LimitAmpG1.TabIndex = 64;
            this.pid4LimitAmpG1.Text = "0";
            // 
            // pid4MiddleAmpG1
            // 
            this.pid4MiddleAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4MiddleAmpG1.Location = new System.Drawing.Point(149, 130);
            this.pid4MiddleAmpG1.Name = "pid4MiddleAmpG1";
            this.pid4MiddleAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid4MiddleAmpG1.TabIndex = 63;
            this.pid4MiddleAmpG1.Text = "0";
            // 
            // pid4LockAmpG1
            // 
            this.pid4LockAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid4LockAmpG1.Location = new System.Drawing.Point(105, 130);
            this.pid4LockAmpG1.Name = "pid4LockAmpG1";
            this.pid4LockAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid4LockAmpG1.TabIndex = 62;
            this.pid4LockAmpG1.Text = "0";
            // 
            // pid3DG1
            // 
            this.pid3DG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3DG1.Location = new System.Drawing.Point(329, 97);
            this.pid3DG1.Name = "pid3DG1";
            this.pid3DG1.Size = new System.Drawing.Size(39, 23);
            this.pid3DG1.TabIndex = 59;
            this.pid3DG1.Text = "0";
            // 
            // pid3IG1
            // 
            this.pid3IG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3IG1.Location = new System.Drawing.Point(284, 97);
            this.pid3IG1.Name = "pid3IG1";
            this.pid3IG1.Size = new System.Drawing.Size(39, 23);
            this.pid3IG1.TabIndex = 58;
            this.pid3IG1.Text = "0";
            // 
            // pid3PG1
            // 
            this.pid3PG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3PG1.Location = new System.Drawing.Point(239, 97);
            this.pid3PG1.Name = "pid3PG1";
            this.pid3PG1.Size = new System.Drawing.Size(39, 23);
            this.pid3PG1.TabIndex = 57;
            this.pid3PG1.Text = "0";
            // 
            // pid3LimitAmpG1
            // 
            this.pid3LimitAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3LimitAmpG1.Location = new System.Drawing.Point(194, 97);
            this.pid3LimitAmpG1.Name = "pid3LimitAmpG1";
            this.pid3LimitAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid3LimitAmpG1.TabIndex = 56;
            this.pid3LimitAmpG1.Text = "0";
            // 
            // pid3MiddleAmpG1
            // 
            this.pid3MiddleAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3MiddleAmpG1.Location = new System.Drawing.Point(149, 97);
            this.pid3MiddleAmpG1.Name = "pid3MiddleAmpG1";
            this.pid3MiddleAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid3MiddleAmpG1.TabIndex = 55;
            this.pid3MiddleAmpG1.Text = "0";
            // 
            // pid3LockAmpG1
            // 
            this.pid3LockAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid3LockAmpG1.Location = new System.Drawing.Point(105, 97);
            this.pid3LockAmpG1.Name = "pid3LockAmpG1";
            this.pid3LockAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid3LockAmpG1.TabIndex = 54;
            this.pid3LockAmpG1.Text = "0";
            // 
            // pid2DG1
            // 
            this.pid2DG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2DG1.Location = new System.Drawing.Point(329, 64);
            this.pid2DG1.Name = "pid2DG1";
            this.pid2DG1.Size = new System.Drawing.Size(39, 23);
            this.pid2DG1.TabIndex = 51;
            this.pid2DG1.Text = "0";
            // 
            // pid2IG1
            // 
            this.pid2IG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2IG1.Location = new System.Drawing.Point(284, 64);
            this.pid2IG1.Name = "pid2IG1";
            this.pid2IG1.Size = new System.Drawing.Size(39, 23);
            this.pid2IG1.TabIndex = 50;
            this.pid2IG1.Text = "0";
            // 
            // pid2PG1
            // 
            this.pid2PG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2PG1.Location = new System.Drawing.Point(239, 64);
            this.pid2PG1.Name = "pid2PG1";
            this.pid2PG1.Size = new System.Drawing.Size(39, 23);
            this.pid2PG1.TabIndex = 49;
            this.pid2PG1.Text = "0";
            // 
            // pid2LimitAmpG1
            // 
            this.pid2LimitAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2LimitAmpG1.Location = new System.Drawing.Point(194, 64);
            this.pid2LimitAmpG1.Name = "pid2LimitAmpG1";
            this.pid2LimitAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid2LimitAmpG1.TabIndex = 48;
            this.pid2LimitAmpG1.Text = "0";
            // 
            // pid2MiddleAmpG1
            // 
            this.pid2MiddleAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2MiddleAmpG1.Location = new System.Drawing.Point(149, 64);
            this.pid2MiddleAmpG1.Name = "pid2MiddleAmpG1";
            this.pid2MiddleAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid2MiddleAmpG1.TabIndex = 47;
            this.pid2MiddleAmpG1.Text = "0";
            // 
            // pid2LockAmpG1
            // 
            this.pid2LockAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid2LockAmpG1.Location = new System.Drawing.Point(105, 64);
            this.pid2LockAmpG1.Name = "pid2LockAmpG1";
            this.pid2LockAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid2LockAmpG1.TabIndex = 46;
            this.pid2LockAmpG1.Text = "0";
            // 
            // pid1DG1
            // 
            this.pid1DG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1DG1.Location = new System.Drawing.Point(329, 31);
            this.pid1DG1.Name = "pid1DG1";
            this.pid1DG1.Size = new System.Drawing.Size(39, 23);
            this.pid1DG1.TabIndex = 9;
            this.pid1DG1.Text = "0";
            // 
            // pid1IG1
            // 
            this.pid1IG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1IG1.Location = new System.Drawing.Point(284, 31);
            this.pid1IG1.Name = "pid1IG1";
            this.pid1IG1.Size = new System.Drawing.Size(39, 23);
            this.pid1IG1.TabIndex = 8;
            this.pid1IG1.Text = "0";
            // 
            // pid1PG1
            // 
            this.pid1PG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1PG1.Location = new System.Drawing.Point(239, 31);
            this.pid1PG1.Name = "pid1PG1";
            this.pid1PG1.Size = new System.Drawing.Size(39, 23);
            this.pid1PG1.TabIndex = 7;
            this.pid1PG1.Text = "0";
            // 
            // pid1LimitAmpG1
            // 
            this.pid1LimitAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1LimitAmpG1.Location = new System.Drawing.Point(194, 31);
            this.pid1LimitAmpG1.Name = "pid1LimitAmpG1";
            this.pid1LimitAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid1LimitAmpG1.TabIndex = 6;
            this.pid1LimitAmpG1.Text = "0";
            // 
            // pid1MiddleAmpG1
            // 
            this.pid1MiddleAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1MiddleAmpG1.Location = new System.Drawing.Point(149, 31);
            this.pid1MiddleAmpG1.Name = "pid1MiddleAmpG1";
            this.pid1MiddleAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid1MiddleAmpG1.TabIndex = 5;
            this.pid1MiddleAmpG1.Text = "0";
            // 
            // pid1LockAmpG1
            // 
            this.pid1LockAmpG1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pid1LockAmpG1.Location = new System.Drawing.Point(105, 31);
            this.pid1LockAmpG1.Name = "pid1LockAmpG1";
            this.pid1LockAmpG1.Size = new System.Drawing.Size(39, 23);
            this.pid1LockAmpG1.TabIndex = 4;
            this.pid1LockAmpG1.Text = "0";
            // 
            // Openloop_BC_textBox
            // 
            this.Openloop_BC_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Openloop_BC_textBox.Location = new System.Drawing.Point(39, 130);
            this.Openloop_BC_textBox.Name = "Openloop_BC_textBox";
            this.Openloop_BC_textBox.Size = new System.Drawing.Size(39, 26);
            this.Openloop_BC_textBox.TabIndex = 1;
            this.Openloop_BC_textBox.Text = "0";
            // 
            // Openloop_BS_textBox
            // 
            this.Openloop_BS_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Openloop_BS_textBox.Location = new System.Drawing.Point(39, 97);
            this.Openloop_BS_textBox.Name = "Openloop_BS_textBox";
            this.Openloop_BS_textBox.Size = new System.Drawing.Size(39, 26);
            this.Openloop_BS_textBox.TabIndex = 1;
            this.Openloop_BS_textBox.Text = "0";
            // 
            // Openloop_AC_textBox
            // 
            this.Openloop_AC_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Openloop_AC_textBox.Location = new System.Drawing.Point(39, 64);
            this.Openloop_AC_textBox.Name = "Openloop_AC_textBox";
            this.Openloop_AC_textBox.Size = new System.Drawing.Size(39, 26);
            this.Openloop_AC_textBox.TabIndex = 1;
            this.Openloop_AC_textBox.Text = "0";
            // 
            // Openloop_AS_textBox
            // 
            this.Openloop_AS_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Openloop_AS_textBox.Location = new System.Drawing.Point(39, 31);
            this.Openloop_AS_textBox.Name = "Openloop_AS_textBox";
            this.Openloop_AS_textBox.Size = new System.Drawing.Size(39, 26);
            this.Openloop_AS_textBox.TabIndex = 1;
            this.Openloop_AS_textBox.Text = "0";
            // 
            // label191
            // 
            this.label191.AutoSize = true;
            this.label191.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label191.Location = new System.Drawing.Point(253, 186);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(53, 12);
            this.label191.TabIndex = 78;
            this.label191.Text = "输出幅值";
            // 
            // label192
            // 
            this.label192.AutoSize = true;
            this.label192.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label192.Location = new System.Drawing.Point(95, 188);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(53, 12);
            this.label192.TabIndex = 79;
            this.label192.Text = "幅值误差";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(199, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 24);
            this.label16.TabIndex = 75;
            this.label16.Text = "稳幅\r\n限幅";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(151, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 24);
            this.label15.TabIndex = 74;
            this.label15.Text = "中心\r\n幅值";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(109, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 24);
            this.label14.TabIndex = 73;
            this.label14.Text = "锁定\r\n幅值";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(339, 12);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 16);
            this.label12.TabIndex = 72;
            this.label12.Text = "D";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(296, 12);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 16);
            this.label11.TabIndex = 71;
            this.label11.Text = "I";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(249, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 16);
            this.label10.TabIndex = 70;
            this.label10.Text = "P";
            // 
            // G1_pid4_button
            // 
            this.G1_pid4_button.BackColor = System.Drawing.SystemColors.Window;
            this.G1_pid4_button.Location = new System.Drawing.Point(377, 140);
            this.G1_pid4_button.Name = "G1_pid4_button";
            this.G1_pid4_button.Size = new System.Drawing.Size(22, 17);
            this.G1_pid4_button.TabIndex = 69;
            this.G1_pid4_button.UseVisualStyleBackColor = false;
            this.G1_pid4_button.Click += new System.EventHandler(this.G1_pid4_button_Click);
            // 
            // pid4EnableG1
            // 
            this.pid4EnableG1.BackColor = System.Drawing.Color.Red;
            this.pid4EnableG1.Location = new System.Drawing.Point(82, 140);
            this.pid4EnableG1.Name = "pid4EnableG1";
            this.pid4EnableG1.Size = new System.Drawing.Size(22, 17);
            this.pid4EnableG1.TabIndex = 68;
            this.pid4EnableG1.UseVisualStyleBackColor = false;
            this.pid4EnableG1.Click += new System.EventHandler(this.pid4EnableG1_Click);
            // 
            // G1_pid3_button
            // 
            this.G1_pid3_button.BackColor = System.Drawing.SystemColors.Window;
            this.G1_pid3_button.Location = new System.Drawing.Point(377, 107);
            this.G1_pid3_button.Name = "G1_pid3_button";
            this.G1_pid3_button.Size = new System.Drawing.Size(22, 17);
            this.G1_pid3_button.TabIndex = 61;
            this.G1_pid3_button.UseVisualStyleBackColor = false;
            this.G1_pid3_button.Click += new System.EventHandler(this.G1_pid3_button_Click);
            // 
            // pid3EnableG1
            // 
            this.pid3EnableG1.BackColor = System.Drawing.Color.Red;
            this.pid3EnableG1.Location = new System.Drawing.Point(82, 107);
            this.pid3EnableG1.Name = "pid3EnableG1";
            this.pid3EnableG1.Size = new System.Drawing.Size(22, 17);
            this.pid3EnableG1.TabIndex = 60;
            this.pid3EnableG1.UseVisualStyleBackColor = false;
            this.pid3EnableG1.Click += new System.EventHandler(this.pid3EnableG1_Click);
            // 
            // G1_pid2_button
            // 
            this.G1_pid2_button.BackColor = System.Drawing.SystemColors.Window;
            this.G1_pid2_button.Location = new System.Drawing.Point(377, 74);
            this.G1_pid2_button.Name = "G1_pid2_button";
            this.G1_pid2_button.Size = new System.Drawing.Size(22, 17);
            this.G1_pid2_button.TabIndex = 53;
            this.G1_pid2_button.UseVisualStyleBackColor = false;
            this.G1_pid2_button.Click += new System.EventHandler(this.G1_pid2_button_Click);
            // 
            // pid2EnableG1
            // 
            this.pid2EnableG1.BackColor = System.Drawing.Color.Red;
            this.pid2EnableG1.Location = new System.Drawing.Point(82, 74);
            this.pid2EnableG1.Name = "pid2EnableG1";
            this.pid2EnableG1.Size = new System.Drawing.Size(22, 17);
            this.pid2EnableG1.TabIndex = 52;
            this.pid2EnableG1.UseVisualStyleBackColor = false;
            this.pid2EnableG1.Click += new System.EventHandler(this.pid2EnableG1_Click);
            // 
            // G1_pid1_button
            // 
            this.G1_pid1_button.BackColor = System.Drawing.SystemColors.Window;
            this.G1_pid1_button.Location = new System.Drawing.Point(377, 41);
            this.G1_pid1_button.Name = "G1_pid1_button";
            this.G1_pid1_button.Size = new System.Drawing.Size(22, 17);
            this.G1_pid1_button.TabIndex = 45;
            this.G1_pid1_button.UseVisualStyleBackColor = false;
            this.G1_pid1_button.Click += new System.EventHandler(this.G1_pid1_button_Click);
            // 
            // pid1EnableG1
            // 
            this.pid1EnableG1.BackColor = System.Drawing.Color.Red;
            this.pid1EnableG1.Location = new System.Drawing.Point(82, 41);
            this.pid1EnableG1.Name = "pid1EnableG1";
            this.pid1EnableG1.Size = new System.Drawing.Size(22, 17);
            this.pid1EnableG1.TabIndex = 44;
            this.pid1EnableG1.UseVisualStyleBackColor = false;
            this.pid1EnableG1.Click += new System.EventHandler(this.pid1EnableG1_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(45, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 16);
            this.label9.TabIndex = 3;
            this.label9.Text = "mV";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(6, 133);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 24);
            this.label8.TabIndex = 2;
            this.label8.Text = "G1DB\r\ncos";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(6, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 24);
            this.label7.TabIndex = 2;
            this.label7.Text = "G1DB\r\nsin";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(4, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 24);
            this.label6.TabIndex = 2;
            this.label6.Text = "G1DA\r\ncos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(4, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 24);
            this.label5.TabIndex = 2;
            this.label5.Text = "G1DA\r\nsin";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage11);
            this.tabControl2.Controls.Add(this.tabPage25);
            this.tabControl2.Location = new System.Drawing.Point(27, 319);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(423, 233);
            this.tabControl2.TabIndex = 14;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.comboBox3);
            this.tabPage4.Controls.Add(this.label108);
            this.tabPage4.Controls.Add(this.label101);
            this.tabPage4.Controls.Add(this.label100);
            this.tabPage4.Controls.Add(this.label99);
            this.tabPage4.Controls.Add(this.label98);
            this.tabPage4.Controls.Add(this.label96);
            this.tabPage4.Controls.Add(this.qFactorG1Enable);
            this.tabPage4.Controls.Add(this.qfactorLongTauG1_textBox);
            this.tabPage4.Controls.Add(this.qfactorMaxG1_textBox);
            this.tabPage4.Controls.Add(this.qfactorShortTauG1_textBox);
            this.tabPage4.Controls.Add(this.qfactorMinG1_textBox);
            this.tabPage4.Controls.Add(this.qfactorStartFreG1_textBox);
            this.tabPage4.Controls.Add(this.qfactorDelayG1_textBox);
            this.tabPage4.Controls.Add(this.G1_Qfactor_button);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(415, 207);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Q值";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "AI",
            "AQ",
            "BI",
            "BQ"});
            this.comboBox3.Location = new System.Drawing.Point(54, 40);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(84, 20);
            this.comboBox3.TabIndex = 51;
            this.comboBox3.Text = "AI";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(31, 104);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(29, 12);
            this.label108.TabIndex = 50;
            this.label108.Text = "延时";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(294, 91);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(29, 12);
            this.label101.TabIndex = 47;
            this.label101.Text = "Qmax";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(294, 43);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(29, 12);
            this.label100.TabIndex = 46;
            this.label100.Text = "Qmin";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(163, 140);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(29, 12);
            this.label99.TabIndex = 45;
            this.label99.Text = "长τ";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(163, 91);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(29, 12);
            this.label98.TabIndex = 44;
            this.label98.Text = "短τ";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(163, 48);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(29, 12);
            this.label96.TabIndex = 43;
            this.label96.Text = "频率";
            // 
            // qFactorG1Enable
            // 
            this.qFactorG1Enable.BackColor = System.Drawing.Color.Red;
            this.qFactorG1Enable.Location = new System.Drawing.Point(21, 19);
            this.qFactorG1Enable.Name = "qFactorG1Enable";
            this.qFactorG1Enable.Size = new System.Drawing.Size(22, 17);
            this.qFactorG1Enable.TabIndex = 42;
            this.qFactorG1Enable.UseVisualStyleBackColor = false;
            this.qFactorG1Enable.Click += new System.EventHandler(this.qFactorG1Enable_Click);
            // 
            // qfactorLongTauG1_textBox
            // 
            this.qfactorLongTauG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorLongTauG1_textBox.Location = new System.Drawing.Point(198, 125);
            this.qfactorLongTauG1_textBox.Multiline = true;
            this.qfactorLongTauG1_textBox.Name = "qfactorLongTauG1_textBox";
            this.qfactorLongTauG1_textBox.ReadOnly = true;
            this.qfactorLongTauG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorLongTauG1_textBox.TabIndex = 8;
            this.qfactorLongTauG1_textBox.Text = "0";
            // 
            // qfactorMaxG1_textBox
            // 
            this.qfactorMaxG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorMaxG1_textBox.Location = new System.Drawing.Point(329, 76);
            this.qfactorMaxG1_textBox.Multiline = true;
            this.qfactorMaxG1_textBox.Name = "qfactorMaxG1_textBox";
            this.qfactorMaxG1_textBox.ReadOnly = true;
            this.qfactorMaxG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorMaxG1_textBox.TabIndex = 7;
            this.qfactorMaxG1_textBox.Text = "0";
            // 
            // qfactorShortTauG1_textBox
            // 
            this.qfactorShortTauG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorShortTauG1_textBox.Location = new System.Drawing.Point(198, 76);
            this.qfactorShortTauG1_textBox.Multiline = true;
            this.qfactorShortTauG1_textBox.Name = "qfactorShortTauG1_textBox";
            this.qfactorShortTauG1_textBox.ReadOnly = true;
            this.qfactorShortTauG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorShortTauG1_textBox.TabIndex = 6;
            this.qfactorShortTauG1_textBox.Text = "0";
            // 
            // qfactorMinG1_textBox
            // 
            this.qfactorMinG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorMinG1_textBox.Location = new System.Drawing.Point(329, 28);
            this.qfactorMinG1_textBox.Multiline = true;
            this.qfactorMinG1_textBox.Name = "qfactorMinG1_textBox";
            this.qfactorMinG1_textBox.ReadOnly = true;
            this.qfactorMinG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorMinG1_textBox.TabIndex = 5;
            this.qfactorMinG1_textBox.Text = "0";
            // 
            // qfactorStartFreG1_textBox
            // 
            this.qfactorStartFreG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorStartFreG1_textBox.Location = new System.Drawing.Point(198, 33);
            this.qfactorStartFreG1_textBox.Multiline = true;
            this.qfactorStartFreG1_textBox.Name = "qfactorStartFreG1_textBox";
            this.qfactorStartFreG1_textBox.ReadOnly = true;
            this.qfactorStartFreG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorStartFreG1_textBox.TabIndex = 4;
            this.qfactorStartFreG1_textBox.Text = "0";
            // 
            // qfactorDelayG1_textBox
            // 
            this.qfactorDelayG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.qfactorDelayG1_textBox.Location = new System.Drawing.Point(66, 90);
            this.qfactorDelayG1_textBox.Multiline = true;
            this.qfactorDelayG1_textBox.Name = "qfactorDelayG1_textBox";
            this.qfactorDelayG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.qfactorDelayG1_textBox.TabIndex = 3;
            this.qfactorDelayG1_textBox.Text = "0";
            // 
            // G1_Qfactor_button
            // 
            this.G1_Qfactor_button.Location = new System.Drawing.Point(66, 160);
            this.G1_Qfactor_button.Name = "G1_Qfactor_button";
            this.G1_Qfactor_button.Size = new System.Drawing.Size(75, 23);
            this.G1_Qfactor_button.TabIndex = 0;
            this.G1_Qfactor_button.Text = "G1发送";
            this.G1_Qfactor_button.UseVisualStyleBackColor = true;
            this.G1_Qfactor_button.Click += new System.EventHandler(this.G1_Qfactor_button_Click);
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.comboBox5);
            this.tabPage11.Controls.Add(this.label109);
            this.tabPage11.Controls.Add(this.label110);
            this.tabPage11.Controls.Add(this.agcMinOutG1_textBox);
            this.tabPage11.Controls.Add(this.freResonantG1_textBox);
            this.tabPage11.Controls.Add(this.ResonantG1_button);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(415, 207);
            this.tabPage11.TabIndex = 2;
            this.tabPage11.Text = "谐振频率";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "AI",
            "AQ",
            "BI",
            "BQ",
            "关"});
            this.comboBox5.Location = new System.Drawing.Point(36, 50);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(84, 20);
            this.comboBox5.TabIndex = 57;
            this.comboBox5.Text = "AI";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(169, 128);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(29, 12);
            this.label109.TabIndex = 56;
            this.label109.Text = "幅值";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(169, 85);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(29, 12);
            this.label110.TabIndex = 55;
            this.label110.Text = "频率";
            // 
            // agcMinOutG1_textBox
            // 
            this.agcMinOutG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.agcMinOutG1_textBox.Location = new System.Drawing.Point(204, 113);
            this.agcMinOutG1_textBox.Multiline = true;
            this.agcMinOutG1_textBox.Name = "agcMinOutG1_textBox";
            this.agcMinOutG1_textBox.ReadOnly = true;
            this.agcMinOutG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.agcMinOutG1_textBox.TabIndex = 54;
            this.agcMinOutG1_textBox.Text = "0";
            // 
            // freResonantG1_textBox
            // 
            this.freResonantG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.freResonantG1_textBox.Location = new System.Drawing.Point(204, 70);
            this.freResonantG1_textBox.Multiline = true;
            this.freResonantG1_textBox.Name = "freResonantG1_textBox";
            this.freResonantG1_textBox.ReadOnly = true;
            this.freResonantG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.freResonantG1_textBox.TabIndex = 53;
            this.freResonantG1_textBox.Text = "0";
            // 
            // ResonantG1_button
            // 
            this.ResonantG1_button.Location = new System.Drawing.Point(36, 117);
            this.ResonantG1_button.Name = "ResonantG1_button";
            this.ResonantG1_button.Size = new System.Drawing.Size(75, 23);
            this.ResonantG1_button.TabIndex = 52;
            this.ResonantG1_button.Text = "G1发送";
            this.ResonantG1_button.UseVisualStyleBackColor = true;
            this.ResonantG1_button.Click += new System.EventHandler(this.ResonantG1_button_Click);
            // 
            // tabPage25
            // 
            this.tabPage25.Controls.Add(this.comboBox7);
            this.tabPage25.Controls.Add(this.label133);
            this.tabPage25.Controls.Add(this.label136);
            this.tabPage25.Controls.Add(this.label137);
            this.tabPage25.Controls.Add(this.label138);
            this.tabPage25.Controls.Add(this.phaseFindG1Enable);
            this.tabPage25.Controls.Add(this.minPhaseG1_textBox);
            this.tabPage25.Controls.Add(this.rightPhaseG1_textBox);
            this.tabPage25.Controls.Add(this.leftPhaseG1_textBox);
            this.tabPage25.Controls.Add(this.setTimeG1_textBox);
            this.tabPage25.Controls.Add(this.phaseFindG1_button);
            this.tabPage25.Location = new System.Drawing.Point(4, 22);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage25.Size = new System.Drawing.Size(415, 207);
            this.tabPage25.TabIndex = 3;
            this.tabPage25.Text = "最佳相位";
            this.tabPage25.UseVisualStyleBackColor = true;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "AI",
            "AQ",
            "BI",
            "BQ"});
            this.comboBox7.Location = new System.Drawing.Point(49, 42);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(84, 20);
            this.comboBox7.TabIndex = 66;
            this.comboBox7.Text = "AI";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(26, 96);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(29, 24);
            this.label133.TabIndex = 65;
            this.label133.Text = "设定\r\n时间";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(157, 131);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(29, 24);
            this.label136.TabIndex = 62;
            this.label136.Text = "截止\r\n相位";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(152, 93);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(41, 12);
            this.label137.TabIndex = 61;
            this.label137.Text = "右相位";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(152, 50);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(41, 12);
            this.label138.TabIndex = 60;
            this.label138.Text = "左相位";
            // 
            // phaseFindG1Enable
            // 
            this.phaseFindG1Enable.BackColor = System.Drawing.Color.Red;
            this.phaseFindG1Enable.Location = new System.Drawing.Point(16, 21);
            this.phaseFindG1Enable.Name = "phaseFindG1Enable";
            this.phaseFindG1Enable.Size = new System.Drawing.Size(22, 17);
            this.phaseFindG1Enable.TabIndex = 59;
            this.phaseFindG1Enable.UseVisualStyleBackColor = false;
            this.phaseFindG1Enable.Click += new System.EventHandler(this.phaseFindG1Enable_Click);
            // 
            // minPhaseG1_textBox
            // 
            this.minPhaseG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.minPhaseG1_textBox.Location = new System.Drawing.Point(193, 127);
            this.minPhaseG1_textBox.Multiline = true;
            this.minPhaseG1_textBox.Name = "minPhaseG1_textBox";
            this.minPhaseG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.minPhaseG1_textBox.TabIndex = 58;
            this.minPhaseG1_textBox.Text = "0";
            // 
            // rightPhaseG1_textBox
            // 
            this.rightPhaseG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rightPhaseG1_textBox.Location = new System.Drawing.Point(193, 78);
            this.rightPhaseG1_textBox.Multiline = true;
            this.rightPhaseG1_textBox.Name = "rightPhaseG1_textBox";
            this.rightPhaseG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.rightPhaseG1_textBox.TabIndex = 56;
            this.rightPhaseG1_textBox.Text = "0";
            // 
            // leftPhaseG1_textBox
            // 
            this.leftPhaseG1_textBox.AcceptsReturn = true;
            this.leftPhaseG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.leftPhaseG1_textBox.Location = new System.Drawing.Point(193, 35);
            this.leftPhaseG1_textBox.Multiline = true;
            this.leftPhaseG1_textBox.Name = "leftPhaseG1_textBox";
            this.leftPhaseG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.leftPhaseG1_textBox.TabIndex = 54;
            this.leftPhaseG1_textBox.Text = "0";
            // 
            // setTimeG1_textBox
            // 
            this.setTimeG1_textBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.setTimeG1_textBox.Location = new System.Drawing.Point(61, 92);
            this.setTimeG1_textBox.Multiline = true;
            this.setTimeG1_textBox.Name = "setTimeG1_textBox";
            this.setTimeG1_textBox.Size = new System.Drawing.Size(75, 27);
            this.setTimeG1_textBox.TabIndex = 53;
            this.setTimeG1_textBox.Text = "0";
            // 
            // phaseFindG1_button
            // 
            this.phaseFindG1_button.Location = new System.Drawing.Point(61, 162);
            this.phaseFindG1_button.Name = "phaseFindG1_button";
            this.phaseFindG1_button.Size = new System.Drawing.Size(75, 23);
            this.phaseFindG1_button.TabIndex = 52;
            this.phaseFindG1_button.Text = "G1发送";
            this.phaseFindG1_button.UseVisualStyleBackColor = true;
            this.phaseFindG1_button.Click += new System.EventHandler(this.phaseFindG1_button_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Red;
            this.button5.Location = new System.Drawing.Point(3, 379);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(22, 17);
            this.button5.TabIndex = 44;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Green;
            this.button6.Location = new System.Drawing.Point(3, 418);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(22, 17);
            this.button6.TabIndex = 45;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button7.Location = new System.Drawing.Point(3, 460);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(22, 17);
            this.button7.TabIndex = 46;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label93.Location = new System.Drawing.Point(1, 350);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(29, 12);
            this.label93.TabIndex = 84;
            this.label93.Text = "图例";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label94.Location = new System.Drawing.Point(6, 397);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(17, 12);
            this.label94.TabIndex = 85;
            this.label94.Text = "关";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label95.Location = new System.Drawing.Point(1, 438);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(29, 12);
            this.label95.TabIndex = 86;
            this.label95.Text = "幅值";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label97.Location = new System.Drawing.Point(1, 481);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(29, 12);
            this.label97.TabIndex = 87;
            this.label97.Text = "分量";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(271, 43);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 88;
            this.button8.Text = "G1AI";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(271, 70);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 89;
            this.button10.Text = "G1AQ";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(355, 43);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 90;
            this.button11.Text = "G1BI";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(356, 69);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 91;
            this.button12.Text = "G1BQ";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(1515, 14);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 23);
            this.button13.TabIndex = 92;
            this.button13.Text = "G2AI";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(1515, 43);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 93;
            this.button14.Text = "G2AQ";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(1596, 14);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 23);
            this.button15.TabIndex = 94;
            this.button15.Text = "G2BI";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(1596, 43);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 95;
            this.button16.Text = "G2BQ";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(436, 43);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 23);
            this.button17.TabIndex = 96;
            this.button17.Text = "G1Q值";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(1677, 14);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 23);
            this.button18.TabIndex = 97;
            this.button18.Text = "G2Q值";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(437, 69);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 23);
            this.button19.TabIndex = 98;
            this.button19.Text = "G1谐振频率";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(1677, 43);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 23);
            this.button20.TabIndex = 99;
            this.button20.Text = "G2谐振频率";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(517, 43);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 23);
            this.button22.TabIndex = 100;
            this.button22.Text = "G1最佳相位";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(1758, 14);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 23);
            this.button23.TabIndex = 101;
            this.button23.Text = "G1最佳相位";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(517, 69);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(75, 23);
            this.button25.TabIndex = 103;
            this.button25.Text = "G1模态切换";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1884, 782);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.label97);
            this.Controls.Add(this.label95);
            this.Controls.Add(this.label94);
            this.Controls.Add(this.label93);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.tabControl8);
            this.Controls.Add(this.tabControl7);
            this.Controls.Add(this.tabControl6);
            this.Controls.Add(this.pllLedG2);
            this.Controls.Add(this.sweepLedG2);
            this.Controls.Add(this.openLoopLedG2);
            this.Controls.Add(this.pllLedG1);
            this.Controls.Add(this.sweepLedG1);
            this.Controls.Add(this.openLoopLedG1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tabControl3);
            this.Controls.Add(this.label142);
            this.Controls.Add(this.label140);
            this.Controls.Add(this.label139);
            this.Controls.Add(this.storage_timetoend_textBox);
            this.Controls.Add(this.timer_storage_button);
            this.Controls.Add(this.storage_button);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.textBox89);
            this.Controls.Add(this.button_switch);
            this.Controls.Add(this.port_list);
            this.Controls.Add(this.tabControl4);
            this.Controls.Add(this.tabControl5);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label141);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.Resize += new System.EventHandler(this.Form1_AutoSizeChanged);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabControl3.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            this.tabPage27.ResumeLayout(false);
            this.tabPage16.ResumeLayout(false);
            this.tabPage16.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.tabPage18.PerformLayout();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.tabControl4.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage14.ResumeLayout(false);
            this.tabPage14.PerformLayout();
            this.tabPage17.ResumeLayout(false);
            this.tabPage17.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabControl6.ResumeLayout(false);
            this.tabPage19.ResumeLayout(false);
            this.tabPage19.PerformLayout();
            this.tabPage20.ResumeLayout(false);
            this.tabPage20.PerformLayout();
            this.tabPage21.ResumeLayout(false);
            this.tabPage21.PerformLayout();
            this.tabControl7.ResumeLayout(false);
            this.tabPage22.ResumeLayout(false);
            this.tabPage22.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage23.ResumeLayout(false);
            this.tabPage23.PerformLayout();
            this.tabPage24.ResumeLayout(false);
            this.tabPage24.PerformLayout();
            this.tabControl8.ResumeLayout(false);
            this.tabPage26.ResumeLayout(false);
            this.tabPage26.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.tabPage25.ResumeLayout(false);
            this.tabPage25.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Button Delete_fre_button;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.CheckBox Scanfre_PhaseB_checkBox;
        private System.Windows.Forms.CheckBox Scanfre_AmpB_checkBox;
        private System.Windows.Forms.CheckBox Scanfre_PhaseA_checkBox;
        private System.Windows.Forms.CheckBox Scanfre_AmpA_checkBox;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.CheckBox SB_IQ_AcheckBox;
        private System.Windows.Forms.CheckBox SA_IQ_AcheckBox;
        private System.Windows.Forms.CheckBox SB_IQ_QcheckBox;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.CheckBox SA_IQ_QcheckBox;
        private System.Windows.Forms.CheckBox SB_IQ_IcheckBox;
        private System.Windows.Forms.CheckBox SA_IQ_IcheckBox;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label123;
        private ScottPlot.FormsPlot plt1;
        private System.Windows.Forms.TabPage tabPage5;
        private ScottPlot.FormsPlot plt2;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox1;
        private ScottPlot.FormsPlot plt8;
        private ScottPlot.FormsPlot plt7;
        private ScottPlot.FormsPlot plt6;
        private ScottPlot.FormsPlot plt5;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.CheckBox checkBox11;
        private ScottPlot.FormsPlot plt10;
        private System.Windows.Forms.CheckBox checkBox17;
        private ScottPlot.FormsPlot plt18;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.Label label187;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.Button Delete_G2fre_button;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox25;
        private ScottPlot.FormsPlot plt17;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.CheckBox checkBox24;
        private ScottPlot.FormsPlot plt16;
        private ScottPlot.FormsPlot plt15;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.TextBox storage_timetoend_textBox;
        private System.Windows.Forms.Button timer_storage_button;
        private System.Windows.Forms.Button storage_button;
        private System.Windows.Forms.Button button9;
        protected System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.Button button_switch;
        private System.Windows.Forms.ComboBox port_list;
        private System.Windows.Forms.CheckBox checkBox32;
        private ScottPlot.FormsPlot plt20;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox HV4_textBox;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox HV3_textBox;
        private System.Windows.Forms.TextBox HV2_textBox;
        private System.Windows.Forms.TextBox HV1_textBox;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox HV_SB_textBox;
        private System.Windows.Forms.TextBox HV_CB_textBox;
        private System.Windows.Forms.TextBox HV_SA_textBox;
        private System.Windows.Forms.TextBox HV_CA_textBox;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.ComboBox comboBox11;
        private ScottPlot.FormsPlot plt12;
        private ScottPlot.FormsPlot plt11;
        private System.Windows.Forms.TextBox G1_wait_textBox;
        private System.Windows.Forms.TextBox G1_stepfre_textBox;
        private System.Windows.Forms.TextBox G1_lfre_textBox;
        private System.Windows.Forms.TextBox G1_hfre_textBox;
        private System.Windows.Forms.Button G1_scanfre_button;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.TextBox PLL_D_textBox;
        private System.Windows.Forms.TextBox PLL_relativeerror_textBox;
        private System.Windows.Forms.TextBox PLL_Nowphase_textBox;
        private System.Windows.Forms.TextBox PLL_Nowfre_textBox;
        private System.Windows.Forms.TextBox PLL_Lockpha_Limiteamp_textBox;
        private System.Windows.Forms.TextBox PLL_I_textBox;
        private System.Windows.Forms.TextBox PLL_P_textBox;
        private System.Windows.Forms.TextBox PLL_middlefre_textBox;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox PLL_Lockphase_textBox;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.Button G1_MISCbutton;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox G1_drivefre_textBox;
        private System.Windows.Forms.Button G1_drivefre_button;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Button G1_PLL_button;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button G1_HV_button;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private ScottPlot.FormsPlot plt22;
        private ScottPlot.FormsPlot plt21;
        private ScottPlot.FormsPlot plt24;
        private ScottPlot.FormsPlot plt23;
        private System.Windows.Forms.Button openLoopLedG1;
        private System.Windows.Forms.Button sweepLedG1;
        private System.Windows.Forms.Button pllLedG1;
        private System.Windows.Forms.Button openLoopLedG2;
        private System.Windows.Forms.Button sweepLedG2;
        private System.Windows.Forms.Button pllLedG2;
        private System.Windows.Forms.Button openLoopEnableG1;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.TabControl tabControl7;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.TabControl tabControl8;
        private System.Windows.Forms.TabPage tabPage26;
        private System.Windows.Forms.Button openLoopEnableG2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox G2_drivefre_textBox;
        private System.Windows.Forms.Button G2_drivefre_button;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox G2_waitfre_textBox;
        private System.Windows.Forms.TextBox G2_stepfre_textBox;
        private System.Windows.Forms.TextBox G2_lfre_textBox;
        private System.Windows.Forms.TextBox G2_hfre_textBox;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Button G2_scanfre_button;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Button G2_PLL_button;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.TextBox G2_PLL_D_textBox;
        private System.Windows.Forms.TextBox G2_PLL_Lockpha_Limiteamp_textBox;
        private System.Windows.Forms.TextBox G2_PLL_relativeerror_textBox;
        private System.Windows.Forms.TextBox G2_PLL_Nowphase_textBox;
        private System.Windows.Forms.TextBox G2_PLL_Nowfre_textBox;
        private System.Windows.Forms.TextBox G2_PLL_I_textBox;
        private System.Windows.Forms.TextBox G2_PLL_P_textBox;
        private System.Windows.Forms.TextBox G2_PLL_middlefre_textBox;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox G2_PLL_Lockphase_textBox;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.TextBox G2_Openloop_BC_textBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox G2_Opebloop_BS_textBox;
        private System.Windows.Forms.TextBox G2_Openloop_AC_textBox;
        private System.Windows.Forms.TextBox G2_Openloop_AS_textBox;
        private System.Windows.Forms.Button G2_HV_button;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button G2_MISCbutton;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox G2_HV4_textBox;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox G2_HV3_textBox;
        private System.Windows.Forms.TextBox G2_HV2_textBox;
        private System.Windows.Forms.TextBox G2_HV1_textBox;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox G2_HV_SB_textBox;
        private System.Windows.Forms.TextBox G2_HV_CB_textBox;
        private System.Windows.Forms.TextBox G2_HV_SA_textBox;
        private System.Windows.Forms.TextBox G2_HV_CA_textBox;
        private System.Windows.Forms.Button G2_pid4_button;
        private System.Windows.Forms.Button pid4EnableG2;
        private System.Windows.Forms.TextBox pid4DG2;
        private System.Windows.Forms.TextBox pid4IG2;
        private System.Windows.Forms.TextBox pid4PG2;
        private System.Windows.Forms.TextBox pid4LimitAmpG2;
        private System.Windows.Forms.TextBox pid4MiddleAmpG2;
        private System.Windows.Forms.TextBox pid4LockAmpG2;
        private System.Windows.Forms.Button G2_pid3_button;
        private System.Windows.Forms.Button pid3EnableG2;
        private System.Windows.Forms.TextBox pid3DG2;
        private System.Windows.Forms.TextBox pid3IG2;
        private System.Windows.Forms.TextBox pid3PG2;
        private System.Windows.Forms.TextBox pid3LimitAmpG2;
        private System.Windows.Forms.TextBox pid3MiddleAmpG2;
        private System.Windows.Forms.TextBox pid3LockAmpG2;
        private System.Windows.Forms.Button G2_pid2_button;
        private System.Windows.Forms.Button pid2EnableG2;
        private System.Windows.Forms.TextBox pid2DG2;
        private System.Windows.Forms.TextBox pid2IG2;
        private System.Windows.Forms.TextBox pid2PG2;
        private System.Windows.Forms.TextBox pid2LimitAmpG2;
        private System.Windows.Forms.TextBox pid2MiddleAmpG2;
        private System.Windows.Forms.TextBox pid2LockAmpG2;
        private System.Windows.Forms.Button G2_pid1_button;
        private System.Windows.Forms.Button pid1EnableG2;
        private System.Windows.Forms.TextBox pid1DG2;
        private System.Windows.Forms.TextBox pid1IG2;
        private System.Windows.Forms.TextBox pid1PG2;
        private System.Windows.Forms.TextBox pid1LimitAmpG2;
        private System.Windows.Forms.TextBox pid1MiddleAmpG2;
        private System.Windows.Forms.TextBox pid1LockAmpG2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.TextBox pidAmpOutputG1_textBox;
        private System.Windows.Forms.TextBox pidAmpErrorG1_textBox;
        private System.Windows.Forms.TextBox pid4DG1;
        private System.Windows.Forms.TextBox pid4IG1;
        private System.Windows.Forms.TextBox pid4PG1;
        private System.Windows.Forms.TextBox pid4LimitAmpG1;
        private System.Windows.Forms.TextBox pid4MiddleAmpG1;
        private System.Windows.Forms.TextBox pid4LockAmpG1;
        private System.Windows.Forms.TextBox pid3DG1;
        private System.Windows.Forms.TextBox pid3IG1;
        private System.Windows.Forms.TextBox pid3PG1;
        private System.Windows.Forms.TextBox pid3LimitAmpG1;
        private System.Windows.Forms.TextBox pid3MiddleAmpG1;
        private System.Windows.Forms.TextBox pid3LockAmpG1;
        private System.Windows.Forms.TextBox pid2DG1;
        private System.Windows.Forms.TextBox pid2IG1;
        private System.Windows.Forms.TextBox pid2PG1;
        private System.Windows.Forms.TextBox pid2LimitAmpG1;
        private System.Windows.Forms.TextBox pid2MiddleAmpG1;
        private System.Windows.Forms.TextBox pid2LockAmpG1;
        private System.Windows.Forms.TextBox pid1DG1;
        private System.Windows.Forms.TextBox pid1IG1;
        private System.Windows.Forms.TextBox pid1PG1;
        private System.Windows.Forms.TextBox pid1LimitAmpG1;
        private System.Windows.Forms.TextBox pid1MiddleAmpG1;
        private System.Windows.Forms.TextBox pid1LockAmpG1;
        private System.Windows.Forms.TextBox Openloop_BC_textBox;
        private System.Windows.Forms.TextBox Openloop_BS_textBox;
        private System.Windows.Forms.TextBox Openloop_AC_textBox;
        private System.Windows.Forms.TextBox Openloop_AS_textBox;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button G1_pid4_button;
        private System.Windows.Forms.Button pid4EnableG1;
        private System.Windows.Forms.Button G1_pid3_button;
        private System.Windows.Forms.Button pid3EnableG1;
        private System.Windows.Forms.Button G1_pid2_button;
        private System.Windows.Forms.Button pid2EnableG1;
        private System.Windows.Forms.Button G1_pid1_button;
        private System.Windows.Forms.Button pid1EnableG1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox pidAmpOutputG2_textBox;
        private System.Windows.Forms.TextBox pidAmpErrorG2_textBox;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Button G2_CMD_OPENLOOP_ACT_button;
        private System.Windows.Forms.Button CMD_OPENLOOP_ACT_button;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox qfactorLongTauG1_textBox;
        private System.Windows.Forms.TextBox qfactorMaxG1_textBox;
        private System.Windows.Forms.TextBox qfactorShortTauG1_textBox;
        private System.Windows.Forms.TextBox qfactorMinG1_textBox;
        private System.Windows.Forms.TextBox qfactorStartFreG1_textBox;
        private System.Windows.Forms.TextBox qfactorDelayG1_textBox;
        private System.Windows.Forms.Button G1_Qfactor_button;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TextBox qfactorLongTauG2_textBox;
        private System.Windows.Forms.TextBox qfactorMaxG2_textBox;
        private System.Windows.Forms.TextBox qfactorShortTauG2_textBox;
        private System.Windows.Forms.TextBox qfactorMinG2_textBox;
        private System.Windows.Forms.TextBox qfactorStartFreG2_textBox;
        private System.Windows.Forms.TextBox qfactorDelayG2_textBox;
        private System.Windows.Forms.Button G2_Qfactor_button;
        private System.Windows.Forms.Button qFactorG2Enable;
        private System.Windows.Forms.Button qFactorG1Enable;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TextBox agcMinOutG1_textBox;
        private System.Windows.Forms.TextBox freResonantG1_textBox;
        private System.Windows.Forms.Button ResonantG1_button;
        private System.Windows.Forms.TabPage tabPage12;
        private ScottPlot.FormsPlot plt32;
        private ScottPlot.FormsPlot plt31;
        private System.Windows.Forms.TabPage tabPage17;
        private ScottPlot.FormsPlot plt34;
        private ScottPlot.FormsPlot plt33;
        private System.Windows.Forms.CheckBox checkBox31;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox36;
        private System.Windows.Forms.CheckBox checkBox35;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.TextBox agcMinOutG2_textBox;
        private System.Windows.Forms.TextBox freResonantG2_textBox;
        private System.Windows.Forms.Button ResonantG2_button;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.TextBox G2_pilotFre_rightAmp_textBox;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.TextBox G2_pilotFreCos_textBox;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.TextBox G2_pilotFre_textBox;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.TextBox G2_pilotFreSin_textBox;
        private System.Windows.Forms.Button G2_pilotFrequncy_button;
        private System.Windows.Forms.Button pilotFrequncyEnableG2;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.TextBox G2_pilotFre_leftAmp_textBox;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button G1_dataLineEnable_button;
        private System.Windows.Forms.Button G2_dataLineEnable_button;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Button phaseFindG1Enable;
        private System.Windows.Forms.TextBox minPhaseG1_textBox;
        private System.Windows.Forms.TextBox rightPhaseG1_textBox;
        private System.Windows.Forms.TextBox leftPhaseG1_textBox;
        private System.Windows.Forms.TextBox setTimeG1_textBox;
        private System.Windows.Forms.Button phaseFindG1_button;
        private System.Windows.Forms.TabPage tabPage27;
        private ScottPlot.FormsPlot pltphasefinder1;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Button G1_modeSwitch_button;
        private System.Windows.Forms.Button G1_modeCopySB_button;
        private System.Windows.Forms.Button G1_modeCopySA_button;
        private System.Windows.Forms.TextBox G1_modeSwitchDelay_textBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Button G1_modeSwitchEnable;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
    }
}

